import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Safety net for third-party canvas or style parsers failing on Tailwind CSS v4 OKLAB/OKLCH color space functions
if (typeof window !== 'undefined') {
  const isColorSpaceError = (error: any) => {
    if (!error) return false;
    const message = (error.message || '').toLowerCase();
    const stack = (error.stack || '').toLowerCase();
    return message.includes('unsupported color function') ||
           message.includes('oklab') ||
           message.includes('oklch') ||
           stack.includes('unsupported color function') ||
           stack.includes('oklab') ||
           stack.includes('oklch');
  };

  window.addEventListener('unhandledrejection', (event) => {
    const reasonStr = event.reason?.message || String(event.reason || '');
    if (isColorSpaceError(event.reason)) {
      event.preventDefault();
      console.warn('Silenced non-hazardous Tailwind color-parsing unhandled rejection:', event.reason);
    } else if (reasonStr.includes('Missing or insufficient permissions') || reasonStr.includes('permission-denied') || reasonStr.toLowerCase().includes('permission')) {
      event.preventDefault();
      console.warn('Silenced Firestore unhandled permission rejection:', event.reason);
    } else {
      console.error('Unhandled rejection:', event.reason);
      event.preventDefault();
    }
  });

  window.addEventListener('error', (event) => {
    if (isColorSpaceError(event.error) || isColorSpaceError(event)) {
      event.preventDefault();
      console.warn('Silenced non-hazardous Tailwind color-parsing error event:', event.error || event);
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
