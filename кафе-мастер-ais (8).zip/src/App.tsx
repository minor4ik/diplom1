import React, { useState, useEffect, useMemo, useCallback, Suspense, Component, ReactNode, lazy } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Layout from './components/Layout';
import { useCafeStore } from './store';
import { View, Staff } from './types';
import { getEffectiveRole } from './lib/auth';
import { auth, db } from './firebase';
import { onAuthStateChanged, signInAnonymously } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { Loader2, AlertTriangle, AlertCircle, History, Wifi, WifiOff } from 'lucide-react';
import Login from './components/Login';
import { logSystemError } from './store';
import MaintenanceMode from './components/MaintenanceMode';

// Ленивая загрузка компонентов для ускорения начальной загрузки
const Dashboard = lazy(() => import('./components/Dashboard'));
const MenuManager = lazy(() => import('./components/MenuManager'));
const OrderSystem = lazy(() => import('./components/OrderSystem'));
const KitchenView = lazy(() => import('./components/KitchenView'));
const Inventory = lazy(() => import('./components/Inventory'));
const UserManager = lazy(() => import('./components/UserManager'));
const Reports = lazy(() => import('./components/Reports'));
const Changelog = lazy(() => import('./components/Changelog'));
const LogsView = lazy(() => import('./components/LogsView'));
const PromoManager = lazy(() => import('./components/PromoManager'));
const TicketsView = lazy(() => import('./components/TicketsView'));
const StaffChat = lazy(() => import('./components/StaffChat'));
const Profile = lazy(() => import('./components/Profile'));
const WalletView = lazy(() => import('./components/WalletView'));
const WifiView = lazy(() => import('./components/WifiView'));
const DevLogsView = lazy(() => import('./components/DevLogsView'));
const DocumentManager = lazy(() => import('./components/DocumentManager'));

// Компонент Error Boundary для предотвращения черного экрана при ошибках во время выполнения
interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false, error: null };

  static getDerivedStateFromError(error: any): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error('Critical UI Error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 dark:bg-slate-950 transition-colors">
          <div className="max-w-md w-full bg-white dark:bg-slate-900 rounded-3xl p-8 shadow-xl text-center border border-slate-200 dark:border-slate-800">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle size={32} />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Ой! Ошибка</h1>
            <p className="text-slate-500 dark:text-slate-400 mb-6 font-medium">
              Произошла критическая ошибка при работе интерфейса.
            </p>
            <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-xl text-left mb-6 overflow-auto max-h-40 border border-slate-100 dark:border-slate-700">
              <code className="text-[10px] text-red-500 font-mono">
                {this.state.error?.toString() || 'Неизвестная ошибка'}
              </code>
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all active:scale-95 shadow-lg shadow-indigo-200 dark:shadow-none"
            >
              Перезагрузить страницу
            </button>
          </div>
        </div>
      );
    }

    // @ts-ignore
    return this.props.children;
  }
}

export default function App() {
  const { 
    dishes, 
    updateDish,
    deleteDish,
    ingredients, 
    updateIngredient,
    deleteIngredient,
    orders, 
    addOrder, 
    updateOrderStatus,
    staff,
    updateStaff,
    updateStaffProfile,
    deleteStaff,
    expenses,
    addExpense,
    promoCodes,
    updatePromoCode,
    deletePromoCode,
    tickets,
    addTicket,
    updateTicket,
    archiveTicket,
    addTicketComment,
    markTicketAsRead,
    chatRooms,
    createChatRoom,
    staffMessages,
    sendStaffMessage,
    markMessageAsRead,
    pinChatMessage,
    unpinChatMessage,
    updateChatRoom,
    updateParticipantInRoom,
    clearChatRoomMessages,
    deleteChatRoom,
    setUserPresence,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    clearNotifications,
    clearOrders,
    clearKitchenOrders,
    clearDatabaseCache,
    logs,
    generateId,
    isInitialDataChecked,
    currentUser,
    setCurrentUser,
    firebaseUser,
    currentView,
    setView,
    theme,
    setTheme,
    loadingTimedOut,
    setLoadingTimedOut,
    isSystemOffline,
    setSystemOfflineStatus
  } = useCafeStore();

  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const handleGlobalError = (event: ErrorEvent) => {
      if (event.message?.includes('Quota exceeded') || event.message?.includes('resource-exhausted')) return;
      logSystemError(event.message || 'Unknown global runtime error', 'window.onerror', event.error?.stack);
    };

    const handlePromiseRejection = (event: PromiseRejectionEvent) => {
      const reason = event.reason;
      const msg = reason instanceof Error ? reason.message : String(reason);
      const stack = reason instanceof Error ? reason.stack : undefined;
      if (msg?.includes('Quota exceeded') || msg?.includes('resource-exhausted')) return;
      logSystemError(msg || 'Unhandled promise rejection', 'PromiseRejection', stack);
    };

    const originalConsoleError = console.error;
    console.error = (...args: any[]) => {
      originalConsoleError.apply(console, args);
      const message = args.map(arg => {
        if (arg instanceof Error) {
          return arg.message + (arg.stack ? `\n${arg.stack}` : '');
        }
        return typeof arg === 'object' ? JSON.stringify(arg) : String(arg);
      }).join(' ');

      if (
        message.includes('Quota exceeded') || 
        message.includes('resource-exhausted') || 
        message.includes('Firestore Error') || 
        message.includes('FirebaseError') ||
        message.includes('Muted background error')
      ) {
        return;
      }
      logSystemError(message, 'console.error', Error().stack);
    };

    window.addEventListener('error', handleGlobalError);
    window.addEventListener('unhandledrejection', handlePromiseRejection);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('error', handleGlobalError);
      window.removeEventListener('unhandledrejection', handlePromiseRejection);
      console.error = originalConsoleError;
    };
  }, []);

  const authInitialized = true; // Use simple state since store handles the real thing
  
  const hasLocalSession = !!currentUser;
  const isDataLoading = !hasLocalSession && !isInitialDataChecked;

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      if (!user) {
        signInAnonymously(auth).catch(err => {
          console.error("Ошибка тихой анонимной авторизации:", err);
        });
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (isDataLoading) {
      const timer = setTimeout(() => {
        setLoadingTimedOut(true);
      }, 5000); // 5 секунд для таймаута
      return () => clearTimeout(timer);
    } else {
      setLoadingTimedOut(false);
    }
  }, [isDataLoading]);

  const handleLogin = (user: Staff) => {
    setCurrentUser(user);
    
    // Перенаправляем на доступный раздел при входе
    const role = getEffectiveRole(user);
    if (role === 'chef' || role === 'bartender') setView('kitchen');
    else if (role === 'waiter' || role === 'user') setView('orders');
    else setView('profile');
  };

  const handleLogout = async () => {
    if (currentUser) {
      try {
        await setUserPresence(currentUser.id, false);
      } catch (err) {
        console.warn('Logout presence update failed:', err);
      }
    }
    setCurrentUser(null);
  };

  const handleUpdateProfile = async (id: string, updates: Partial<Staff>) => {
    await updateStaffProfile(id, updates);
  };

  useEffect(() => {
    if (currentUser?.id && firebaseUser && isOnline) {
      setUserPresence(currentUser.id, true).catch(err => {
        console.warn('IsOnline triggered presence failed:', err);
      });
    }
  }, [isOnline, currentUser?.id, firebaseUser, setUserPresence]);

  useEffect(() => {
    if (currentUser && firebaseUser) {
      // Поддерживаем актуальность маппинга UID -> Staff ID и затем устанавливаем присутствие
      const syncMappingAndPresence = async () => {
        try {
          await setDoc(doc(db, 'staff_uids', firebaseUser.uid), { staffId: currentUser.id });
          await setUserPresence(currentUser.id, true);
        } catch (e) {
          console.warn('Silent mapping sync or presence failed:', e);
          // В случае неудачи всё равно пробуем установить статус, но безопасно
          try {
            await setUserPresence(currentUser.id, true);
          } catch (innerErr) {
            console.warn('Retry silent presence failed:', innerErr);
          }
        }
      };
      
      syncMappingAndPresence();
      
      const handleTabClose = () => {
        setUserPresence(currentUser.id, false).catch(err => {
          console.warn('Tab close presence failed:', err);
        });
      };
      
      window.addEventListener('beforeunload', handleTabClose);
      return () => {
        window.removeEventListener('beforeunload', handleTabClose);
      };
    }
  }, [currentUser?.id, firebaseUser, setUserPresence]);

  useEffect(() => {
    // Восстановление сессии Firebase Auth, если есть локальный пользователь
    if (currentUser && !auth.currentUser) {
      signInAnonymously(auth).catch(err => {
        console.error('Не удалось восстановить анонимную сессию auth:', err);
      });
    }
  }, [currentUser]);

  useEffect(() => {
    // Отключено для экономии квоты при исчерпании ресурсов
    // testFirebase();
  }, []);

  const [targetTicketId, setTargetTicketId] = useState<string | null>(null);
  const [targetUserId, setTargetUserId] = useState<string | null>(null);
  const [targetChatUserId, setTargetChatUserId] = useState<string | null>(null);

  const handleNavigate = useCallback((newView: View, params?: { ticketId?: string; userId?: string; chatId?: string }) => {
    // Базовая проверка RBAC для навигации
    if (!currentUser) return;
    const role = getEffectiveRole(currentUser);
    const viewConfig: Record<View, string[]> = {
      'tickets': ['owner', 'admin', 'tech', 'tester', 'developer'],
      'dashboard': ['owner', 'admin', 'tech', 'developer', 'tester'],
      'orders': ['owner', 'admin', 'chef', 'waiter', 'bartender', 'tech', 'user', 'developer'],
      'kitchen': ['owner', 'admin', 'chef', 'bartender', 'tech', 'developer'],
      'menu': ['owner', 'admin', 'tech', 'developer'],
      'inventory': ['owner', 'admin', 'chef', 'bartender', 'tech', 'developer'],
      'staff': ['owner', 'admin', 'tech', 'developer', 'hr'],
      'hr-docs': ['owner', 'hr', 'admin', 'developer', 'tech', 'tester'],
      'reports': ['owner', 'admin', 'chef', 'tech', 'developer'],
      'promos': ['owner', 'admin', 'tech', 'developer'],
      'changelog': ['owner', 'admin', 'tech', 'developer'],
      'logs': ['owner', 'admin', 'tech', 'developer'],
      'wifi': ['owner', 'admin', 'tech', 'developer', 'tester'],
      'wallet': ['owner', 'admin', 'chef', 'waiter', 'bartender', 'tech', 'tester', 'developer', 'user', 'hr'],
      'staff-chat': ['owner', 'admin', 'chef', 'waiter', 'bartender', 'tech', 'tester', 'developer', 'hr'],
      'profile': ['owner', 'admin', 'chef', 'waiter', 'bartender', 'tech', 'tester', 'developer', 'user', 'hr'],
      'dev-logs': ['developer']
    };

    const allowedRoles = viewConfig[newView as keyof typeof viewConfig];
    if (allowedRoles && !allowedRoles.includes(role)) {
      console.warn(`Access denied for role ${role} to view ${newView}`);
      return; 
    }

    setView(newView);
    if (params?.ticketId) {
      setTargetTicketId(params.ticketId);
    } else {
      setTargetTicketId(null);
    }

    if (params?.userId) {
      setTargetUserId(params.userId);
    } else {
      setTargetUserId(null);
    }

    if (params?.chatId) {
      setTargetChatUserId(params.chatId);
    } else {
      setTargetChatUserId(null);
    }
  }, [currentUser, setView, setTargetTicketId, setTargetUserId, setTargetChatUserId]);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
    }
  }, [theme]);

  if (isDataLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4 transition-colors">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="text-indigo-600 mb-6 flex justify-center">
            {loadingTimedOut ? (
              <AlertCircle size={48} className="text-rose-500" />
            ) : (
              <Loader2 size={48} className="animate-spin" />
            )}
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2 tracking-tight">
            {loadingTimedOut 
              ? "Проблемы с загрузкой" 
              : "Загрузка системы..."}
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-6 max-w-xs mx-auto">
            {loadingTimedOut 
              ? "Данные загружаются слишком долго. Пожалуйста, проверьте подключение к интернету." 
              : "Синхронизация данных с сервером. Пожалуйста, подождите."}
          </p>
          
          {loadingTimedOut && (
            <div className="flex flex-col gap-3 w-full">
              <button 
                onClick={() => window.location.reload()}
                className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-500/20 hover:bg-indigo-700 transition-all active:scale-95 flex items-center justify-center gap-2 w-full"
              >
                <History size={18} />
                Попробовать снова
              </button>
              <button 
                onClick={() => {
                  try {
                    localStorage.clear();
                    window.location.reload();
                  } catch(e) {}
                }}
                className="px-6 py-3 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold text-sm hover:bg-slate-300 dark:hover:bg-slate-700 transition-all active:scale-95 flex items-center justify-center gap-2 w-full"
              >
                Очистить кэш и войти заново
              </button>
            </div>
          )}
        </motion.div>
      </div>
    );
  }

  const role = currentUser ? getEffectiveRole(currentUser) : 'other';
  const isDeveloper = role === 'developer';

  if (isSystemOffline && !isDeveloper) {
    return (
      <MaintenanceMode
        staff={staff}
        onLogin={handleLogin}
        currentUser={currentUser}
        onLogout={handleLogout}
      />
    );
  }

  if (!currentUser) {
    return (
      <ErrorBoundary>
        <Login onLogin={handleLogin} staff={staff} />
      </ErrorBoundary>
    );
  }

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard orders={orders} onNavigate={handleNavigate} currentUser={currentUser!} />;
      case 'menu':
        return <MenuManager dishes={dishes} updateDish={updateDish} deleteDish={deleteDish} />;
      case 'orders':
        return <OrderSystem 
          dishes={dishes} 
          addOrder={addOrder} 
          ingredients={ingredients} 
          promoCodes={promoCodes} 
          generateId={generateId} 
          currentUser={currentUser} 
        />;
      case 'kitchen':
        return <KitchenView 
          orders={orders} 
          updateStatus={updateOrderStatus} 
          dishes={dishes} 
          currentUser={currentUser} 
          clearKitchen={clearKitchenOrders}
        />;
      case 'inventory':
        return <Inventory ingredients={ingredients} updateIngredient={updateIngredient} addExpense={addExpense} />;
      case 'staff':
        return <UserManager staff={staff} updateStaff={updateStaff} deleteStaff={deleteStaff} currentUser={currentUser!} generateId={generateId} />;
      case 'hr-docs':
        return <DocumentManager />;
      case 'reports':
        return <Reports orders={orders} expenses={expenses} />;
      case 'changelog':
        return <Changelog />;
      case 'logs':
        return <LogsView logs={logs} staff={staff} />;
      case 'promos':
        return <PromoManager promoCodes={promoCodes} updatePromoCode={updatePromoCode} deletePromoCode={deletePromoCode} generateId={generateId} />;
      case 'tickets':
        return <TicketsView 
          tickets={tickets} 
          staff={staff}
          addTicket={addTicket} 
          updateTicket={updateTicket} 
          archiveTicket={archiveTicket}
          addTicketComment={addTicketComment} 
          markTicketAsRead={markTicketAsRead}
          currentUser={currentUser!} 
          initialTicketId={targetTicketId}
          onClose={() => setTargetTicketId(null)}
        />;
      case 'wifi':
        return <WifiView currentUser={currentUser!} />;
      case 'staff-chat':
        return <StaffChat 
          rooms={chatRooms}
          messages={staffMessages} 
          staff={staff}
          sendMessage={sendStaffMessage} 
          createRoom={createChatRoom}
          updateRoom={updateChatRoom}
          pinMessage={pinChatMessage}
          unpinMessage={unpinChatMessage}
          updateParticipant={updateParticipantInRoom}
          clearRoomMessages={clearChatRoomMessages}
          deleteRoom={deleteChatRoom}
          markAsRead={markMessageAsRead}
          currentUser={currentUser!} 
          theme={theme}
          setTheme={setTheme}
          onNavigate={handleNavigate}
          targetUserId={targetChatUserId || undefined}
        />;
      case 'dev-logs':
        return (
          <DevLogsView 
            currentUser={currentUser!} 
            clearCache={clearDatabaseCache} 
            isSystemOffline={isSystemOffline}
            setSystemOfflineStatus={setSystemOfflineStatus}
          />
        );
      case 'wallet':
        return <WalletView currentUser={currentUser!} />;
      case 'profile':
        return <Profile 
          currentUser={currentUser!} 
          staff={staff}
          orders={orders}
          tickets={tickets}
          onNavigate={handleNavigate}
          updateProfile={handleUpdateProfile}
          viewUserId={targetUserId || undefined}
        />;
      default:
        return <Dashboard orders={orders} onNavigate={handleNavigate} currentUser={currentUser!} />;
    }
  };

  return (
    <ErrorBoundary>
      {/* Индикатор отсутствия сети */}
      {!isOnline && (
        <div className="fixed top-0 left-0 right-0 z-[100] bg-amber-500 text-white text-[10px] font-bold py-1 px-4 flex items-center justify-center gap-2 animate-in fade-in slide-in-from-top duration-300">
          <AlertCircle size={12} />
          <span>РАБОТА В ОФФЛАЙН-РЕЖИМЕ — ДАННЫЕ СИНХРОНИЗИРУЮТСЯ ПРИ ПОДКЛЮЧЕНИИ</span>
        </div>
      )}
      <Layout 
        currentView={currentView} 
        setView={handleNavigate}
        notifications={notifications}
        markNotificationRead={markNotificationRead}
        markAllNotificationsRead={markAllNotificationsRead}
        clearNotifications={clearNotifications}
        onLogout={handleLogout}
        currentUser={currentUser}
        theme={theme}
        setTheme={setTheme}
      >
        <Suspense fallback={
          <div className="flex items-center justify-center h-full">
            <Loader2 className="animate-spin text-indigo-500" />
          </div>
        }>
          <AnimatePresence mode="wait">
            <motion.div
              key={currentView}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {renderView()}
            </motion.div>
          </AnimatePresence>
        </Suspense>
      </Layout>
    </ErrorBoundary>
  );
}
