import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

// Инициализация Firebase
const app = initializeApp(firebaseConfig);

// Инициализация Firestore с поддержкой оффлайн-режима и нескольких вкладок
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() })
}, firebaseConfig.firestoreDatabaseId);

// Инициализация Auth
export const auth = getAuth();
