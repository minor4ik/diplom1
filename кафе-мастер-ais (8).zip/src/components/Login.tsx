import React, { useState } from 'react';
import { Utensils, Lock, User, AlertCircle, Phone, UserPlus, Sparkles, X, FileText } from 'lucide-react';
import { Card, Button } from './UI';
import { Staff } from '../types';
import { db, auth } from '../firebase';
import { collection, addDoc, doc, setDoc, updateDoc, writeBatch } from 'firebase/firestore';
import { signInAnonymously } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';

interface LoginProps {
  onLogin: (user: Staff) => void;
  staff: Staff[];
}

export default function Login({ onLogin, staff }: LoginProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [activeDoc, setActiveDoc] = useState<'agreement' | 'offer' | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmedLogin = login.trim();
    const trimmedPassword = password.trim();

    if (!trimmedLogin || !trimmedPassword) {
      setError('Пожалуйста, введите логин и пароль');
      return;
    }

    setIsLoading(true);
    try {
      if (isRegistering) {
        if (!name.trim()) {
          setError('Пожалуйста, введите ваше имя');
          setIsLoading(false);
          return;
        }

        if (!agreed) {
          setError('Вы должны подтвердить согласие с пользовательским соглашением и правилами оферты');
          setIsLoading(false);
          return;
        }
        
        // Check if login already exists
        if (staff.some(s => s.login === trimmedLogin)) {
          setError('Этот логин уже занят');
          setIsLoading(false);
          return;
        }

        // 1. Sign in anonymously to get a UID
        const authResult = await signInAnonymously(auth);
        const uid = authResult.user.uid;

        const newUser: Staff = {
          id: uid, // Use UID as document ID
          name: name.trim(),
          login: trimmedLogin,
          password: trimmedPassword,
          phone: phone.trim() || 'не указан',
          role: 'user',
          position: 'Пользователь'
        };

        // 2. Create staff document and mapping
        const batch = writeBatch(db);
        batch.set(doc(db, 'staff', uid), newUser);
        batch.set(doc(db, 'staff_uids', uid), { staffId: uid });
        await batch.commit();

        onLogin(newUser);
      } else {
        const user = staff.find(s => s.login === trimmedLogin && (s.password === trimmedPassword || (!s.password && trimmedPassword === '1234')));
        
        if (user) {
          // 1. Sign in anonymously
          const authResult = await signInAnonymously(auth);
          const uid = authResult.user.uid;

          // 2. Link the Auth UID to the staff record via a "pointer" document
          // This allows rules to lookup role by UID even if ID is different
          try {
             await setDoc(doc(db, 'staff_uids', uid), { staffId: user.id });
             await setDoc(doc(db, 'staff', user.id), { ...user, firebaseUid: uid }, { merge: true });
          } catch (linkErr) {
             console.warn('Could not link staff with firebaseUid:', linkErr);
          }

          onLogin({ ...user, firebaseUid: uid } as any);
        } else {
          setError('Неверный логин или пароль');
        }
      }
    } catch (err) {
      console.error('Login/Registration error:', err);
      setError('Произошла ошибка при входе. Попробуйте снова.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden transition-colors duration-500">
      {/* Background blobs for flair */}
      <div className="absolute top-0 -left-4 w-72 h-72 bg-indigo-200 dark:bg-indigo-900 rounded-full mix-blend-multiply filter blur-3xl opacity-30 dark:opacity-20 animate-pulse" />
      <div className="absolute bottom-0 -right-4 w-72 h-72 bg-violet-200 dark:bg-purple-900 rounded-full mix-blend-multiply filter blur-3xl opacity-30 dark:opacity-20 animate-pulse delay-1000" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="text-center mb-8">
          <motion.div 
            whileHover={{ scale: 1.1, rotate: 10 }}
            className="w-16 h-16 bg-linear-to-br from-indigo-500 to-indigo-700 rounded-2xl flex items-center justify-center text-white mx-auto mb-4 shadow-xl shadow-indigo-200 dark:shadow-indigo-900/50"
          >
            <Utensils size={32} />
          </motion.div>
          <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Кафе Мастер</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2 font-medium">Система управления заведением</p>
        </div>

        <Card className="p-8 shadow-2xl border-white dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl relative overflow-hidden group">
          {/* Subtle line decoration */}
          <div className="absolute top-0 inset-x-0 h-1 bg-linear-to-r from-indigo-500 via-indigo-600 to-indigo-500" />
          
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-8 text-center flex items-center justify-center gap-2">
            <AnimatePresence mode="wait">
              <motion.span
                key={isRegistering ? 'reg' : 'login'}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
              >
                {isRegistering ? 'Создать аккаунт' : 'С возвращением'}
              </motion.span>
            </AnimatePresence>
            {!isRegistering && <Sparkles className="text-amber-400 fill-amber-400" size={20} />}
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-5">
            <AnimatePresence mode="wait">
              {error && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 text-red-600 dark:text-red-400 rounded-xl text-sm flex items-center gap-2"
                >
                  <AlertCircle size={16} />
                  {error}
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence mode="wait">
              {isRegistering && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-2 overflow-hidden"
                >
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Как вас зовут?</label>
                  <div className="relative group">
                    <UserPlus className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                    <input 
                      type="text" 
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all font-medium dark:bg-slate-800 dark:text-white"
                      placeholder="Ваше имя"
                      value={name}
                      onChange={e => setName(e.target.value)}
                      disabled={isLoading}
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Логин</label>
              <div className="relative group">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                <input 
                  type="text" 
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all font-medium dark:bg-slate-800 dark:text-white"
                  placeholder="Введите логин"
                  value={login}
                  onChange={e => setLogin(e.target.value)}
                  disabled={isLoading}
                />
              </div>
            </div>

            <AnimatePresence mode="wait">
              {isRegistering && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-2 overflow-hidden"
                >
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Телефон</label>
                  <div className="relative group">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                    <input 
                      type="tel" 
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all font-medium dark:bg-slate-800 dark:text-white"
                      placeholder="+7 (___) ___-__-__"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      disabled={isLoading}
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Пароль</label>
              <div className="relative group">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                <input 
                  type="password" 
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all font-medium dark:bg-slate-800 dark:text-white"
                  placeholder="Введите пароль"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  disabled={isLoading}
                />
              </div>
            </div>

            <AnimatePresence mode="wait">
              {isRegistering && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-start gap-3 px-1 py-1 max-h-24 overflow-hidden"
                >
                  <input 
                    id="agreement-checkbox"
                    type="checkbox"
                    className="mt-1 w-4 h-4 cursor-pointer text-indigo-600 accent-indigo-600 border-slate-200 dark:border-slate-750 rounded focus:ring-indigo-500/20 focus:ring-4 dark:bg-slate-800"
                    checked={agreed}
                    onChange={e => setAgreed(e.target.checked)}
                    disabled={isLoading}
                  />
                  <label htmlFor="agreement-checkbox" className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed select-none">
                    Я ознакомился и согласен с{' '}
                    <button 
                      type="button"
                      onClick={() => setActiveDoc('agreement')}
                      className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
                    >
                      Пользовательским соглашением
                    </button>{' '}
                    и правилами{' '}
                    <button 
                      type="button"
                      onClick={() => setActiveDoc('offer')}
                      className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
                    >
                      Публичной оферты
                    </button>{' '}
                    системы автоматизации «Кафе Мастер»
                  </label>
                </motion.div>
              )}
            </AnimatePresence>

            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button 
                type="submit" 
                className="w-full py-4 text-base font-black mt-2 btn-shimmer btn-magic rounded-xl border-none shadow-indigo-500/40 dark:shadow-indigo-900/60" 
                disabled={isLoading}
              >
                {isLoading ? 'Загрузка...' : (isRegistering ? 'ЗАРЕГИСТРИРОВАТЬСЯ' : 'ВОЙТИ В СИСТЕМУ')}
              </Button>
            </motion.div>
          </form>

          <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 text-center">
            <button 
              onClick={() => {
                setIsRegistering(!isRegistering);
                setError('');
              }}
              className="text-sm text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 font-bold transition-all duration-300 relative group pb-1"
              disabled={isLoading}
            >
              {isRegistering ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Зарегистрироваться'}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-indigo-500 group-hover:w-full transition-all duration-300" />
            </button>
          </div>
        </Card>

        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-slate-400 dark:text-slate-600 text-xs mt-8 font-medium"
        >
          &copy; 2026 Кафе Мастер. Все права защищены.
        </motion.p>
      </motion.div>

      {/* User Agreement & Public Offer Modal Dialog */}
      <AnimatePresence>
        {activeDoc && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0"
              onClick={() => setActiveDoc(null)}
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl z-10 flex flex-col max-h-[85vh] animate-in fade-in duration-150"
            >
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/45 flex items-center justify-center text-indigo-500 dark:text-indigo-400">
                    <FileText size={20} />
                  </div>
                  <div>
                    <h3 className="text-base md:text-lg font-black text-slate-900 dark:text-white leading-tight">
                      {activeDoc === 'agreement' ? 'Пользовательское соглашение' : 'Договор публичной оферты'}
                    </h3>
                    <p className="text-[9px] md:text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mt-0.5">
                      Система автоматизации заведения «Кафе Мастер»
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveDoc(null)}
                  className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-all active:scale-95"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Scrollable document content */}
              <div className="flex-1 overflow-y-auto pr-2 text-xs md:text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-normal space-y-4 max-h-[50vh] scrollbar-hide scroll-smooth pb-4 select-text">
                {activeDoc === 'agreement' ? (
                  <>
                    <p className="font-bold text-slate-900 dark:text-white mt-1">1. Общие положения</p>
                    <p>
                      Настоящее Пользовательское соглашение (далее — «Соглашение») регулирует порядок использования облачного сервиса «Кафе Мастер» (далее — «Система») конечными пользователями, сотрудниками и клиентами.
                    </p>
                    <p>
                      Проходя процедуру регистрации и отмечая пункт согласия, вы полностью и безоговорочно принимаете условия настоящего документа. В случае несогласия с какими-либо пунктами, пожалуйста, незамедлительно прекратите использование Системы.
                    </p>

                    <p className="font-bold text-slate-900 dark:text-white mt-4">2. Функционал автоматизации и возможности Системы</p>
                    <p>
                      «Кафе Мастер» предоставляет интегрированные цифровые решения для автоматизации ресторанного бизнеса:
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Быстрый прием онлайн-заказов и распределение на Kitchen View («Монитор Кухни»);</li>
                      <li>Контроль состояния запасов на складе и автоматическое информирование о нехватке продукции (Inventory);</li>
                      <li>Личный кабинет лояльности («Виртуальный кошелек / Wallet») с бонусными и реальными счетами;</li>
                      <li>Интегрированная умная ветка поддержки пользователей с ИИ-ассистентом и переводом на живых операторов;</li>
                      <li>Специализированные защищенные внутренние чаты для персонала и системы системных уведомлений.</li>
                    </ul>

                    <p className="font-bold text-slate-900 dark:text-white mt-4">3. Регистрация и Кабинет Пользователя</p>
                    <p>
                      Создавая аккаунт, пользователь обязуется предоставлять точные контактные данные (Имя, Телефон, Логин) и устанавливать устойчивый к подбору пароль. Запрещается создавать учетные записи от лица третьих лиц без их согласия, а также осуществлять автоматизированное сканирование портов или внедрение вредоносных кодов в базы данных Firestore.
                    </p>

                    <p className="font-bold text-slate-900 dark:text-white mt-4">4. Конфиденциальность персональной информации</p>
                    <p>
                      Система обрабатывает данные пользователей строго в рамках обеспечения функций приема заказов, поддержки и авторизации. Логины, пароли (в виде надежных хешей) и кошельки зашифрованы с использованием сертификатов безопасности и не передаются внешним рекламодателям или маркетинговым агрегаторам.
                    </p>

                    <p className="font-bold text-slate-900 dark:text-white mt-4">5. Ограничение ответственности</p>
                    <p>
                      Платформа предоставляется на условиях «как есть (as is)». Администрация не несет ответственности за перебои в доступе к интернету у провайдеров, однако прилагает максимальные усилия к резервированию каналов передачи данных и обеспечению оффлайн-синхронизации баз данных.
                    </p>
                  </>
                ) : (
                  <>
                    <p className="font-bold text-slate-900 dark:text-white mt-1">1. Предмет публичной оферты</p>
                    <p>
                      Настоящий Договор-оферта представляет собой публичное предложение заведения общественного питания и платформы «Кафе Мастер» по дистанционному оформлению заказов на продукцию меню, применению промокодов и ведению программ лояльности на изложенных ниже условиях.
                    </p>
                    <p>
                      Безусловным акцептом настоящей оферты со стороны Покупателя считается завершение регистрации и/или проведение любого платежа в системе Wallet.
                    </p>

                    <p className="font-bold text-slate-900 dark:text-white mt-4">2. Виртуальный кошелек, баланс и программа бонусов</p>
                    <p>
                      В рамках учетной записи каждому пользователю выделяется Личный Кошелек (Wallet), состоящий из основного рублевого баланса и бонусного субсчета:
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Пополнение основного баланса кошелька осуществляется тестовыми или одобренными реальными платежными шлюзами;</li>
                      <li>Бонусные баллы начисляются как кешбэк за привлечение друзей, применение промокодов или объемы покупок;</li>
                      <li>Накопленные бонусы могут отовариваться во время заказа на скидку до 100% от стоимости блюд, но не подлежат выдаче наличными деньгами.</li>
                    </ul>

                    <p className="font-bold text-slate-900 dark:text-white mt-4">3. Политика оформления, отмены и возврата средств (Refund)</p>
                    <p>
                      Пользователь соглашается со следующими условиями управления заказами:
                    </p>
                    <p>
                      Отмена заказа с полным возвратом стоимости на баланс кошелька возможна исключительно в период, пока заказ находится в статусе Ожидания («pending»). Если повар на кухне зафиксировал перевод в статус Готовки («cooking»), отмена становится невозможной в связи с началом расходования физических ингредиентов.
                    </p>

                    <p className="font-bold text-slate-900 dark:text-white mt-4">4. Промокоды и Скидки</p>
                    <p>
                      Все промокоды, активируемые в Панели лояльности, имеют ограниченный срок действия и максимальный лимит использований. Организатор оставляет за собой право блокировать подозрительные учетные записи при обнаружении уязвимостей, попытках злоупотребления промо-бюджетом или мультиаккаунтинге.
                    </p>

                    <p className="font-bold text-slate-900 dark:text-white mt-4">5. Обращения и споры</p>
                    <p>
                      В случае возникновения затруднений с начислением средств, некорректным списанием или некачественным приготовлением блюд кухней, пользователь должен обратиться в Чат поддержки (Support Chat). Большинство конфликтных ситуаций урегулируется в течение нескольких минут через тикет-систему или службу операторов.
                    </p>
                  </>
                )}
              </div>

              {/* Confirm & Close controls */}
              <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end">
                <Button
                  type="button"
                  onClick={() => {
                    setAgreed(true);
                    setActiveDoc(null);
                  }}
                  className="px-6 py-3.5 text-xs font-bold text-white bg-indigo-650 hover:bg-indigo-700 dark:bg-indigo-600 dark:hover:bg-indigo-500 rounded-xl active:scale-95 transition-all shadow-md shadow-indigo-600/10"
                >
                  ПРИНЯТЬ УСЛОВИЯ
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

