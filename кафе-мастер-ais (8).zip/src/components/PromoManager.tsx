import React, { useState } from 'react';
import { PromoCode, Staff } from '../types';
import { Card, Button, Input } from './UI';
import { Tag, Plus, Trash2, Edit2, CheckCircle2, XCircle, Search, Calendar, Hash } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface PromoManagerProps {
  promoCodes: PromoCode[];
  updatePromoCode: (promo: PromoCode) => Promise<void>;
  deletePromoCode: (id: string) => Promise<void>;
  generateId: () => string;
}

export default function PromoManager({ promoCodes, updatePromoCode, deletePromoCode, generateId }: PromoManagerProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [formData, setFormData] = useState<Partial<PromoCode>>({
    code: '',
    discountPercent: 10,
    maxDiscount: 500,
    isActive: true,
    usageCount: 0,
    maxUsages: 100
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.code || !formData.discountPercent) return;

    const promo: PromoCode = {
      id: editingId || generateId(),
      code: formData.code.toUpperCase().replace(/\s/g, ''),
      discountPercent: Number(formData.discountPercent),
      maxDiscount: formData.maxDiscount ? Number(formData.maxDiscount) : undefined,
      isActive: formData.isActive ?? true,
      usageCount: formData.usageCount ?? 0,
      maxUsages: formData.maxUsages ? Number(formData.maxUsages) : undefined,
      expiryDate: formData.expiryDate
    };

    await updatePromoCode(promo);
    setIsAdding(false);
    setEditingId(null);
    setFormData({
      code: '',
      discountPercent: 10,
      maxDiscount: 500,
      isActive: true,
      usageCount: 0,
      maxUsages: 100
    });
  };

  const handleEdit = (promo: PromoCode) => {
    setFormData(promo);
    setEditingId(promo.id);
    setIsAdding(true);
  };

  const filteredPromos = promoCodes.filter(p => 
    p.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <Input 
            placeholder="Поиск промокода..." 
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button onClick={() => setIsAdding(true)} className="w-full sm:w-auto">
          <Plus size={18} />
          Создать промокод
        </Button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className="p-6">
              <h3 className="text-lg font-bold mb-4 dark:text-white">
                {editingId ? 'Редактировать промокод' : 'Новый промокод'}
              </h3>
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Код (Секретное слово)</label>
                  <Input 
                    value={formData.code || ''}
                    onChange={(e) => setFormData({...formData, code: e.target.value})}
                    placeholder="SUMMER2026"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Скидка (%)</label>
                  <Input 
                    type="number"
                    min="1"
                    max="100"
                    value={formData.discountPercent ?? ''}
                    onChange={(e) => setFormData({...formData, discountPercent: Number(e.target.value)})}
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Макс. скидка (₽)</label>
                  <Input 
                    type="number"
                    value={formData.maxDiscount ?? ''}
                    onChange={(e) => setFormData({...formData, maxDiscount: Number(e.target.value)})}
                    placeholder="Напр. 500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Макс. использований</label>
                  <Input 
                    type="number"
                    value={formData.maxUsages ?? ''}
                    onChange={(e) => setFormData({...formData, maxUsages: Number(e.target.value)})}
                    placeholder="Напр. 100"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Дата истечения</label>
                  <Input 
                    type="date"
                    value={formData.expiryDate ? new Date(formData.expiryDate).toISOString().split('T')[0] : ''}
                    onChange={(e) => setFormData({...formData, expiryDate: e.target.value ? new Date(e.target.value).getTime() : undefined})}
                  />
                </div>
                <div className="flex items-end gap-2">
                  <Button type="submit" className="flex-1">
                    {editingId ? 'Сохранить' : 'Создать'}
                  </Button>
                  <Button variant="secondary" onClick={() => {setIsAdding(false); setEditingId(null);}}>
                    Отмена
                  </Button>
                </div>
              </form>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredPromos.map(promo => (
          <Card key={promo.id} className="p-4 border-l-4 border-l-indigo-500">
            <div className="flex justify-between items-start mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-xl font-black text-slate-900 dark:text-white tracking-widest uppercase">{promo.code}</h4>
                  {promo.isActive ? (
                    <span className="bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">Активен</span>
                  ) : (
                    <span className="bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">Отключен</span>
                  )}
                </div>
                <p className="text-3xl font-black text-indigo-600 dark:text-indigo-400 mt-1">-{promo.discountPercent}%</p>
              </div>
              <div className="flex gap-1">
                <button 
                  onClick={() => handleEdit(promo)}
                  className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
                >
                  <Edit2 size={16} />
                </button>
                <button 
                  onClick={() => deletePromoCode(promo.id)}
                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-slate-50 dark:border-slate-800">
              <div className="space-y-1">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Лимит скидки</p>
                <p className="text-sm font-medium dark:text-slate-200">{promo.maxDiscount ? `${promo.maxDiscount} ₽` : 'Безлимит'}</p>
              </div>
              <div className="space-y-1">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Использовано</p>
                <p className="text-sm font-medium dark:text-slate-200">
                  {promo.usageCount} {promo.maxUsages ? `/ ${promo.maxUsages}` : ''}
                </p>
              </div>
              {promo.expiryDate && (
                <div className="space-y-1 col-span-2">
                  <p className="text-[10px] font-bold text-slate-400 uppercase">Действует до</p>
                  <div className="flex items-center gap-2 text-sm font-medium dark:text-slate-200">
                    <Calendar size={14} className="text-slate-400" />
                    {new Date(promo.expiryDate).toLocaleDateString()}
                  </div>
                </div>
              )}
            </div>

            <Button 
              variant="secondary" 
              className="w-full mt-4 text-xs h-9"
              onClick={() => updatePromoCode({...promo, isActive: !promo.isActive})}
            >
              {promo.isActive ? <XCircle size={14} /> : <CheckCircle2 size={14} />}
              {promo.isActive ? 'Деактивировать' : 'Активировать'}
            </Button>
          </Card>
        ))}

        {filteredPromos.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-400">
            <Tag size={48} className="mx-auto mb-4 opacity-10" />
            <p>Промокоды не найдены</p>
          </div>
        )}
      </div>
    </div>
  );
}
