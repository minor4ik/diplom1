import React, { useState } from 'react';
import { Plus, Search, Trash2, Edit2, X, Utensils, Pizza, Coffee, PieChart, Soup, Clock, Scale } from 'lucide-react';
import { Dish } from '../types';
import { Card, Button, cn } from './UI';
import { motion, AnimatePresence } from 'motion/react';

interface MenuManagerProps {
  dishes: Dish[];
  updateDish: (dish: Dish) => Promise<void>;
  deleteDish: (id: string) => Promise<void>;
}

export default function MenuManager({ dishes, updateDish, deleteDish }: MenuManagerProps) {
  const [search, setSearch] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingDish, setEditingDish] = useState<Dish | null>(null);
  const [newDish, setNewDish] = useState<Partial<Dish>>({
    name: '',
    category: 'Роллы',
    price: 0,
    description: '',
    available: true,
    ingredients: [],
    prepTime: 15,
    weight: 200
  });

  const filteredDishes = dishes.filter(d => 
    (d.name || '').toLowerCase().includes(search.toLowerCase()) ||
    (d.category || '').toLowerCase().includes(search.toLowerCase())
  );

  const handleAddDish = async () => {
    if (!newDish.name || !newDish.price) return;
    const dish: Dish = {
      id: Math.random().toString(36).substr(2, 9),
      name: newDish.name!,
      category: newDish.category!,
      price: Number(newDish.price),
      description: newDish.description || '',
      available: true,
      ingredients: [],
      prepTime: Number(newDish.prepTime) || 15,
      weight: Number(newDish.weight) || 200
    };
    
    try {
      await updateDish(dish);
      setIsAdding(false);
      setNewDish({ name: '', category: 'Роллы', price: 0, description: '', available: true, ingredients: [], prepTime: 15, weight: 200 });
    } catch (error) {
      console.error('Ошибка при добавлении блюда:', error);
      alert('Ошибка при сохранении блюда. Попробуйте снова.');
    }
  };

  const handleUpdateDish = async () => {
    if (!editingDish || !editingDish.name || !editingDish.price) return;
    
    try {
      await updateDish(editingDish);
      setEditingDish(null);
    } catch (error) {
      console.error('Ошибка при обновлении блюда:', error);
      alert('Ошибка при обновлении данных. Попробуйте снова.');
    }
  };

  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    try {
      await deleteDish(id);
      setDeletingId(null);
    } catch (error) {
      console.error('Ошибка при удалении блюда:', error);
      alert('Ошибка при удалении. Попробуйте снова.');
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Пицца': return <Pizza size={24} />;
      case 'Роллы': return <Utensils size={24} />;
      case 'Напитки': return <Coffee size={24} />;
      case 'Десерты': return <PieChart size={24} />;
      case 'Закуски': return <Soup size={24} />;
      default: return <Utensils size={24} />;
    }
  };

  const getCategoryStyles = (category: string) => {
    switch (category) {
      case 'Пицца': return 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400 border-orange-200 dark:border-orange-900/40';
      case 'Роллы': return 'bg-rose-100 dark:bg-rose-900/30 text-rose-700 dark:text-rose-400 border-rose-200 dark:border-rose-900/40';
      case 'Напитки': return 'bg-sky-100 dark:bg-sky-900/30 text-sky-700 dark:text-sky-400 border-sky-200 dark:border-sky-900/40';
      case 'Десерты': return 'bg-pink-100 dark:bg-pink-900/30 text-pink-700 dark:text-pink-400 border-pink-200 dark:border-pink-900/40';
      case 'Закуски': return 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/40';
      default: return 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Поиск блюда или категории..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all placeholder:text-slate-400"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Button onClick={() => setIsAdding(true)}>
          <Plus size={18} />
          Добавить блюдо
        </Button>
      </div>

      {isAdding && (
        <Card className="p-4 sm:p-6 border-2 border-indigo-100 dark:border-indigo-900/30 bg-indigo-50/30 dark:bg-indigo-900/20">
          <div className="flex justify-between items-center mb-4 sm:mb-6">
            <h3 className="text-lg font-bold dark:text-white">Новое блюдо</h3>
            <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
              <X size={20} />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Название</label>
              <input 
                type="text" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20"
                value={newDish.name || ''}
                onChange={e => setNewDish({...newDish, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Категория</label>
              <select 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20"
                value={newDish.category || 'Роллы'}
                onChange={e => setNewDish({...newDish, category: e.target.value})}
              >
                <option className="dark:bg-slate-900">Роллы</option>
                <option className="dark:bg-slate-900">Пицца</option>
                <option className="dark:bg-slate-900">Напитки</option>
                <option className="dark:bg-slate-900">Десерты</option>
                <option className="dark:bg-slate-900">Закуски</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Цена (₽)</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20"
                value={newDish.price ?? 0}
                onChange={e => setNewDish({...newDish, price: Number(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Время приготовления (мин)</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20"
                value={newDish.prepTime ?? 0}
                onChange={e => setNewDish({...newDish, prepTime: Number(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Вес (г)</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20"
                value={newDish.weight ?? 0}
                onChange={e => setNewDish({...newDish, weight: Number(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Описание</label>
              <input 
                type="text" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20"
                value={newDish.description || ''}
                onChange={e => setNewDish({...newDish, description: e.target.value})}
              />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setIsAdding(false)}>Отмена</Button>
            <Button onClick={handleAddDish}>Сохранить</Button>
          </div>
        </Card>
      )}

      {editingDish && (
        <Card className="p-4 sm:p-6 border-2 border-amber-100 dark:border-amber-900/30 bg-amber-50/30 dark:bg-amber-900/20">
          <div className="flex justify-between items-center mb-4 sm:mb-6">
            <h3 className="text-lg font-bold dark:text-white">Редактировать блюдо</h3>
            <button onClick={() => setEditingDish(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
              <X size={20} />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Название</label>
              <input 
                type="text" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500/20"
                value={editingDish.name || ''}
                onChange={e => setEditingDish(prev => prev ? {...prev, name: e.target.value} : null)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Категория</label>
              <select 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500/20"
                value={editingDish.category || 'Роллы'}
                onChange={e => setEditingDish({...editingDish, category: e.target.value})}
              >
                <option className="dark:bg-slate-900">Роллы</option>
                <option className="dark:bg-slate-900">Пицца</option>
                <option className="dark:bg-slate-900">Напитки</option>
                <option className="dark:bg-slate-900">Десерты</option>
                <option className="dark:bg-slate-900">Закуски</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Цена (₽)</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500/20"
                value={editingDish.price ?? 0}
                onChange={e => setEditingDish({...editingDish, price: Number(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Время приготовления (мин)</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500/20"
                value={editingDish.prepTime ?? 0}
                onChange={e => setEditingDish({...editingDish, prepTime: Number(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Вес (г)</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500/20"
                value={editingDish.weight ?? 0}
                onChange={e => setEditingDish({...editingDish, weight: Number(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Описание</label>
              <input 
                type="text" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500/20"
                value={editingDish.description || ''}
                onChange={e => setEditingDish({...editingDish, description: e.target.value})}
              />
            </div>
            <div className="flex items-center gap-2">
              <input 
                type="checkbox" 
                id="edit-available"
                className="w-4 h-4 text-amber-600 rounded border-slate-300 dark:border-slate-700 dark:bg-slate-900 focus:ring-amber-500"
                checked={editingDish.available}
                onChange={e => setEditingDish({...editingDish, available: e.target.checked})}
              />
              <label htmlFor="edit-available" className="text-sm font-medium text-slate-700 dark:text-slate-300">В наличии</label>
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setEditingDish(null)}>Отмена</Button>
            <Button onClick={handleUpdateDish} className="bg-amber-600 hover:bg-amber-700">Обновить</Button>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {filteredDishes.map((dish) => (
            <motion.div
              key={dish.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.2 }}
            >
              <Card className={cn(
                "h-full hover:shadow-lg transition-all border-slate-100 dark:border-slate-800 flex flex-col group relative overflow-hidden",
                !dish.available && "opacity-75"
              )}>
                {!dish.available && (
                  <div className="absolute top-2 right-2 z-10">
                    <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-sm uppercase">
                      Нет в наличии
                    </span>
                  </div>
                )}
                
                <div className="p-6 flex-1">
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn(
                      "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors duration-300 border",
                      dish.available 
                        ? "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 border-indigo-100 dark:border-indigo-900/40 group-hover:bg-indigo-600 dark:group-hover:bg-indigo-500 group-hover:text-white" 
                        : "bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-600 border-slate-200 dark:border-slate-800"
                    )}>
                      {getCategoryIcon(dish.category)}
                    </div>
                    <span className={cn(
                      "px-2.5 py-1 rounded-full border text-[10px] font-black uppercase tracking-widest",
                      getCategoryStyles(dish.category)
                    )}>
                      {dish.category}
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1 line-clamp-1">{dish.name}</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 h-10">{dish.description}</p>

                  <div className="flex items-center justify-between mb-4">
                    <div className="text-2xl font-black text-slate-900 dark:text-white">
                      {dish.price} <span className="text-sm font-normal text-slate-400 dark:text-slate-600">₽</span>
                    </div>
                    <div className="flex gap-3">
                      <div className="flex items-center gap-1 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase">
                        <Clock size={12} className="text-indigo-400 dark:text-indigo-500" />
                        {dish.prepTime} мин
                      </div>
                      <div className="flex items-center gap-1 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase">
                        <Scale size={12} className="text-indigo-400 dark:text-indigo-500" />
                        {dish.weight} г
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-50/50 dark:bg-slate-900/50 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                  {deletingId === dish.id ? (
                    <div className="flex-1 flex gap-2 animate-in fade-in zoom-in duration-200">
                      <Button 
                        variant="secondary" 
                        className="flex-1 py-2 text-xs bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 border-red-100 dark:border-red-900/30 hover:bg-red-100 dark:hover:bg-red-900/40"
                        onClick={() => handleDelete(dish.id)}
                      >
                        Удалить?
                      </Button>
                      <Button 
                        variant="secondary" 
                        className="flex-1 py-2 text-xs bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700"
                        onClick={() => setDeletingId(null)}
                      >
                        Отмена
                      </Button>
                    </div>
                  ) : (
                    <>
                      <Button 
                        variant="secondary" 
                        className="flex-1 py-2 text-xs gap-1.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 shadow-sm"
                        onClick={() => setEditingDish(dish)}
                      >
                        <Edit2 size={14} />
                        Изменить
                      </Button>
                      <Button 
                        variant="secondary" 
                        className="aspect-square p-0 flex items-center justify-center text-slate-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-sm"
                        onClick={() => setDeletingId(dish.id)}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </>
                  )}
                </div>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filteredDishes.length === 0 && (
        <div className="text-center py-20 bg-slate-50 dark:bg-slate-900/50 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800">
          <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center text-slate-400 dark:text-slate-600 mx-auto mb-4">
            <Utensils size={32} />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Блюда не найдены</h3>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Попробуйте изменить параметры поиска</p>
        </div>
      )}
    </div>
  );
}
