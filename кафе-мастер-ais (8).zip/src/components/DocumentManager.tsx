import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, 
  Plus, 
  Trash2, 
  Download, 
  Send, 
  UserPlus, 
  UserMinus, 
  BookOpen, 
  Check, 
  X, 
  Clock, 
  User, 
  Search, 
  FileSignature, 
  AlertCircle,
  TrendingUp,
  FileCheck2,
  Users,
  Briefcase,
  Phone,
  Mail,
  Calendar
} from 'lucide-react';
import { useCafeStore } from '../store';
import { ElectronicDocument, Staff } from '../types';
import { getEffectiveRole } from '../lib/auth';
import { Card, Button } from './UI';

export default function DocumentManager() {
  const { 
    documents, 
    addDocument, 
    updateDocument, 
    deleteDocument, 
    staff, 
    currentUser,
    logAction,
    addNotification
  } = useCafeStore();

  const [activeTab, setActiveTab] = useState<'accounting' | 'hiring' | 'dismissal' | 'candidates' | 'owner' | 'archive'>('accounting');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  
  // Create / Edit modal state
  const [isCreating, setIsCreating] = useState(false);
  const [editingDoc, setEditingDoc] = useState<ElectronicDocument | null>(null);
  
  // Form State
  const [docType, setDocType] = useState<'accounting' | 'hiring' | 'dismissal' | 'candidates' | 'owner' | 'archive'>('accounting');
  const [title, setTitle] = useState('');
  const [employeeName, setEmployeeName] = useState('');
  const [employeeId, setEmployeeId] = useState('');
  const [position, setPosition] = useState('');
  const [salary, setSalary] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [passport, setPassport] = useState('');
  const [inn, setInn] = useState('');
  const [snils, setSnils] = useState('');
  const [hrComment, setHrComment] = useState('');
  const [docStatus, setDocStatus] = useState<'draft' | 'pending_hr' | 'approved' | 'rejected'>('draft');

  // Candidate fields form state
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [resume, setResume] = useState('');
  const [interviewDate, setInterviewDate] = useState('');

  const activeRole = getEffectiveRole(currentUser);
  const isOwner = activeRole === 'owner' || 
                  activeRole === 'developer' || 
                  currentUser?.role === 'owner' ||
                  currentUser?.role === 'developer' ||
                  (currentUser?.position || '').toLowerCase().includes('владелец') ||
                  (currentUser?.position || '').toLowerCase().includes('owner') ||
                  (currentUser?.position || '').toLowerCase().includes('разработчик') ||
                  (currentUser?.position || '').toLowerCase().includes('dev');
                  
  const isHr = activeRole === 'hr' || 
               currentUser?.role === 'hr' ||
               (currentUser?.position || '').toLowerCase().includes('кадр') || 
               (currentUser?.position || '').toLowerCase().includes('hr') ||
               (currentUser?.position || '').toLowerCase().includes('инспектор');
               
  const isAdmin = activeRole === 'admin' || 
                  currentUser?.role === 'admin' ||
                  (currentUser?.position || '').toLowerCase().includes('администратор') ||
                  (currentUser?.position || '').toLowerCase().includes('админ');
                  
  const hasEditRights = isOwner || isHr || isAdmin || 
                        ['owner', 'hr', 'admin', 'developer', 'tech', 'tester'].includes(activeRole) || 
                        ['owner', 'hr', 'admin', 'developer', 'tech', 'tester'].includes(currentUser?.role || '');

  const filteredDocs = documents.filter(doc => {
    const matchesTab = doc.type === activeTab;
    const matchesSearch = doc.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          doc.employeeName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (doc.fields.position || '').toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'all' ? true : doc.status === filterStatus;
    return matchesTab && matchesSearch && matchesStatus;
  });

  // HR Stats calculations
  const totalEmployees = staff.filter(s => s.role !== 'user').length;
  const hiringDocsCount = documents.filter(d => d.type === 'hiring' && d.status === 'approved').length;
  const candidatesDocsCount = documents.filter(d => d.type === 'candidates').length;
  const pendingDocsCount = documents.filter(d => d.status === 'pending_hr').length;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !employeeName) return;

    const finalStatus = hasEditRights ? docStatus : 'pending_hr';

    await addDocument({
      type: docType,
      title,
      employeeName,
      employeeId: employeeId || undefined,
      createdBy: currentUser?.name || 'Система',
      createdById: currentUser?.id || '',
      status: finalStatus, // Custom status choice or default pending
      fields: {
        position,
        salary: salary ? parseFloat(salary) : undefined,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
        reason: reason || undefined,
        notes: notes || undefined,
        passport: passport || undefined,
        inn: inn || undefined,
        snils: snils || undefined,
        phone: phone || undefined,
        email: email || undefined,
        resume: resume || undefined,
        interviewDate: interviewDate || undefined,
      }
    });

    if (finalStatus === 'pending_hr') {
      try {
        await addNotification({
          title: 'Новый документ на рассмотрении',
          message: `Создан кадровый документ "${title}" для ${employeeName}. Требуется рассмотрение.`,
          type: 'info',
          targetRoles: ['owner', 'hr', 'developer']
        });
      } catch (error) {
        console.error('Ошибка при отправке автоматического уведомления:', error);
      }
    }

    logAction(
      currentUser?.id || '',
      currentUser?.name || 'Система',
      currentUser?.role || 'other',
      'Создание документа',
      `Создан электронный документ: ${title} для ${employeeName}`
    );

    // Reset Form
    resetForm();
    setIsCreating(false);
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDoc) return;

    await updateDocument(editingDoc.id, {
      title,
      employeeName,
      employeeId: employeeId || undefined,
      status: docStatus,
      fields: {
        ...editingDoc.fields,
        position,
        salary: salary ? parseFloat(salary) : undefined,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
        reason: reason || undefined,
        notes: notes || undefined,
        passport: passport || undefined,
        inn: inn || undefined,
        snils: snils || undefined,
        hrComment: hrComment || undefined,
        phone: phone || undefined,
        email: email || undefined,
        resume: resume || undefined,
        interviewDate: interviewDate || undefined,
      }
    });

    logAction(
      currentUser?.id || '',
      currentUser?.name || 'Система',
      currentUser?.role || 'other',
      'Изменение документа',
      `Изменены данные документа: ${title}`
    );

    resetForm();
    setEditingDoc(null);
  };

  const resetForm = () => {
    setTitle('');
    setEmployeeName('');
    setEmployeeId('');
    setPosition('');
    setSalary('');
    setStartDate('');
    setEndDate('');
    setReason('');
    setNotes('');
    setPassport('');
    setInn('');
    setSnils('');
    setHrComment('');
    setDocStatus('draft');
    setPhone('');
    setEmail('');
    setResume('');
    setInterviewDate('');
  };

  const startEdit = (doc: ElectronicDocument) => {
    setEditingDoc(doc);
    setDocType(doc.type);
    setTitle(doc.title);
    setEmployeeName(doc.employeeName);
    setEmployeeId(doc.employeeId || '');
    setPosition(doc.fields.position || '');
    setSalary(doc.fields.salary ? doc.fields.salary.toString() : '');
    setStartDate(doc.fields.startDate || '');
    setEndDate(doc.fields.endDate || '');
    setReason(doc.fields.reason || '');
    setNotes(doc.fields.notes || '');
    setPassport(doc.fields.passport || '');
    setInn(doc.fields.inn || '');
    setSnils(doc.fields.snils || '');
    setHrComment(doc.fields.hrComment || '');
    setDocStatus(doc.status);
    setPhone(doc.fields.phone || '');
    setEmail(doc.fields.email || '');
    setResume(doc.fields.resume || '');
    setInterviewDate(doc.fields.interviewDate || '');
  };

  // Convert/Export Document to text for download
  const handleExport = (doc: ElectronicDocument) => {
    const typeLabel = 
      doc.type === 'accounting' ? 'УЧЁТНЫЙ ДОКУМЕНТ' : 
      doc.type === 'hiring' ? 'ПРИНЯТИЕ НА РАБОТУ' : 
      doc.type === 'dismissal' ? 'РАСТОРЖЕНИЕ ДОГОВОРА / УВОЛЬНЕНИЕ' :
      doc.type === 'owner' ? 'ДОКУМЕНТ ВЛАДЕЛЬЦА / КОРПОРАТИВНЫЙ' :
      doc.type === 'archive' ? 'АРХИВНЫЙ ДОКУМЕНТ' :
      'АНКЕТА КАНДИДАТА / НА РАССМОТРЕНИИ';
      
    const statusLabel = 
      doc.status === 'draft' ? 'ЧЕРНОВИК' : 
      doc.status === 'pending_hr' ? 'НА РАССМОТРЕНИИ В ОК' : 
      doc.status === 'approved' ? 'ЭЦП УТВЕРЖДЕНО' : 
      'ОТКЛОНЕНО';
    
    let textContent = `====================================================
           ЭЛЕКТРОННЫЙ КАДРОВЫЙ ДОКУМЕНТ
====================================================
Тип документа: ${typeLabel}
Заголовок: ${doc.title}
Уникальный ID документа: ${doc.id}
Дата создания: ${new Date(doc.createdAt).toLocaleString('ru-RU')}
Создатель: ${doc.createdBy} (ID: ${doc.createdById})
Статус: [ ${statusLabel} ]

ДАННЫЕ СОТРУДНИКА / КАНДИДАТА:
-------------------------------------------
ФИО: ${doc.employeeName}
Должность/Желаемая должность: ${doc.fields.position || 'Не указано'}
Оклад/Ставка/Ожидаемый оклад: ${doc.fields.salary ? doc.fields.salary + ' руб.' : 'Не указан'}
Паспортные данные: ${doc.fields.passport || 'Не указано'}
ИНН: ${doc.fields.inn || 'Не указано'}
СНИЛС: ${doc.fields.snils || 'Не указано'}`;

    if (doc.type === 'hiring') {
      textContent += `\nДата начала работы: ${doc.fields.startDate || 'Не указана'}`;
    } else if (doc.type === 'dismissal') {
      textContent += `\nДата увольнения: ${doc.fields.endDate || 'Не указана'}\nПричина увольнения: ${doc.fields.reason || 'Не указана'}`;
    } else if (doc.type === 'candidates') {
      textContent += `\nТелефон: ${doc.fields.phone || 'Не указан'}\nEmail: ${doc.fields.email || 'Не указан'}\nДата интервью: ${doc.fields.interviewDate || 'Не указано'}\nРезюме: ${doc.fields.resume || 'Не указано'}`;
    } else if (doc.type === 'owner') {
      textContent += `\nВладелец / Руководитель: ${doc.employeeName}\nКонтактные данные: ${doc.fields.phone || 'Не указано'} / ${doc.fields.email || 'Не указано'}`;
    } else if (doc.type === 'archive') {
      textContent += `\nСведения архива: ${doc.fields.notes || 'Не указаны'}`;
    }

    if (doc.fields.notes) {
      textContent += `\n\nДОПОЛНИТЕЛЬНЫЕ ПРИМЕЧАНИЯ:\n${doc.fields.notes}`;
    }

    if (doc.fields.hrComment) {
      textContent += `\n\nКОММЕНТАРИЙ ОТДЕЛА КАДРОВ:\n${doc.fields.hrComment}`;
    }

    textContent += `\n\n====================================================
ЦИФРОВАЯ ПОДПИСЬ И СЕКЬЮРНОСТЬ:
Сервис автоматизации заведения «Кафе Мастер»
Документ верифицирован в облаке Firestore
Штамп времени верификации: ${new Date().toISOString()}
====================================================`;

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${doc.type}_${doc.id}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleStatusChange = async (id: string, status: 'draft' | 'pending_hr' | 'approved' | 'rejected') => {
    await updateDocument(id, { status });
    
    let actionLabel = 'Изменение статуса';
    if (status === 'pending_hr') actionLabel = 'Перенаправление в ОК';
    if (status === 'approved') actionLabel = 'Владелец/HR утвердил документ';
    if (status === 'rejected') actionLabel = 'Владелец/HR отклонил документ';

    logAction(
      currentUser?.id || '',
      currentUser?.name || 'Система',
      currentUser?.role || 'other',
      actionLabel,
      `Статус документа ID ${id} изменен на ${status}`
    );
  };

  const selectEmployee = (id: string) => {
    const selected = staff.find(s => s.id === id);
    if (selected) {
      setEmployeeId(selected.id);
      setEmployeeName(selected.name);
      setPosition(selected.position);
    }
  };

  return (
    <div className="space-y-6">
      {/* Кадровый учет Stats Bento Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-3xl flex items-center gap-4 shadow-sm relative overflow-hidden group">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/45 flex items-center justify-center text-indigo-500 shrink-0">
            <Users size={22} className="group-hover:scale-110 transition-transform" />
          </div>
          <div>
            <span className="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Кадровый Учет</span>
            <h4 className="text-xl font-black text-slate-900 dark:text-white mt-1 leading-none">{totalEmployees} сотр.</h4>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-3xl flex items-center gap-4 shadow-sm relative overflow-hidden group">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/45 flex items-center justify-center text-emerald-500 shrink-0">
            <UserPlus size={22} className="group-hover:scale-110 transition-transform" />
          </div>
          <div>
            <span className="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Принятые</span>
            <h4 className="text-xl font-black text-slate-900 dark:text-white mt-1 leading-none">{hiringDocsCount} указ.</h4>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-3xl flex items-center gap-4 shadow-sm relative overflow-hidden group">
          <div className="w-12 h-12 rounded-2xl bg-teal-50 dark:bg-teal-950/45 flex items-center justify-center text-teal-650 shrink-0">
            <Briefcase size={22} className="group-hover:scale-110 transition-transform" />
          </div>
          <div>
            <span className="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Кандидаты</span>
            <h4 className="text-xl font-black text-slate-900 dark:text-white mt-1 leading-none">{candidatesDocsCount} указ.</h4>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-5 rounded-3xl flex items-center gap-4 shadow-sm relative overflow-hidden group">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 dark:bg-amber-950/45 flex items-center justify-center text-amber-500 shrink-0">
            <Clock size={22} className="group-hover:scale-110 transition-transform" />
          </div>
          <div>
            <span className="text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">На рассмотрении ОК</span>
            <h4 className="text-xl font-black text-slate-900 dark:text-white mt-1 leading-none">{pendingDocsCount} док.</h4>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
        
        {/* Module Header / Filters */}
        <div className="p-6 md:p-8 border-b border-slate-100 dark:border-slate-800 flex flex-col gap-6">
          <div id="document-manager-header" className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white pb-1 leading-tight">Цифровые документы</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Электронные карточки учета персонала, анкетирование кандидатов, приказы о приеме и увольнениях
              </p>
            </div>
            
            {(hasEditRights || isOwner || isHr || ['owner', 'hr', 'developer', 'admin', 'tech', 'tester'].includes(activeRole) || ['owner', 'hr', 'developer', 'admin', 'tech', 'tester'].includes(currentUser?.role || '')) && (
              <Button 
                id="add-document-btn"
                onClick={() => { setIsCreating(true); resetForm(); }}
                className="w-full md:w-auto px-5 py-3 text-xs bg-indigo-600 hover:bg-indigo-750 text-white font-bold tracking-wide rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2 shrink-0 transition-transform active:scale-95"
              >
                <Plus size={16} />
                Добавить документ
              </Button>
            )}
          </div>

          {/* Categories Tabs */}
          <div className="flex border-b border-slate-100 dark:border-slate-850 gap-2 overflow-x-auto pb-1 scrollbar-hide">
            <button
              onClick={() => { setActiveTab('accounting'); setFilterStatus('all'); }}
              className={`pb-3 px-4 text-xs font-bold transition-all relative border-b-2 whitespace-nowrap outline-none ${
                activeTab === 'accounting' 
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-black' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Кадровый учет
            </button>
            <button
              onClick={() => { setActiveTab('hiring'); setFilterStatus('all'); }}
              className={`pb-3 px-4 text-xs font-bold transition-all relative border-b-2 whitespace-nowrap outline-none ${
                activeTab === 'hiring' 
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-black' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Принятие на работу
            </button>
            <button
              onClick={() => { setActiveTab('dismissal'); setFilterStatus('all'); }}
              className={`pb-3 px-4 text-xs font-bold transition-all relative border-b-2 whitespace-nowrap outline-none ${
                activeTab === 'dismissal' 
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-black' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Увольнения
            </button>
            <button
              onClick={() => { setActiveTab('candidates'); setFilterStatus('all'); }}
              className={`pb-3 px-4 text-xs font-bold transition-all relative border-b-2 whitespace-nowrap outline-none ${
                activeTab === 'candidates' 
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-black' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Кандидаты / На рассмотрении
            </button>
            <button
              onClick={() => { setActiveTab('owner'); setFilterStatus('all'); }}
              className={`pb-3 px-4 text-xs font-bold transition-all relative border-b-2 whitespace-nowrap outline-none ${
                activeTab === 'owner' 
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-black' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Документы владельца
            </button>
            <button
              onClick={() => { setActiveTab('archive'); setFilterStatus('all'); }}
              className={`pb-3 px-4 text-xs font-bold transition-all relative border-b-2 whitespace-nowrap outline-none ${
                activeTab === 'archive' 
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-black' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Архив
            </button>
          </div>

          {/* Filtering row */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input
                type="text"
                placeholder="Поиск по имени, должности, ключевым словам..."
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/20"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
            </div>
            
            <select
              className="px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-505/20 min-w-44"
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
            >
              <option value="all">Все статусы</option>
              <option value="draft">Черновики</option>
              <option value="pending_hr">На рассмотрении</option>
              <option value="approved">Утверждено</option>
              <option value="rejected">Отклонено</option>
            </select>
          </div>
        </div>

        {/* Documents Grid / List */}
        <div className="p-6 md:p-8">
          {filteredDocs.length === 0 ? (
            <div className="text-center py-16 flex flex-col items-center">
              <div className="w-14 h-14 rounded-full bg-slate-50 dark:bg-slate-800/50 flex items-center justify-center text-slate-400 mb-4 border border-dashed border-slate-200 dark:border-slate-750">
                <FileText size={22} />
              </div>
              <h3 className="text-md font-bold text-slate-900 dark:text-white">Нет документов</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-sm">
                В этой категории документов не найдено. Создайте новый электронный документ или измените поисковой запрос.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredDocs.map(doc => {
                const isDraft = doc.status === 'draft';
                const isPending = doc.status === 'pending_hr';
                const isApproved = doc.status === 'approved';
                const isRejected = doc.status === 'rejected';

                return (
                  <motion.div
                    key={doc.id}
                    layoutId={`doc-card-${doc.id}`}
                    className={`border rounded-2xl p-5 shadow-sm hover:shadow-md transition-all relative flex flex-col justify-between ${
                      isApproved 
                        ? 'border-emerald-100 dark:border-emerald-95 bg-emerald-50/10 dark:bg-emerald-950/5' 
                        : isRejected 
                        ? 'border-red-100 dark:border-red-95 bg-red-50/10' 
                        : isPending 
                        ? 'border-amber-100 dark:border-amber-95 bg-amber-50/10' 
                        : 'border-slate-100 dark:border-slate-800'
                    }`}
                  >
                    <div>
                      {/* Badge status */}
                      <div className="flex items-center justify-between mb-3">
                        <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                          isApproved 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : isRejected 
                            ? 'bg-red-100 text-red-800' 
                            : isPending 
                            ? 'bg-amber-100 text-amber-800' 
                            : 'bg-slate-100 text-slate-600'
                        }`}>
                          {isDraft && 'Черновик'}
                          {isPending && 'На рассмотрении'}
                          {isApproved && 'Утверждено'}
                          {isRejected && 'Отклонено'}
                        </span>
                        
                        <div className="flex gap-1">
                          <button
                            onClick={() => handleExport(doc)}
                            className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50/45 dark:hover:bg-indigo-950/20 rounded-lg transition-all"
                            title="Выгрузить / Экспорт"
                          >
                            <Download size={15} />
                          </button>
                          
                          {hasEditRights && (
                            <button
                              onClick={() => startEdit(doc)}
                              className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50/45 dark:hover:bg-indigo-950/20 rounded-lg transition-all"
                              title="Редактировать"
                            >
                              <FileSignature size={15} />
                            </button>
                          )}

                          {(isOwner || isHr) && (
                            <button
                              onClick={() => deleteDocument(doc.id)}
                              className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50/45 dark:hover:bg-red-950/20 rounded-lg transition-all"
                              title="Удалить"
                            >
                              <Trash2 size={15} />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Header title */}
                      <h3 className="text-sm font-black text-slate-900 dark:text-white line-clamp-1">{doc.title}</h3>
                      <p className="text-[10px] text-slate-400 font-medium">Создан: {new Date(doc.createdAt).toLocaleDateString('ru-RU')} • автор {doc.createdBy}</p>

                      {/* Fields details */}
                      <div className="mt-4 pt-3 border-t border-dashed border-slate-100 dark:border-slate-800 space-y-2">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-slate-400">Сотрудник:</span>
                          <span className="font-bold text-slate-800 dark:text-slate-200">{doc.employeeName}</span>
                        </div>
                        {doc.fields.position && (
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-slate-400">Должность:</span>
                            <span className="font-medium text-slate-700 dark:text-slate-300">{doc.fields.position}</span>
                          </div>
                        )}
                        {doc.fields.salary !== undefined && (
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-slate-400">Оклад / Ставка:</span>
                            <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{doc.fields.salary.toLocaleString()} руб.</span>
                          </div>
                        )}
                        {doc.type === 'hiring' && doc.fields.startDate && (
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-slate-400">Дата приема:</span>
                            <span className="font-medium text-indigo-600 dark:text-indigo-400">{doc.fields.startDate}</span>
                          </div>
                        )}
                        {doc.type === 'dismissal' && (
                          <>
                            {doc.fields.endDate && (
                              <div className="flex justify-between items-center text-xs">
                                <span className="text-slate-400">Дата увольнения:</span>
                                <span className="font-medium text-red-500">{doc.fields.endDate}</span>
                              </div>
                            )}
                            {doc.fields.reason && (
                              <div className="bg-red-50/50 dark:bg-red-950/10 p-2 rounded-lg text-[11px] text-red-600 dark:text-red-400 border border-red-100/50 dark:border-red-950/20 mt-1 italic">
                                Причина: {doc.fields.reason}
                              </div>
                            )}
                          </>
                        )}
                        
                        {doc.type === 'candidates' && (
                          <>
                            {doc.fields.phone && (
                              <div className="flex justify-between items-center text-xs">
                                <span className="text-slate-400">Телефон:</span>
                                <span className="font-medium text-slate-700 dark:text-slate-300">{doc.fields.phone}</span>
                              </div>
                            )}
                            {doc.fields.email && (
                              <div className="flex justify-between items-center text-xs">
                                <span className="text-slate-400">Email:</span>
                                <span className="font-medium text-slate-700 dark:text-slate-300">{doc.fields.email}</span>
                              </div>
                            )}
                            {doc.fields.interviewDate && (
                              <div className="flex justify-between items-center text-xs">
                                <span className="text-slate-400">Интервью назначенное:</span>
                                <span className="font-medium text-amber-600 dark:text-amber-400">
                                  {new Date(doc.fields.interviewDate).toLocaleString('ru-RU')}
                                </span>
                              </div>
                            )}
                            {doc.fields.resume && (
                              <div className="bg-slate-50 dark:bg-slate-800/40 p-2 rounded-lg text-[11px] text-slate-600 dark:text-slate-400 border border-slate-100/30 mt-1 italic whitespace-pre-wrap">
                                Резюме: {doc.fields.resume}
                              </div>
                            )}
                          </>
                        )}

                        {doc.type !== 'candidates' && (
                          <>
                            {doc.fields.passport && (
                              <div className="text-[10px] text-slate-400">Паспорт: {doc.fields.passport}</div>
                            )}
                            {(doc.fields.inn || doc.fields.snils) && (
                              <div className="text-[10px] text-slate-400 flex flex-wrap gap-2 text-xs">
                                {doc.fields.inn && <span>ИНН: {doc.fields.inn}</span>}
                                {doc.fields.snils && <span>СНИЛС: {doc.fields.snils}</span>}
                              </div>
                            )}
                          </>
                        )}

                        {doc.fields.notes && (
                          <div className="text-[11px] text-slate-500 italic mt-2 line-clamp-3">Примечания: {doc.fields.notes}</div>
                        )}

                        {doc.fields.hrComment && (
                          <div className="bg-indigo-50/45 dark:bg-indigo-950/25 p-2 rounded-xl text-[11px] text-indigo-700 dark:text-indigo-300 border border-indigo-100/40 mt-1">
                            <span className="font-bold">Комментарий ОК:</span> {doc.fields.hrComment}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Flow & Actions */}
                    <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-2 items-center justify-between">
                      <div className="flex gap-2">
                        {/* Owner redirect to HR */}
                        {isOwner && isDraft && (
                          <button
                            onClick={() => handleStatusChange(doc.id, 'pending_hr')}
                            className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-650 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-all active:scale-95 border border-indigo-100"
                          >
                            <Send size={12} />
                            Направить в ОК
                          </button>
                        )}

                        {/* HR approve / reject buttons */}
                        {(isHr || isOwner) && isPending && (
                          <>
                            <button
                              onClick={() => handleStatusChange(doc.id, 'approved')}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-black uppercase tracking-wide flex items-center gap-1 cursor-pointer transition-all active:scale-95 shadow-sm"
                            >
                              <Check size={12} />
                              Утвердить
                            </button>
                            <button
                              onClick={() => handleStatusChange(doc.id, 'rejected')}
                              className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg text-[10px] font-black uppercase tracking-wide flex items-center gap-1 cursor-pointer transition-all active:scale-95"
                            >
                              <X size={12} />
                              Отклонить
                            </button>
                          </>
                        )}
                      </div>

                      {/* Signature Digital Blue Stamp */}
                      {isApproved && (
                        <div className="flex items-center gap-1 rounded border border-emerald-500/45 px-1.5 py-0.5 text-emerald-600 bg-emerald-50/50 select-none uppercase font-mono font-black text-[9px] tracking-tighter shrink-0 rotate-1">
                          <FileSignature size={12} />
                          ЭЦП Подписано
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* CREATE OR EDIT MODAL DIALOG */}
      <AnimatePresence>
        {(isCreating || editingDoc) && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0"
              onClick={() => { setIsCreating(false); setEditingDoc(null); }}
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl z-10 flex flex-col max-h-[90vh] animate-in fade-in duration-150 overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/45 flex items-center justify-center text-indigo-500 dark:text-indigo-400">
                    <FileText size={20} />
                  </div>
                  <div>
                    <h3 className="text-base md:text-lg font-black text-slate-900 dark:text-white leading-tight">
                      {isCreating ? 'Новый цифровой документ' : 'Редактировать документ'}
                    </h3>
                    <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mt-0.5">
                      {isCreating ? 'Создание и учет шаблонов' : 'Изменение полей договора'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => { setIsCreating(false); setEditingDoc(null); }}
                  className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-all active:scale-95 cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Form Content */}
              <form onSubmit={isCreating ? handleCreate : handleUpdate} className="space-y-4">
                
                {isCreating && (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-350">Категория документа</label>
                    <select
                      className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none"
                      value={docType}
                      onChange={e => setDocType(e.target.value as any)}
                    >
                      <option value="accounting">Карточка учета (Профиль / Налоги)</option>
                      <option value="hiring">Приказ / Принятие на работу</option>
                      <option value="dismissal">Расторжение контракта / Увольнение</option>
                      <option value="candidates">Кандидат / На рассмотрении</option>
                      <option value="owner">Документы владельца</option>
                      <option value="archive">Архив</option>
                    </select>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-355">Название документа</label>
                  <input
                    type="text"
                    required
                    placeholder="Например: Приказ о назначении №10 или Карточка учета №01"
                    className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/10"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-355">Связать с сотрудником</label>
                    <select
                      className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-855 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none"
                      value={employeeId}
                      onChange={e => selectEmployee(e.target.value)}
                    >
                      <option value="">-- Новый / Без учетной записи --</option>
                      {staff.filter(s => s.role !== 'user').map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.position})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-355">ФИО сотрудника / Кандидата</label>
                    <input
                      type="text"
                      required
                      placeholder="Иванов Иван Иванович"
                      className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/10"
                      value={employeeName}
                      onChange={e => setEmployeeName(e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-355">Должность / Желаемая вакансия</label>
                    <input
                      type="text"
                      placeholder="Официант / Администратор"
                      className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/10"
                      value={position}
                      onChange={e => setPosition(e.target.value)}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-355">Оклад / Ставка / Желаемый оклад (руб)</label>
                    <input
                      type="number"
                      placeholder="35000"
                      className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/10"
                      value={salary}
                      onChange={e => setSalary(e.target.value)}
                    />
                  </div>
                </div>

                {docType === 'candidates' ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-700 dark:text-slate-310">Контактный телефон</label>
                        <input
                          type="text"
                          placeholder="+7 (995) 123-45-67"
                          className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/10 font-mono"
                          value={phone}
                          onChange={e => setPhone(e.target.value)}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-700 dark:text-slate-310">Email</label>
                        <input
                          type="email"
                          placeholder="candidate@example.com"
                          className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/10"
                          value={email}
                          onChange={e => setEmail(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700 dark:text-slate-310">Дата и время собеседования</label>
                      <input
                        type="datetime-local"
                        className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none"
                        value={interviewDate}
                        onChange={e => setInterviewDate(e.target.value)}
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-700 dark:text-slate-310">Резюме / Навыки / Опыт работы</label>
                      <textarea
                        rows={3}
                        placeholder="Опыт в ресторанной индустрии, навыки, предыдущие заведения..."
                        className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/10 resize-none font-medium"
                        value={resume}
                        onChange={e => setResume(e.target.value)}
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div className="grid grid-cols-3 gap-3">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-700 dark:text-slate-310">Паспортные данные</label>
                        <input
                          type="text"
                          placeholder="4515 999111"
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none"
                          value={passport}
                          onChange={e => setPassport(e.target.value)}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-700 dark:text-slate-310">ИНН</label>
                        <input
                          type="text"
                          placeholder="770011223344"
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none"
                          value={inn}
                          onChange={e => setInn(e.target.value)}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-700 dark:text-slate-310">СНИЛС</label>
                        <input
                          type="text"
                          placeholder="111-222-333 44"
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none"
                          value={snils}
                          onChange={e => setSnils(e.target.value)}
                        />
                      </div>
                    </div>

                    {docType === 'hiring' && (
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-700 dark:text-slate-355">Дата начала работы</label>
                        <input
                          type="date"
                          className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none"
                          value={startDate}
                          onChange={e => setStartDate(e.target.value)}
                        />
                      </div>
                    )}

                    {docType === 'dismissal' && (
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-700 dark:text-slate-355">Дата увольнения</label>
                          <input
                            type="date"
                            className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none"
                            value={endDate}
                            onChange={e => setEndDate(e.target.value)}
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-700 dark:text-slate-355">Причина увольнения</label>
                          <input
                            type="text"
                            placeholder="По собственному желанию"
                            className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none"
                            value={reason}
                            onChange={e => setReason(e.target.value)}
                          />
                        </div>
                      </div>
                    )}
                  </>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-355">Примечания / Особые условия договора</label>
                  <textarea
                    rows={2}
                    placeholder="Описание договора, особые условия труда или комментарии..."
                    className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-850 border border-slate-100 dark:border-slate-755 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/10 resize-none"
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                  />
                </div>

                {hasEditRights && (
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 dark:text-indigo-400">Статус документа</label>
                    <div className="grid grid-cols-2 gap-4">
                      <select
                        className="w-full px-4 py-2 bg-indigo-50/15 dark:bg-slate-855 border border-indigo-100 dark:border-indigo-850 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none"
                        value={docStatus}
                        onChange={e => setDocStatus(e.target.value as any)}
                      >
                        <option value="draft">Черновик</option>
                        <option value="pending_hr">На рассмотрении</option>
                        <option value="approved">Утверждено</option>
                        <option value="rejected">Отклонено</option>
                      </select>
                      
                      <input
                        type="text"
                        placeholder="Резолюция: Принят, проверен..."
                        className="w-full px-4 py-2 bg-indigo-50/15 dark:bg-slate-855 border border-indigo-100 dark:border-indigo-850 text-xs text-slate-800 dark:text-slate-200 rounded-xl outline-none focus:border-indigo-505"
                        value={hrComment}
                        onChange={e => setHrComment(e.target.value)}
                      />
                    </div>
                  </div>
                )}

                {/* Confirm Buttons */}
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => { setIsCreating(false); setEditingDoc(null); }}
                    className="px-5 py-3 text-xs"
                  >
                    Отмена
                  </Button>
                  <Button
                    type="submit"
                    className="px-6 py-3 text-xs text-white bg-indigo-650 hover:bg-indigo-700 rounded-xl font-bold shadow-md shadow-indigo-600/10 cursor-pointer"
                  >
                    {isCreating ? 'Создать документ' : 'Сохранить изменения'}
                  </Button>
                </div>

              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
