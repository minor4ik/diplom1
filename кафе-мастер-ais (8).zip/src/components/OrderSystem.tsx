import React, { useState, useEffect } from 'react';
import { Plus, Minus, ShoppingCart, Trash2, XCircle, Tag, Check, ArrowRight } from 'lucide-react';
import { Dish, OrderItem, Order, Ingredient, Staff, PromoCode, Wallet } from '../types';
import { Card, Button, cn, Input } from './UI';
import { motion, AnimatePresence } from 'motion/react';
import { useCafeStore, handleFirestoreErrorGlobal, OperationType } from '../store';
import { db } from '../firebase';
import { doc, getDoc, runTransaction, collection } from 'firebase/firestore';
import { formatRUB, calculateLoyaltyPoints } from '../lib/walletUtils';
import { Wallet as WalletIcon, Gift, CreditCard, Coins } from 'lucide-react';

interface OrderSystemProps {
  dishes: Dish[];
  addOrder: (order: Order, user?: Staff) => void;
  ingredients: Ingredient[];
  promoCodes: PromoCode[];
  generateId: () => string;
  currentUser: Staff;
}

export default function OrderSystem({ dishes, addOrder, ingredients, promoCodes, generateId, currentUser }: OrderSystemProps) {
  const { cart, addToCart: addToCartGlobal, removeFromCart: removeFromCartGlobal, updateCartQuantity, clearCart, authInitialized } = useCafeStore();
  const [tableNumber, setTableNumber] = useState(currentUser.role === 'user' ? 0 : 1);
  const [guests, setGuests] = useState(1);
  const [errorHeader, setErrorHeader] = useState<string | null>(null);
  
  const [promoInput, setPromoInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);
  const [promoError, setPromoError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastOrderNumber, setLastOrderNumber] = useState<string | null>(null);
  
  const [useWallet, setUseWallet] = useState(false);
  const [useBonuses, setUseBonuses] = useState(false);
  const [userWallet, setUserWallet] = useState<Wallet | null>(null);
  const [activeTab, setActiveTab] = useState<'menu' | 'cart'>('menu');

  useEffect(() => {
    const fetchWallet = async () => {
      if (!currentUser?.id || !authInitialized) return;
      const walletRef = doc(db, 'wallets', currentUser.id);
      try {
        const snap = await getDoc(walletRef);
        if (snap.exists()) {
          setUserWallet(snap.data() as Wallet);
        }
      } catch (err) {
        handleFirestoreErrorGlobal(err, OperationType.GET, `wallets/${currentUser.id}`);
      }
    };
    fetchWallet();
  }, [currentUser?.id, authInitialized]);

  const subtotal = Number(cart.reduce((sum, item) => sum + (Number(item.price) || 0) * (Number(item.quantity) || 1), 0)) || 0;
  
  const discountAmount = appliedPromo ? Math.min(
    (subtotal * (Number(appliedPromo.discountPercent) || 0)) / 100,
    Number(appliedPromo.maxDiscount) || Infinity
  ) : 0;
  
  const totalBase = Math.max(0, subtotal - discountAmount);
  const maxBonusPayable = Math.floor(totalBase * 0.5);
  const appliedBonuses = useBonuses ? Math.min(Number(userWallet?.bonusBalance) || 0, maxBonusPayable) : 0;
  const total = Math.max(0, totalBase - (Number(appliedBonuses) || 0));
  const totalQuantity = cart.reduce((sum, item) => sum + (Number(item.quantity) || 1), 0);

  const handleApplyPromo = () => {
    setPromoError(null);
    const code = promoInput.trim().toUpperCase();
    if (!code) return;

    const promo = promoCodes.find(p => p.code === code);
    
    if (!promo) {
      setPromoError('Промокод не найден');
      return;
    }

    if (!promo.isActive) {
      setPromoError('Промокод более не активен');
      return;
    }

    if (promo.maxUsages && promo.usageCount >= promo.maxUsages) {
      setPromoError('Лимит использований исчерпан');
      return;
    }

    if (promo.expiryDate && Date.now() > promo.expiryDate) {
      setPromoError('Срок действия промокода истек');
      return;
    }

    setAppliedPromo(promo);
    setPromoInput('');
  };

  const addToCart = (dish: Dish) => {
    if (dish.available === false) {
      setErrorHeader(`Блюдо "${dish.name}" временно отсутствует в наличии`);
      setTimeout(() => setErrorHeader(null), 3000);
      return;
    }
    addToCartGlobal(dish);
  };

  const removeFromCart = (dishId: string) => {
    removeFromCartGlobal(dishId);
  };

  const updateQuantity = (dishId: string, delta: number) => {
    updateCartQuantity(dishId, delta);
  };

  const handleCheckout = async () => {
    if (cart.length === 0 || isSubmitting) return;

    if (useWallet && userWallet && userWallet.balance < total * 100) {
      setErrorHeader('Недостаточно средств на кошельке');
      setTimeout(() => setErrorHeader(null), 3000);
      return;
    }
    
    setIsSubmitting(true);
    try {
      const orderId = generateId();
      const newOrder: Order = {
        id: orderId,
        orderNumber: '', // Будет сгенерирован в store
        tableNumber,
        items: [...cart],
        status: 'pending',
        timestamp: Date.now(),
        subtotal,
        discountTotal: discountAmount,
        appliedBonuses: appliedBonuses,
        promoCode: appliedPromo?.code || '',
        total,
        guests,
        userId: currentUser.id,
        paymentMethod: useWallet ? 'wallet' : 'cash'
      };

      const resultNum = await addOrder(newOrder, currentUser);
      setLastOrderNumber(typeof resultNum === 'string' ? resultNum : null);
      clearCart();
      setAppliedPromo(null);
      setUseBonuses(false);
      setUseWallet(false);
    } catch (error) {
      console.error('Ошибка при создании заказа:', error);
      setErrorHeader('Ошибка при оплате. Попробуйте еще раз.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Mobile Tab Swapper */}
      <div className="lg:hidden flex bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200/50 dark:border-slate-700/50">
        <button
          onClick={() => setActiveTab('menu')}
          className={cn(
            "flex-1 py-3 text-xs sm:text-sm font-black rounded-xl transition-all text-center uppercase tracking-wider",
            activeTab === 'menu'
              ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-white shadow-md border border-slate-100 dark:border-slate-800"
              : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          )}
        >
          🍛 Выбор блюд
        </button>
        <button
          onClick={() => setActiveTab('cart')}
          className={cn(
            "flex-1 py-3 text-xs sm:text-sm font-black rounded-xl transition-all text-center flex items-center justify-center gap-2 uppercase tracking-wider",
            activeTab === 'cart'
              ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-white shadow-md border border-slate-100 dark:border-slate-800"
              : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          )}
        >
          <span>🛒 Текущий заказ</span>
          {totalQuantity > 0 && (
            <span className="bg-indigo-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full min-w-[18px] text-center">
              {totalQuantity}
            </span>
          )}
        </button>
      </div>

      <div className="flex flex-col lg:grid lg:grid-cols-3 gap-8 relative select-none">
      <AnimatePresence>
        {lastOrderNumber && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[110] flex items-center justify-center p-4"
            onClick={() => setLastOrderNumber(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[2.5rem] p-8 text-center shadow-2xl relative overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="absolute top-0 left-0 w-full h-2 bg-indigo-600" />
              <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-900/30 rounded-3xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 mx-auto mb-6">
                <Check size={40} strokeWidth={3} />
              </div>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight mb-2">Заказ оформлен!</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-6 font-medium">Ваш заказ успешно передан на кухню. Вы можете отследить его по номеру:</p>
              
              <div className="bg-slate-50 dark:bg-slate-800 rounded-2xl p-4 mb-8 border border-slate-100 dark:border-slate-700">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-1">Номер чека</span>
                <span className="text-4xl font-black text-indigo-600 dark:text-indigo-400 tracking-widest">{lastOrderNumber}</span>
              </div>

              <Button onClick={() => setLastOrderNumber(null)} className="w-full h-12 rounded-2xl uppercase tracking-widest font-black text-xs">
                Понятно
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {errorHeader && (
          <motion.div 
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-8 left-1/2 -translate-x-1/2 z-[100] w-full max-w-md px-4"
          >
            <div className="bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 p-4 rounded-xl shadow-2xl flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900/50 flex items-center justify-center text-red-600 dark:text-red-400 shrink-0">
                <XCircle size={24} />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-red-800 dark:text-red-200">Ошибка</h4>
                <p className="text-sm text-red-600 dark:text-red-400">{errorHeader}</p>
              </div>
              <button 
                onClick={() => setErrorHeader(null)}
                className="text-red-400 hover:text-red-600 transition-colors"
              >
                <XCircle size={20} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Menu Selection - Shown first on mobile */}
      <div className={cn("order-1 lg:order-1 lg:col-span-2 space-y-6", activeTab !== 'menu' && "hidden lg:block")}>
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold dark:text-white">Выбор блюд</h2>
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium text-slate-500 dark:text-slate-400">
              {tableNumber === 0 ? 'С собой / Доставка' : `Стол №`}
            </span>
            <input 
              type="number" 
              min="0" 
              className="w-16 px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-center font-bold"
              value={tableNumber || (tableNumber === 0 ? '0' : '')}
              onChange={(e) => setTableNumber(e.target.value === '' ? 0 : parseInt(e.target.value))}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {dishes.map(dish => (
            <Card 
              key={dish.id} 
              className={cn(
                "p-4 flex flex-col justify-between transition-all cursor-pointer group relative overflow-hidden",
                dish.available === false ? "opacity-60 grayscale-[0.5]" : "hover:border-indigo-200 dark:hover:border-indigo-800"
              )} 
              onClick={() => addToCart(dish)}
            >
              {dish.available === false && (
                <div className="absolute top-2 right-2 z-10">
                  <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-lg uppercase tracking-wider">
                    Нет в наличии
                  </span>
                </div>
              )}
              <div>
                <div className="flex justify-between items-start mb-2">
                  <h3 className={cn(
                    "font-bold transition-colors",
                    dish.available === false ? "text-slate-400 dark:text-slate-500" : "text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400"
                  )}>
                    {dish.name}
                  </h3>
                  <span className={cn(
                    "font-bold",
                    dish.available === false ? "text-slate-400 dark:text-slate-500" : "text-indigo-600 dark:text-indigo-400"
                  )}>
                    {dish.price} ₽
                  </span>
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mb-2">{dish.description}</p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {dish.ingredients.map(ing => {
                    const ingredient = ingredients.find(i => i.id === ing.ingredientId);
                    return ingredient ? (
                      <span key={ing.ingredientId} className="text-[10px] px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded">
                        {ingredient.name}
                      </span>
                    ) : null;
                  })}
                </div>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] font-bold text-indigo-500 dark:text-indigo-400 uppercase">Вес: {dish.weight}г</span>
                  <span className="text-[10px] font-bold text-slate-400 dark:text-slate-600 uppercase">~{dish.prepTime} мин</span>
                </div>
              </div>
              <Button 
                variant={dish.available === false ? "secondary" : "secondary"} 
                disabled={dish.available === false}
                className={cn(
                  "w-full transition-all",
                  dish.available !== false && "group-hover:bg-indigo-600 group-hover:text-white"
                )}
              >
                <Plus size={16} />
                {dish.available === false ? 'Нет в наличии' : 'Добавить'}
              </Button>
            </Card>
          ))}
        </div>
      </div>

      {/* Cart / Order Summary - Shown after menu on mobile */}
      <div className={cn("order-2 lg:order-2 space-y-4 sm:space-y-6", activeTab !== 'cart' && "hidden lg:block")}>
        <h2 className="text-xl font-bold dark:text-white">Текущий заказ</h2>
        <Card className="flex flex-col h-[480px] sm:h-[600px] lg:h-[calc(100vh-14rem)] min-h-[400px] overflow-hidden">
          <div className="flex-1 overflow-y-auto min-h-0 min-w-0">
            {/* 1. Список заказанных блюд */}
            <div className="p-4 space-y-4 border-b border-slate-100 dark:border-slate-800">
              {cart.length === 0 ? (
                <div className="py-12 flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 space-y-4">
                  <ShoppingCart size={48} strokeWidth={1.5} />
                  <p>Заказ пуст</p>
                </div>
              ) : (
                cart.map(item => (
                  <div key={item.dishId} className="flex items-center justify-between gap-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                    <div className="flex-1">
                      <p className="font-bold text-sm text-slate-900 dark:text-slate-100">{item.name}</p>
                      <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium">{item.price * item.quantity} ₽</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={(e) => { e.stopPropagation(); updateQuantity(item.dishId, -1); }}
                        className="w-6 h-6 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700"
                      >
                        <Minus size={12} />
                      </button>
                      <span className="text-sm font-bold w-4 text-center dark:text-white">{item.quantity}</span>
                      <button 
                        onClick={(e) => { e.stopPropagation(); updateQuantity(item.dishId, 1); }}
                        className="w-6 h-6 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700"
                      >
                        <Plus size={12} />
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); removeFromCart(item.dishId); }}
                        className="ml-2 text-slate-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* 2. Детали и Опции */}
            <div className="p-4 sm:p-6 bg-slate-50/50 dark:bg-slate-900/50 space-y-4">
              {/* Promo Code Input */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Tag className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
                    <Input 
                      placeholder="Промокод" 
                      className="pl-9 h-9 text-xs uppercase"
                      value={promoInput}
                      onChange={(e) => setPromoInput(e.target.value.toUpperCase())}
                      onKeyDown={(e) => e.key === 'Enter' && handleApplyPromo()}
                    />
                  </div>
                  <Button onClick={handleApplyPromo} className="h-9 px-3 shrink-0">
                    <ArrowRight size={14} />
                  </Button>
                </div>
                {promoError && <p className="text-[10px] font-bold text-red-500 animate-pulse">{promoError}</p>}
                {appliedPromo && (
                  <div className="flex items-center justify-between bg-indigo-50 dark:bg-indigo-900/30 p-2 rounded-lg border border-indigo-100 dark:border-indigo-800/50">
                    <div className="flex items-center gap-2">
                      <Check className="text-indigo-600 dark:text-indigo-400" size={14} />
                      <span className="text-[10px] font-bold text-indigo-700 dark:text-indigo-300 uppercase tracking-wider">{appliedPromo.code}</span>
                      <span className="text-[10px] font-medium text-indigo-500">(-{appliedPromo.discountPercent}%)</span>
                    </div>
                    <button 
                      onClick={() => setAppliedPromo(null)}
                      className="text-slate-400 hover:text-red-500 transition-colors"
                    >
                      <XCircle size={14} />
                    </button>
                  </div>
                )}
              </div>

              {/* Guests */}
              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-center text-sm text-slate-500 dark:text-slate-400 mb-1">
                  <span>Количество гостей:</span>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => setGuests(Math.max(1, guests - 1))}
                      className="w-8 h-8 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="font-bold w-6 text-center dark:text-white">{guests}</span>
                    <button 
                      onClick={() => setGuests(guests + 1)}
                      className="w-8 h-8 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                </div>

                <div className="space-y-2 mb-4 pb-4 border-b border-slate-100 dark:border-slate-800/50">
                  <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1 mb-3">Детали заказа</p>
                  
                  {(appliedPromo || appliedBonuses > 0) && (
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-slate-500 dark:text-slate-400">Сумма заказа:</span>
                      <span className="font-medium text-slate-900 dark:text-white">{subtotal} ₽</span>
                    </div>
                  )}

                  {appliedPromo && (
                    <div className="flex justify-between items-center text-sm font-bold text-indigo-600 dark:text-indigo-400">
                      <div className="flex items-center gap-1.5 label text-[10px] uppercase tracking-wider">
                        <Tag className="w-3 h-3" />
                        <span>Скидка ({appliedPromo.discountPercent}%):</span>
                      </div>
                      <span>-{discountAmount} ₽</span>
                    </div>
                  )}

                  {appliedBonuses > 0 && (
                    <div className="flex justify-between items-center text-sm font-bold text-amber-600">
                      <div className="flex items-center gap-1.5 label text-[10px] uppercase tracking-wider">
                        <Gift className="w-3 h-3" />
                        <span>Бонусы:</span>
                      </div>
                      <span>-{appliedBonuses} ₽</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-4 mt-2 border-t border-slate-100 dark:border-slate-800/50">
                    <span className="text-base font-bold text-slate-900 dark:text-white uppercase tracking-tight">Итого к оплате:</span>
                    <span className="text-3xl font-black text-indigo-600 dark:text-indigo-500">{total} ₽</span>
                  </div>
                </div>
              </div>

              {/* Method of payment */}
              <div className="space-y-3">
                <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Метод оплаты</p>
                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => setUseWallet(false)}
                    className={cn(
                      "flex flex-col items-center gap-2 p-3 rounded-2xl border-2 transition-all",
                      !useWallet ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20" : "border-slate-100 dark:border-slate-800"
                    )}
                  >
                    <CreditCard className={cn("w-5 h-5", !useWallet ? "text-indigo-600" : "text-slate-400")} />
                    <span className={cn("text-[10px] font-bold uppercase text-center", !useWallet ? "text-indigo-700" : "text-slate-500")}>Наличные / Терминал</span>
                  </button>
                  <button 
                    onClick={() => setUseWallet(true)}
                    className={cn(
                      "flex flex-col items-center gap-2 p-3 rounded-2xl border-2 transition-all",
                      useWallet ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20" : "border-slate-100 dark:border-slate-800"
                    )}
                  >
                    <WalletIcon className={cn("w-5 h-5", useWallet ? "text-indigo-600" : "text-slate-400")} />
                    <span className={cn("text-[10px] font-bold uppercase text-center", useWallet ? "text-indigo-700" : "text-slate-500")}>Кошелёк ({formatRUB(userWallet?.balance || 0)})</span>
                  </button>
                </div>

                {userWallet && userWallet.bonusBalance > 0 && (
                  <button 
                    onClick={() => setUseBonuses(!useBonuses)}
                    className={cn(
                      "w-full flex items-center justify-between p-3 rounded-2xl border-2 transition-all",
                      useBonuses ? "border-amber-500 bg-amber-50 dark:bg-amber-900/20" : "border-slate-100 dark:border-slate-800"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <Gift className={cn("w-5 h-5", useBonuses ? "text-amber-600" : "text-slate-400")} />
                      <div className="text-left">
                        <p className={cn("text-[10px] font-bold uppercase", useBonuses ? "text-amber-700" : "text-slate-500")}>Использовать бонусы</p>
                        <p className="text-[8px] text-slate-400">Доступно: {userWallet.bonusBalance} баллов (можно оплатить до 50% суммы)</p>
                      </div>
                    </div>
                    <div className={cn("w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0", useBonuses ? "border-amber-500 bg-amber-500" : "border-slate-200")}>
                      {useBonuses && <Check className="w-3 h-3 text-white" strokeWidth={3} />}
                    </div>
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="p-4 border-t border-slate-150 dark:border-slate-850 bg-white dark:bg-slate-900 flex-shrink-0">
            <Button 
              className={cn("w-full py-5 text-sm sm:text-base font-black uppercase tracking-widest rounded-2xl shadow-lg", useWallet ? "bg-indigo-600 shadow-indigo-500/30" : "shadow-slate-500/20")}
              disabled={cart.length === 0 || isSubmitting}
              onClick={handleCheckout}
            >
              {isSubmitting ? 'Оформление...' : (useWallet ? 'Оплатить кошельком' : 'Оформить заказ')}
            </Button>
          </div>
        </Card>
      </div>

      <AnimatePresence>
        {totalQuantity > 0 && activeTab === 'menu' && (
          <div className="lg:hidden fixed bottom-6 left-4 right-4 z-[90]">
            <motion.button
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              onClick={() => setActiveTab('cart')}
              className="w-full bg-indigo-600 hover:bg-slate-900 dark:hover:bg-slate-800 text-white p-4 rounded-2xl flex items-center justify-between shadow-2xl font-black text-xs uppercase tracking-wider transition-all active:scale-95 border border-white/10"
            >
              <div className="flex items-center gap-2">
                <ShoppingCart size={18} />
                <span>{totalQuantity} {totalQuantity === 1 ? 'блюдо' : totalQuantity < 5 ? 'блюда' : 'блюд'} на {total} ₽</span>
              </div>
              <div className="flex items-center gap-1">
                <span>Оформить заказ</span>
                <ArrowRight size={16} />
              </div>
            </motion.button>
          </div>
        )}
      </AnimatePresence>

    </div>
  </div>
  );
}
