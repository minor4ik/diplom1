import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  Utensils, 
  ClipboardList, 
  ChefHat, 
  Package, 
  LogOut,
  Bell,
  MessageCircle,
  Wallet,
  Users,
  FileBarChart,
  History,
  Menu as MenuIcon,
  X,
  CheckCircle2,
  AlertCircle,
  Info,
  Trash2,
  Clock,
  UserCircle,
  ChevronDown,
  Terminal,
  Sun,
  Moon,
  Tag,
  Ticket as TicketIcon,
  Wifi,
  Shield,
  FileText
} from 'lucide-react';
import { View, Notification, Staff, Message } from '../types';
import { getEffectiveRole } from '../lib/auth';
import { cn } from './UI';
import SupportChat from './SupportChat';

interface LayoutProps {
  children: React.ReactNode;
  currentView: View;
  setView: (view: View, params?: { ticketId?: string }) => void;
  notifications: Notification[];
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  clearNotifications: () => void;
  onLogout: () => void;
  currentUser: Staff;
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
}

export default function Layout({ 
  children, 
  currentView, 
  setView, 
  notifications, 
  markNotificationRead, 
  markAllNotificationsRead,
  clearNotifications,
  onLogout,
  currentUser,
  theme,
  setTheme
}: LayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const allMenuItems = [
    { id: 'profile', label: 'Мой Профиль', icon: UserCircle, roles: ['owner', 'admin', 'chef', 'waiter', 'bartender', 'tech', 'tester', 'developer', 'user', 'hr'] },
    { id: 'wallet', label: 'Кошелёк', icon: Wallet, roles: ['owner', 'admin', 'chef', 'waiter', 'bartender', 'tech', 'tester', 'developer', 'user', 'hr'] },
    { id: 'tickets', label: 'CRM Тикеты', icon: TicketIcon, roles: ['owner', 'admin', 'tech', 'tester', 'developer'] },
    { id: 'dashboard', label: 'Статистика', icon: LayoutDashboard, roles: ['owner', 'admin', 'tech', 'developer'] },
    { id: 'orders', label: 'Заказы', icon: Utensils, roles: ['owner', 'admin', 'chef', 'waiter', 'bartender', 'tech', 'user', 'developer'] },
    { id: 'kitchen', label: 'Кухня', icon: ChefHat, roles: ['owner', 'admin', 'chef', 'bartender', 'tech', 'developer'] },
    { id: 'menu', label: 'Меню', icon: ClipboardList, roles: ['owner', 'admin', 'tech', 'developer'] },
    { id: 'inventory', label: 'Склад', icon: Package, roles: ['owner', 'admin', 'chef', 'bartender', 'tech', 'developer'] },
    { id: 'staff', label: 'Пользователи', icon: Users, roles: ['owner', 'admin', 'tech', 'developer', 'hr'] },
    { id: 'hr-docs', label: 'Документы', icon: FileText, roles: ['owner', 'hr', 'admin', 'developer', 'tech', 'tester'] },
    { id: 'reports', label: 'Отчёты', icon: FileBarChart, roles: ['owner', 'admin', 'chef', 'tech', 'developer'] },
    { id: 'promos', label: 'Промокоды', icon: Tag, roles: ['owner', 'admin', 'tech', 'developer'] },
    { id: 'wifi', label: 'WiFi Сети', icon: Wifi, roles: ['owner', 'admin', 'tech', 'developer', 'tester'] },
    { id: 'staff-chat', label: 'Чаты', icon: MessageCircle, roles: ['owner', 'admin', 'chef', 'waiter', 'bartender', 'tech', 'tester', 'developer', 'hr'] },
    { id: 'changelog', label: 'Журнал', icon: History, roles: ['owner', 'admin', 'tech', 'developer'] },
    { id: 'logs', label: 'Логи', icon: Terminal, roles: ['owner', 'admin', 'tech', 'developer'] },
    { id: 'dev-logs', label: 'Системный раздел', icon: Shield, roles: ['developer'] },
  ];

  const userRole = getEffectiveRole(currentUser);

  const isAccessAllowed = (n: Notification) => {
    // If targeted at a specific user, ONLY that user (and admins) should see it
    if (n.targetUserId) {
      return n.targetUserId === currentUser.id || ['owner', 'admin', 'tech', 'developer', 'tester'].includes(userRole);
    }

    // Privileged roles see general notifications
    if (userRole === 'admin' || userRole === 'owner' || userRole === 'tech' || userRole === 'developer' || userRole === 'tester') return true;
    
    // If targetRoles is specified, respect it
    if (n.targetRoles && n.targetRoles.length > 0) {
      return n.targetRoles.includes(userRole);
    }

    // Fallback logic for legacy notifications or missing targetRoles
    switch (n.type) {
      case 'order':
      case 'status':
        return ['admin', 'owner', 'tech', 'chef', 'waiter', 'bartender'].includes(userRole);
      case 'inventory':
        return ['admin', 'owner', 'tech', 'chef', 'bartender'].includes(userRole);
      case 'chat':
        return ['admin', 'owner', 'tech', 'user', 'waiter', 'chef', 'bartender', 'tester', 'developer'].includes(userRole);
      case 'ticket':
        return ['admin', 'owner', 'tech', 'tester', 'developer'].includes(userRole);
      case 'info':
        return true;
      default:
        return false;
    }
  };

  const unreadCount = notifications.filter(n => !n.read && isAccessAllowed(n)).length;
  const filteredNotifications = notifications.filter(isAccessAllowed);
  
  // Дополнительная проверка: если у пользователя позиция владельца или админа, он должен видеть логи
  const isPrivileged = userRole === 'owner' || userRole === 'admin' || userRole === 'tech' || userRole === 'developer' || userRole === 'tester' || 
                      (currentUser.position || '').toLowerCase().includes('владелец') || 
                      (currentUser.position || '').toLowerCase().includes('администратор') ||
                      (currentUser.position || '').toLowerCase().includes('тех') ||
                      (currentUser.position || '').toLowerCase().includes('dev') ||
                      (currentUser.position || '').toLowerCase().includes('tester');

  const menuItems = allMenuItems.filter(item => {
    if (item.id === 'logs') return isPrivileged;
    return item.roles.includes(userRole);
  });

  const handleNotificationClick = (notif: Notification) => {
    markNotificationRead(notif.id);
    setIsNotificationsOpen(false);
    
    switch (notif.type) {
      case 'order':
        setView('orders');
        break;
      case 'inventory':
        setView('inventory');
        break;
      case 'status':
        setView('kitchen');
        break;
      case 'info':
        setView('dashboard');
        break;
      case 'ticket':
        setView('tickets');
        break;
      default:
        setView('dashboard');
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900 overflow-hidden dark:bg-slate-950 dark:text-slate-100 transition-colors duration-300">
      {/* Mobile Overlay */}
      {(isSidebarOpen || isNotificationsOpen || isUserMenuOpen) && (
        <div 
          className={cn(
            "fixed inset-0 z-40 backdrop-blur-sm transition-opacity",
            isSidebarOpen ? "bg-slate-900/50 lg:hidden" : "bg-transparent"
          )}
          onClick={() => {
            setIsSidebarOpen(false);
            setIsNotificationsOpen(false);
            setIsUserMenuOpen(false);
          }}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 dark:bg-slate-900 dark:border-slate-800",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-3 text-indigo-600">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
              <Utensils size={24} />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">Кафе Мастер</span>
          </div>
          <button 
            className="lg:hidden p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
            onClick={() => setIsSidebarOpen(false)}
          >
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setView(item.id as View);
                setIsSidebarOpen(false);
              }}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-medium",
                currentView === item.id 
                  ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400" 
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-200"
              )}
            >
              <item.icon size={20} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-100 dark:border-slate-800">
          {/* Отображение текущей версии системы в футере боковой панели */}
          <div className="px-4 py-2 mb-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest dark:text-slate-500">
            Версия v 1.6
          </div>
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-red-600 transition-colors font-medium dark:text-slate-400 dark:hover:text-red-500"
          >
            <LogOut size={20} />
            Выход
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden w-full">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8 shrink-0 dark:bg-slate-900 dark:border-slate-800 transition-colors relative">
          <div className="flex items-center gap-4">
            <button 
              className="lg:hidden p-2 text-slate-500 hover:bg-slate-50 rounded-lg dark:text-slate-400 dark:hover:bg-slate-800"
              onClick={() => setIsSidebarOpen(true)}
            >
              <MenuIcon size={24} />
            </button>
            <h1 className="text-lg font-semibold text-slate-800 dark:text-slate-100 truncate max-w-[150px] sm:max-w-none">
              {menuItems.find(i => i.id === currentView)?.label}
            </h1>
          </div>
          <div className="flex items-center gap-2 sm:gap-4 relative">
            <button
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              className="p-2 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors rounded-lg bg-slate-50 dark:bg-slate-800"
              title={theme === 'light' ? "Включить темную тему" : "Включить светлую тему"}
            >
              {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            </button>

            <button 
              onClick={() => {
                const newState = !isNotificationsOpen;
                setIsNotificationsOpen(newState);
                if (newState) {
                  markAllNotificationsRead();
                }
              }}
              className="p-2 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors relative"
            >
              <Bell size={20} />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-red-500 rounded-full border-2 border-white dark:border-slate-900 text-[10px] text-white flex items-center justify-center font-bold">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notifications Dropdown */}
            {isNotificationsOpen && (
              <div className="absolute top-full right-0 mt-2 w-80 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-800 z-[60] overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                  <h3 className="font-bold text-slate-900 dark:text-white">Уведомления</h3>
                  <button 
                    onClick={clearNotifications}
                    className="text-xs text-slate-400 hover:text-red-500 flex items-center gap-1"
                  >
                    <Trash2 size={12} />
                    Очистить
                  </button>
                </div>
                <div className="max-h-96 overflow-y-auto">
                  {filteredNotifications.length === 0 ? (
                    <div className="p-8 text-center text-slate-400">
                      <Bell size={32} className="mx-auto mb-2 opacity-20" />
                      <p className="text-sm">Нет новых уведомлений</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-50 dark:divide-slate-800">
                      {filteredNotifications.map(notif => (
                        <div 
                          key={notif.id} 
                          onClick={() => handleNotificationClick(notif)}
                          className={cn(
                            "p-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer relative",
                            !notif.read && "bg-indigo-50/30 dark:bg-indigo-900/10"
                          )}
                        >
                          {!notif.read && (
                            <div className="absolute left-1 top-1/2 -translate-y-1/2 w-1 h-8 bg-indigo-500 rounded-full"></div>
                          )}
                          <div className="flex gap-3">
                            <div className={cn(
                              "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                               notif.type === 'order' ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400" :
                              notif.type === 'status' ? "bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400" :
                              notif.type === 'inventory' ? "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400" : 
                              notif.type === 'chat' ? "bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400" :
                              notif.type === 'ticket' ? "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400" :
                              "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400"
                            )}>
                              {notif.type === 'order' && <Utensils size={16} />}
                              {notif.type === 'status' && <CheckCircle2 size={16} />}
                              {notif.type === 'inventory' && <AlertCircle size={16} />}
                              {notif.type === 'chat' && <MessageCircle size={16} />}
                              {notif.type === 'ticket' && <TicketIcon size={16} />}
                              {notif.type === 'info' && <Info size={16} />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">{notif.title}</p>
                              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5">{notif.message}</p>
                              <div className="flex items-center gap-1 mt-2 text-[10px] text-slate-400">
                                <Clock size={10} />
                                {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="relative">
              <button 
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-3 pl-2 sm:pl-4 border-l border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors py-1 rounded-lg"
              >
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{currentUser.name}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{currentUser.position}</p>
                </div>
                <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-700 dark:text-indigo-300 font-bold text-xs shrink-0 relative">
                  <div className="w-full h-full rounded-full overflow-hidden flex items-center justify-center">
                    {currentUser?.avatarUrl ? (
                      <img src={currentUser.avatarUrl} alt={currentUser?.name || 'Пользователь'} className="w-full h-full object-cover" />
                    ) : (
                      (currentUser?.name || 'Пользователь').split(' ').filter(Boolean).map(n => n[0]).join('').toUpperCase()
                    )}
                  </div>
                  <div className="absolute -bottom-0.5 -right-0.5 bg-white dark:bg-slate-800 rounded-full p-0.5 shadow-sm border border-slate-100 dark:border-slate-700 z-10">
                    <ChevronDown size={10} className={cn("text-slate-400 transition-transform", isUserMenuOpen && "rotate-180")} />
                  </div>
                </div>
              </button>

              {isUserMenuOpen && (
                <div className="absolute top-full right-0 mt-2 w-52 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-100 dark:border-slate-800 z-[60] py-2 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="px-4 py-2 border-b border-slate-50 dark:border-slate-800 mb-1">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Аккаунт</p>
                  </div>
                  <button 
                    onClick={() => {
                      setView('profile');
                      setIsUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm font-medium"
                  >
                    <LayoutDashboard size={18} />
                    Мой Профиль
                  </button>
                  <button 
                    onClick={() => {
                      onLogout();
                      setIsUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors text-sm font-medium"
                  >
                    <UserCircle size={18} />
                    Сменить аккаунт
                  </button>
                  <button 
                    onClick={() => {
                      onLogout();
                      setIsUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-red-50 dark:hover:bg-red-900/30 hover:text-red-600 dark:hover:text-red-400 transition-colors text-sm font-medium"
                  >
                    <LogOut size={18} />
                    Выйти
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 lg:p-8">
          {children}
        </div>
      </main>

      <SupportChat currentUser={currentUser} />
    </div>
  );
}
