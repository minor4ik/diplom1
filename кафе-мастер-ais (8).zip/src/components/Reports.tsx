import React, { useState, useRef, useMemo } from 'react';
import { FileText, Download, Calendar, X, Trash2 } from 'lucide-react';
import { Order, Expense } from '../types';
import { Card, Button, cn } from './UI';
import { TrendingDown, TrendingUp, PieChart as PieIcon } from 'lucide-react';
import { getValidOrders } from '../lib/stats';

interface ReportsProps {
  orders: Order[];
  expenses: Expense[];
}

export default function Reports({ orders, expenses }: ReportsProps) {
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const filteredOrders = getValidOrders(orders).filter(o => {
    const orderDate = new Date(o.timestamp).toISOString().split('T')[0];
    if (dateRange.start && orderDate < dateRange.start) return false;
    if (dateRange.end && orderDate > dateRange.end) return false;
    return true;
  }).sort((a, b) => {
    const numA = parseInt(a.orderNumber) || 0;
    const numB = parseInt(b.orderNumber) || 0;
    return sortOrder === 'asc' ? numA - numB : numB - numA;
  });

  const filteredExpenses = expenses.filter(e => {
    const expenseDate = new Date(e.timestamp).toISOString().split('T')[0];
    if (dateRange.start && expenseDate < dateRange.start) return false;
    if (dateRange.end && expenseDate > dateRange.end) return false;
    return true;
  });

  const totalRevenue = filteredOrders.reduce((sum, o) => sum + o.total, 0);
  const totalExpenses = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
  const netProfit = totalRevenue - totalExpenses;
  const completedCount = filteredOrders.length;
  
  const totalItemsSold = filteredOrders.reduce((sum, o) => 
    sum + o.items.reduce((itemSum, item) => itemSum + item.quantity, 0), 0
  );

  const popularItems = useMemo(() => {
    const items: Record<string, { quantity: number, total: number }> = {};
    filteredOrders.forEach(o => {
      o.items.forEach(item => {
        if (!items[item.name]) {
          items[item.name] = { quantity: 0, total: 0 };
        }
        items[item.name].quantity += item.quantity;
        items[item.name].total += item.price * item.quantity;
      });
    });
    return Object.entries(items)
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 10);
  }, [filteredOrders]);

  const handleExportPDF = async () => {
    if (!reportRef.current) return;

    try {
      const html2pdfModule = await import('html2pdf.js');
      const html2pdf = html2pdfModule.default;
      
      const element = reportRef.current;
      const opt = {
        margin: 10,
        filename: `report_${new Date().toISOString().split('T')[0]}.pdf`,
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, logging: false },
        jsPDF: { unit: 'mm' as const, format: 'a4' as const, orientation: 'portrait' as const }
      };

      html2pdf().set(opt).from(element).save();
    } catch (err) {
      console.error('PDF export error:', err);
      alert('Внимание: Не удалось экспортировать отчет как PDF из-за внутренней ошибки рендеринга стилей. Пожалуйста, используйте функцию печати браузера (Ctrl+P / Cmd+P).');
    }
  };

  return (
    <div className="space-y-6" ref={reportRef}>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative" data-html2canvas-ignore="true">
        <h2 className="text-xl font-bold dark:text-white">Отчёты</h2>
        <div className="flex gap-2 sm:gap-3 w-full sm:w-auto">
          <Button 
            variant={dateRange.start || dateRange.end ? "primary" : "secondary"} 
            className="flex-1 sm:flex-none"
            onClick={() => setIsFilterOpen(!isFilterOpen)}
          >
            <Calendar size={18} />
            {dateRange.start || dateRange.end ? 'Фильтр активен' : 'Период'}
          </Button>
          <Button className="flex-1 sm:flex-none" onClick={handleExportPDF}>
            <Download size={18} />
            Экспорт
          </Button>
        </div>

        {isFilterOpen && (
          <Card className="absolute top-full right-0 mt-2 p-4 z-50 w-full sm:w-72 shadow-xl border-indigo-100 dark:border-indigo-900/30 animate-in fade-in slide-in-from-top-2">
            <div className="flex justify-between items-center mb-4">
              <h4 className="font-bold text-sm dark:text-white">Фильтр по дате</h4>
              <button onClick={() => setIsFilterOpen(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                <X size={16} />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1 block">От</label>
                <input 
                  type="date" 
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:ring-2 focus:ring-indigo-500/20 text-slate-900 dark:text-slate-100"
                  value={dateRange.start}
                  onChange={e => setDateRange({...dateRange, start: e.target.value})}
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1 block">До</label>
                <input 
                  type="date" 
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:ring-2 focus:ring-indigo-500/20 text-slate-900 dark:text-slate-100"
                  value={dateRange.end}
                  onChange={e => setDateRange({...dateRange, end: e.target.value})}
                />
              </div>
              <div className="flex gap-2 pt-2">
                <Button 
                  variant="secondary" 
                  className="flex-1 text-xs py-2" 
                  onClick={() => {
                    setDateRange({ start: '', end: '' });
                    setIsFilterOpen(false);
                  }}
                >
                  Сброс
                </Button>
                <Button 
                  className="flex-1 text-xs py-2"
                  onClick={() => setIsFilterOpen(false)}
                >
                  Применить
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-4 sm:p-6 bg-emerald-600 text-white">
          <h3 className="text-emerald-100 font-medium mb-2">Общая выручка</h3>
          <p className="text-3xl sm:text-4xl font-bold">{totalRevenue.toLocaleString()} ₽</p>
          <div className="mt-4 space-y-1">
            <div className="flex items-center gap-2 text-emerald-200 text-sm">
              <TrendingUp size={16} />
              На основе {completedCount} заказов
            </div>
            <div className="flex items-center gap-2 text-emerald-300 text-xs font-bold uppercase tracking-wider pl-6">
              Продано {totalItemsSold} поз.
            </div>
          </div>
        </Card>

        <Card className="p-4 sm:p-6 bg-rose-600 text-white">
          <h3 className="text-rose-100 font-medium mb-2">Общие расходы</h3>
          <p className="text-3xl sm:text-4xl font-bold">{totalExpenses.toLocaleString()} ₽</p>
          <div className="mt-4 flex items-center gap-2 text-rose-200 text-sm">
            <TrendingDown size={16} />
            {expenses.length} записей об издержках
          </div>
        </Card>

        <Card className={cn("p-4 sm:p-6 text-white", netProfit >= 0 ? "bg-indigo-600" : "bg-slate-800")}>
          <h3 className="text-indigo-100 font-medium mb-2">Чистая прибыль</h3>
          <p className="text-3xl sm:text-4xl font-bold">{netProfit.toLocaleString()} ₽</p>
          <div className="mt-4 flex items-center gap-2 text-indigo-200 text-sm">
            <PieIcon size={16} />
            Рентабельность: {totalRevenue > 0 ? Math.round((netProfit / totalRevenue) * 100) : 0}%
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="flex flex-col">
          <div className="p-4 sm:p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-white dark:bg-slate-900 rounded-t-3xl">
            <h3 className="font-bold dark:text-white text-sm sm:text-base">История заказов</h3>
            <button 
              onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
              className="text-[10px] sm:text-xs font-bold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300 flex items-center gap-1 bg-indigo-50 dark:bg-indigo-900/20 px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg transition-colors"
            >
              {sortOrder === 'asc' ? 'Сначала старые' : 'Сначала новые'}
            </button>
          </div>
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
                  <th className="px-3 sm:px-6 py-4 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-white uppercase whitespace-nowrap">Чек №</th>
                  <th className="px-3 sm:px-6 py-4 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-white uppercase whitespace-nowrap">Дата и время</th>
                  <th className="px-3 sm:px-6 py-4 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-white uppercase whitespace-nowrap">Стол</th>
                  <th className="px-3 sm:px-6 py-4 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-white uppercase whitespace-nowrap">Гости</th>
                  <th className="px-3 sm:px-6 py-4 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-white uppercase whitespace-nowrap">Сумма</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-900 bg-white dark:bg-slate-900">
                {filteredOrders.slice(0, 50).map((order, index) => (
                  <tr key={order.id} className="hover:bg-slate-50/50 dark:hover:bg-white/5 transition-colors text-sm">
                    <td className="px-3 sm:px-6 py-4 font-mono text-[10px] sm:text-xs font-black text-indigo-600 dark:text-white">
                      Чек №{sortOrder === 'desc' ? filteredOrders.length - index : index + 1}
                      {order.orderNumber && order.orderNumber !== '----' && (
                        <span className="text-[10px] font-normal text-slate-400 block sm:inline sm:ml-1">
                          ({order.orderNumber})
                        </span>
                      )}
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-slate-600 dark:text-white">
                      <div className="font-bold text-slate-900 dark:text-white whitespace-nowrap">
                        {new Date(order.timestamp).toLocaleDateString([], { day: '2-digit', month: '2-digit' })}
                      </div>
                      <div className="text-[10px] text-slate-400 dark:text-white/40">
                        {new Date(order.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </td>
                    <td className="px-3 sm:px-6 py-4 font-black text-slate-900 dark:text-white text-xs sm:text-sm">№{order.tableNumber}</td>
                    <td className="px-3 sm:px-6 py-4 text-slate-600 dark:text-white/80 font-medium text-xs sm:text-sm whitespace-nowrap">{order.guests || 0} чел.</td>
                    <td className="px-3 sm:px-6 py-4 font-black text-slate-900 dark:text-white text-base sm:text-lg whitespace-nowrap">{order.total} ₽</td>
                  </tr>
                ))}
                {filteredOrders.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-6 py-10 text-center text-slate-400 italic text-sm">Нет заказов за этот период</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        <Card className="flex flex-col">
          <div className="p-4 sm:p-6 border-b border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-t-3xl">
            <h3 className="font-bold dark:text-white text-sm sm:text-base">Последние расходы</h3>
          </div>
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
                  <th className="px-3 sm:px-6 py-4 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-white uppercase whitespace-nowrap">Описание</th>
                  <th className="px-3 sm:px-6 py-4 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-white uppercase whitespace-nowrap">Сумма</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-900 bg-white dark:bg-slate-900">
                {filteredExpenses.slice(0, 10).map((expense) => (
                  <tr key={expense.id} className="hover:bg-slate-50/50 dark:hover:bg-white/5 transition-colors text-sm">
                    <td className="px-3 sm:px-6 py-4 font-black">
                      <p className="font-bold text-slate-900 dark:text-white text-sm">{expense.description}</p>
                      <div className="flex items-center gap-2">
                        <p className="text-[10px] text-slate-400 dark:text-white/60 uppercase font-black">{
                          expense.category === 'inventory' ? 'Склад' : 
                          expense.category === 'staff' ? 'Персонал' : 'Прочее'
                        }</p>
                        <span className="text-[10px] text-slate-300 dark:text-white/20">•</span>
                        <p className="text-[10px] text-slate-400 dark:text-white/40 font-bold">
                          {new Date(expense.timestamp).toLocaleDateString([], { day: '2-digit', month: '2-digit' })}
                        </p>
                      </div>
                    </td>
                    <td className="px-3 sm:px-6 py-4 font-black text-rose-600 dark:text-rose-400 text-base sm:text-lg whitespace-nowrap">-{expense.amount} ₽</td>
                  </tr>
                ))}
                {filteredExpenses.length === 0 && (
                  <tr>
                    <td colSpan={2} className="px-6 py-10 text-center text-slate-400 italic text-sm">Нет записей о расходах</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      <Card className="flex flex-col">
          <div className="p-4 sm:p-6 border-b border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-t-3xl">
            <h3 className="font-bold dark:text-white text-sm sm:text-base">Популярные товары</h3>
          </div>
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
                  <th className="px-3 sm:px-6 py-4 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-white uppercase">Наименование</th>
                  <th className="px-3 sm:px-6 py-4 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-white uppercase text-center whitespace-nowrap">Количество</th>
                  <th className="px-3 sm:px-6 py-4 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-white uppercase text-right whitespace-nowrap">Выручка</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-900 bg-white dark:bg-slate-900">
                {popularItems.map((item, index) => (
                  <tr key={index} className="hover:bg-slate-50/50 dark:hover:bg-white/5 transition-colors text-sm">
                    <td className="px-3 sm:px-6 py-4 font-bold text-slate-900 dark:text-white text-sm">{item.name}</td>
                    <td className="px-3 sm:px-6 py-4 text-center font-black text-indigo-600 dark:text-indigo-400 text-sm">{item.quantity} шт.</td>
                    <td className="px-3 sm:px-6 py-4 text-right font-black text-slate-900 dark:text-white text-sm whitespace-nowrap">{item.total.toLocaleString()} ₽</td>
                  </tr>
                ))}
                {popularItems.length === 0 && (
                  <tr>
                    <td colSpan={3} className="px-6 py-10 text-center text-slate-400 italic text-sm">Нет данных о продажах</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
      </Card>
    </div>
  );
}
