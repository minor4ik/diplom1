import React, { useState } from 'react';
import { AlertTriangle, Plus, ArrowDown, ArrowUp, X, Edit2 } from 'lucide-react';
import { Ingredient, Expense } from '../types';
import { Card, Button, cn } from './UI';

interface InventoryProps {
  ingredients: Ingredient[];
  updateIngredient: (ing: Ingredient) => Promise<void>;
  addExpense: (expense: Expense) => void;
}

export default function Inventory({ ingredients, updateIngredient, addExpense }: InventoryProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingIngredient, setEditingIngredient] = useState<Ingredient | null>(null);
  const [supply, setSupply] = useState<{ ingredientId: string; amount: number | string; cost: number | string }>({ 
    ingredientId: '', 
    amount: '', 
    cost: '' 
  });

  const handleSupply = async () => {
    if (!supply.ingredientId || !supply.amount || Number(supply.amount) <= 0) return;
    
    const ingredient = ingredients.find(i => i.id === supply.ingredientId);
    if (!ingredient) return;

    try {
      const newQuantity = Number((ingredient.quantity + Number(supply.amount)).toFixed(3));
      
      const updatedIngredient = { ...ingredient, quantity: newQuantity };
      
      // Обновляем склад в БД через стор
      await updateIngredient(updatedIngredient);

      const expense: Expense = {
        id: Math.random().toString(36).substr(2, 9),
        description: `Поставка: ${ingredient.name} (${supply.amount} ${ingredient.unit})`,
        amount: Number(supply.cost) || (ingredient.costPrice * Number(supply.amount)),
        category: 'inventory',
        timestamp: Date.now()
      };

      // Добавляем издержку в БД через стор
      await addExpense(expense);

      setIsAdding(false);
      setSupply({ ingredientId: '', amount: '', cost: '' });
    } catch (error) {
      console.error('Ошибка при оформлении поставки в Firestore:', error);
      alert('Ошибка при сохранении данных. Попробуйте снова.');
    }
  };

  const handleUpdateIngredient = async () => {
    if (!editingIngredient || !editingIngredient.name) return;
    
    try {
      await updateIngredient(editingIngredient);
      setEditingIngredient(null);
    } catch (error) {
      console.error('Ошибка при обновлении ингредиента:', error);
      alert('Ошибка при сохранении. Попробуйте снова.');
    }
  };

  const adjustStock = async (id: string, delta: number) => {
    const ingredient = ingredients.find(i => i.id === id);
    if (!ingredient) return;

    try {
      const newQuantity = Number(Math.max(0, ingredient.quantity + delta).toFixed(3));
      const updatedIngredient = { ...ingredient, quantity: newQuantity };
      await updateIngredient(updatedIngredient);
    } catch (error) {
      console.error('Ошибка при изменении остатка:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold dark:text-white">Учёт продуктов</h2>
        <Button onClick={() => setIsAdding(true)}>
          <Plus size={18} />
          Новая поставка
        </Button>
      </div>

      {isAdding && (
        <Card className="p-4 sm:p-6 border-2 border-indigo-100 dark:border-indigo-900/30 bg-indigo-50/30 dark:bg-indigo-900/20">
          <div className="flex justify-between items-center mb-4 sm:mb-6">
            <h3 className="text-lg font-bold dark:text-white">Оформление поставки</h3>
            <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
              <X size={20} />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Ингредиент</label>
              <select 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20"
                value={supply.ingredientId}
                onChange={e => setSupply({...supply, ingredientId: e.target.value})}
              >
                <option value="" className="dark:bg-slate-900">Выберите продукт...</option>
                {ingredients.map(ing => (
                  <option key={ing.id} value={ing.id} className="dark:bg-slate-900">{ing.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Количество</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20"
                value={supply.amount}
                onChange={e => setSupply({...supply, amount: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Стоимость закупки (₽)</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500/20"
                placeholder="Оставьте 0 для авторасчета"
                value={supply.cost}
                onChange={e => setSupply({...supply, cost: e.target.value})}
              />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setIsAdding(false)}>Отмена</Button>
            <Button onClick={handleSupply}>Принять</Button>
          </div>
        </Card>
      )}

      {editingIngredient && (
        <Card className="p-4 sm:p-6 border-2 border-amber-100 dark:border-amber-900/30 bg-amber-50/30 dark:bg-amber-900/20">
          <div className="flex justify-between items-center mb-4 sm:mb-6">
            <h3 className="text-lg font-bold dark:text-white">Редактировать продукт</h3>
            <button onClick={() => setEditingIngredient(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
              <X size={20} />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Название</label>
              <input 
                type="text" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500/20"
                value={editingIngredient.name || ''}
                onChange={e => setEditingIngredient({...editingIngredient, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Ед. измерения</label>
              <input 
                type="text" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500/20"
                value={editingIngredient.unit || ''}
                onChange={e => setEditingIngredient({...editingIngredient, unit: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Мин. остаток</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500/20"
                value={editingIngredient.minStock ?? 0}
                onChange={e => setEditingIngredient({...editingIngredient, minStock: Number(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Себестоимость (₽)</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500/20"
                value={editingIngredient.costPrice ?? 0}
                onChange={e => setEditingIngredient({...editingIngredient, costPrice: Number(e.target.value)})}
              />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setEditingIngredient(null)}>Отмена</Button>
            <Button onClick={handleUpdateIngredient} className="bg-amber-600 hover:bg-amber-700">Обновить</Button>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {ingredients.map(ing => {
          const isLow = ing.quantity <= ing.minStock;
          return (
            <Card key={ing.id} className={cn(
              "p-4 sm:p-6 border-l-4 bg-white dark:bg-slate-950",
              isLow ? "border-l-red-500" : "border-l-emerald-500"
            )}>
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white uppercase tracking-tight">{ing.name}</h3>
                  <p className="text-[10px] text-slate-400 dark:text-white/60 font-black uppercase">Себест.: {ing.costPrice} ₽/{ing.unit}</p>
                </div>
                <div className="flex gap-2">
                  {isLow && (
                    <div className="text-red-500 dark:text-white animate-pulse">
                      <AlertTriangle size={20} />
                    </div>
                  )}
                  <button 
                    onClick={() => setEditingIngredient(ing)}
                    className="p-1 text-slate-400 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-300 transition-colors"
                  >
                    <Edit2 size={16} />
                  </button>
                </div>
              </div>

              <div className="flex items-end justify-between">
                <div>
                  <p className="text-4xl font-black text-slate-900 dark:text-white">
                    {Number(ing.quantity.toFixed(2))}
                  </p>
                  <p className="text-[10px] font-bold text-slate-500 dark:text-white/40 uppercase tracking-widest mt-1">
                    Мин. остаток: {ing.minStock}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => adjustStock(ing.id, -1)}
                    className="p-2.5 rounded-xl bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-white hover:bg-slate-200 dark:hover:bg-white/20 transition-all active:scale-95"
                  >
                    <ArrowDown size={16} />
                  </button>
                  <button 
                    onClick={() => adjustStock(ing.id, 1)}
                    className="p-2.5 rounded-xl bg-indigo-50 dark:bg-white/10 text-indigo-600 dark:text-white hover:bg-indigo-100 dark:hover:bg-white/20 transition-all active:scale-95 border border-indigo-100 dark:border-white/10"
                  >
                    <ArrowUp size={16} />
                  </button>
                </div>
              </div>

              {isLow && (
                <div className="mt-4 p-2 rounded-lg bg-red-50 dark:bg-white/10 text-red-700 dark:text-white text-[10px] font-black uppercase text-center border border-red-100 dark:border-white/20">
                  Требуется закупка
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}

