import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, Send, X, User, Bot, ShieldCheck, Star, CheckCircle2, Headphones, Archive, Trash2, Edit3, Image as ImageIcon, Paperclip } from 'lucide-react';
import { Staff, Message, Role, ChatSession, Order, Ticket } from '../types';
import { getEffectiveRole } from '../lib/auth';
import { cn } from './UI';
import { db, auth } from '../firebase';
import { collection, addDoc, onSnapshot, query, orderBy, limit, doc, setDoc, updateDoc, where, getDoc, getDocs, deleteDoc, writeBatch } from 'firebase/firestore';
import { useCafeStore } from '../store';
import { motion, AnimatePresence } from 'motion/react';

interface SupportChatProps {
  currentUser: Staff;
}

const FAQ_RESPONSES: Record<string, string> = {
  'как создать заказ': 'Чтобы создать заказ, перейдите в раздел "Заказы", выберите блюда и нажмите "Оформить заказ".',
  'как изменить статус': 'Статус заказа меняется в разделе "Кухня". Нажмите "Начать готовить" или "Готово".',
  'забыл пароль': 'Для сброса пароля обратитесь к главному администратору.',
  'как вернуть заказ': 'Отмена заказа с полным возвратом средств на баланс кошелька возможна в разделе "Wallet" только в статусе ожидания (pending), до начала приготовления на кухне.',
  'график работы': 'Наше заведение и служба автоматизации работают ежедневно с 09:00 до 23:00 без выходных и перерывов.',
  'привет': 'Здравствуйте! Я бот-помощник CafeMaster. Могу помочь с навигацией по сайту или заказом "Блюда от шефа".',
  'здравствуйте': 'Здравствуйте! Я бот-помощник CafeMaster. Могу помочь с навигацией по сайту или заказом "Блюда от шефа".',
  'как дела': 'Я всего лишь бот, но готов помочь вам с работой в системе!',
  'помощь': 'Я могу помочь с заказами, складом или персоналом. Просто опишите вашу проблему.',
  'навигация': 'Слева находится меню разделов: "Статистика" (обзор работы), "Заказы" (оформление), "Кухня" (готовка), "Меню" (редактирование списка блюд), "Склад" (остатки продуктов).',
  'о сайте': 'CafeMaster — это комплексная система управления кафе, автоматизирующая заказы, складской учет и работу персонала.',
  'функционал': 'Система поддерживает: онлайн-заказы, контроль приготовления (таймеры кухни), инвентаризацию склада с уведомлениями о нехватке, отчетность и управление сотрудниками.',
  'часто задаваемые вопросы': 'Я могу рассказать вам о том, как сделать заказ, как изменить статус или как работает наша система лояльности. Что именно вас интересует?',
  'скидки': 'У нас действует система промокодов! Вы можете получить их за активность или в наших соцсетях. Введите промокод при оформлении заказа в корзине.',
  'вопрос по заказу': 'Для уточнения информации по заказу, пожалуйста, укажите его номер. Или я могу перевести вас на оператора.',
  'другое': 'Опишите, пожалуйста, ваш вопрос подробнее, и я постараюсь помочь или позову человека.',
};

const INACTIVITY_TIMEOUT = 10 * 60 * 1000; // 10 minutes

const ROLE_LABELS: Record<Role, string> = {
  owner: 'Владелец',
  admin: 'Администратор',
  chef: 'Шеф-повар',
  waiter: 'Официант',
  bartender: 'Бармен',
  tech: 'Тех. поддержка',
  tester: 'Тестировщик',
  developer: 'Разработчик',
  hr: 'Отдел кадров',
  user: 'Пользователь',
  other: 'Сотрудник'
};

const ADMIN_SCRIPTS = [
  "Здравствуйте, сейчас разберусь в вашем вопросе более детально и вернусь к вам",
  "Ваш запрос передан в работу, ожидайте ответа",
  "Уточните, пожалуйста, номер вашего заказа или стола",
  "Проблема решена. Могу ли я еще чем-то вам помочь?",
  "Спасибо за ожидание, я готов ответить на ваши вопросы",
  "Хорошего дня! Если возникнут еще вопросы — обращайтесь.",
  "отменил заказ",
  "вернул деньги",
  "начислил бонусы за заказ"
];

const QUICK_ACTIONS = [
  "Часто задаваемые вопросы",
  "Скидки",
  "Вопрос по заказу",
  "Другое",
  "Обращение в тех поддержку",
  "Обращение к оператору"
];

const STATUS_LABELS: Record<string, { label: string, color: string }> = {
  new: { label: 'Новый чат', color: 'bg-blue-500' },
  processing: { label: 'В обработке', color: 'bg-amber-500' },
  pending: { label: 'На рассмотрении', color: 'bg-purple-500' },
  tech: { label: 'Тех. поддержка', color: 'bg-red-500' },
  resolved: { label: 'Обработан', color: 'bg-emerald-500' },
  operator: { label: 'Оператор', color: 'bg-indigo-500' },
  bot: { label: 'Бот', color: 'bg-slate-400' },
  closed: { label: 'Закрыт', color: 'bg-slate-700' }
};

export default function SupportChat({ currentUser }: SupportChatProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editInputText, setEditInputText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [isBotProcessing, setIsBotProcessing] = useState(false);
  const [isBugReporting, setIsBugReporting] = useState(false);
  const [rating, setRating] = useState<number>(0);
  const [showArchive, setShowArchive] = useState(false);
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    onConfirm: () => void | Promise<void>;
  } | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { addOrder, logAction, addNotification, quotaExceeded, authInitialized, firebaseUser, mappingSynced } = useCafeStore();

  const [retryTrigger, setRetryTrigger] = useState(0);
  const lastRetryTimeRef = useRef<number>(0);
  const retryCountRef = useRef<number>(0);

  const handlePermissionDenied = (source: string) => {
    const now = Date.now();
    if (retryCountRef.current < 5 && now - lastRetryTimeRef.current > 800) {
      retryCountRef.current += 1;
      lastRetryTimeRef.current = now;
      console.warn(`SupportChat ${source}: Permission denied. Retrying subscription in 1s (attempt ${retryCountRef.current}/5)...`);
      setTimeout(() => {
        setRetryTrigger(prev => prev + 1);
      }, 1000);
    } else {
      console.warn(`SupportChat ${source}: Access denied permanently or retry limit reached.`);
    }
  };

  const effectiveRole = getEffectiveRole(currentUser);
  const isOwner = effectiveRole === 'owner';
  const isAdmin = effectiveRole === 'admin' || isOwner || effectiveRole === 'developer' || effectiveRole === 'tester';
  const isTech = effectiveRole === 'tech';
  const isOperatorSide = isAdmin || isTech;
  const mySessionId = currentUser?.id || firebaseUser?.uid || auth.currentUser?.uid || 'anonymous';

  // Scroll to bottom when chat opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(scrollToBottom, 300);
    }
  }, [isOpen]);

  // Greeting for new sessions
  useEffect(() => {
    if (!isOpen || isOperatorSide || !mySessionId || !authInitialized) return;
    
    const checkAndGreet = async () => {
      if (quotaExceeded) return;
      try {
        const messagesRef = collection(db, 'messages');
        const q = query(messagesRef, where('targetUserId', '==', mySessionId), limit(1));
        const snap = await getDocs(q);
        
        if (snap.empty && !quotaExceeded) {
          await addDoc(messagesRef, {
            senderId: 'bot',
            senderName: 'Бот-помощник',
            senderRole: 'other',
            text: 'Здравствуйте! Я ваш электронный помощник. Выберите интересующий вас раздел ниже или напишите свой вопрос.',
            timestamp: Date.now(),
            isBot: true,
            targetUserId: mySessionId
          });
        }
      } catch (err) {
        console.error('SupportChat checkAndGreet error:', err);
      }
    };
    
    checkAndGreet();
  }, [isOpen, isOperatorSide, mySessionId, authInitialized]);

  // Listen for messages
  useEffect(() => {
    if (!authInitialized || (isOperatorSide && !mappingSynced)) {
      setMessages([]);
      return;
    }
    let q;
    if (isOperatorSide) {
      if (activeSessionId) {
        // Operator sees messages for active session
        q = query(
          collection(db, 'messages'),
          where('targetUserId', '==', activeSessionId),
          orderBy('timestamp', 'desc'),
          limit(200)
        );
      } else {
        setMessages([]);
        return;
      }
    } else if (mySessionId) {
      // User sees their own messages
      q = query(
        collection(db, 'messages'),
        where('targetUserId', '==', mySessionId),
        orderBy('timestamp', 'desc'),
        limit(200)
      );
    }

    if (!q) return;

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs: Message[] = [];
      snapshot.forEach((doc) => {
        msgs.push({ id: doc.id, ...doc.data() } as Message);
      });
      // Reverse to show ascending in UI
      setMessages(msgs.reverse());
      setTimeout(scrollToBottom, 100);
    }, (error) => {
      if (error?.code === 'permission-denied') {
        setMessages([]);
        handlePermissionDenied('messages');
      } else {
        console.error('SupportChat messages error:', error);
      }
    });

    return () => unsubscribe();
  }, [isOperatorSide, mySessionId, activeSessionId, authInitialized, firebaseUser, retryTrigger, mappingSynced]);

  // Listen for sessions
  useEffect(() => {
    if (!authInitialized || (isOperatorSide && !mappingSynced)) {
      setSessions([]);
      return;
    }
    let q;
    if (isOperatorSide) {
      // В архиве админ и тех видит вообще все сессии, чтобы понимать историю
      if (showArchive) {
        q = query(collection(db, 'chatSessions'), orderBy('lastActivity', 'desc'));
      } else {
        q = query(collection(db, 'chatSessions'), where('status', 'in', ['new', 'operator', 'tech', 'bot', 'processing', 'pending']));
      }
    } else if (mySessionId) {
      // Users see only theirs
      q = query(collection(db, 'chatSessions'), where('id', '==', mySessionId));
    }

    if (!q) return;

    const unsubscribe = onSnapshot(q as any, (snapshot: any) => {
      const sess: ChatSession[] = [];
      snapshot.forEach((doc: any) => {
        const data = { id: doc.id, ...doc.data() } as ChatSession;
        sess.push(data);
        
        // Синхронизируем рейтинг для текущего пользователя
        if (!isOperatorSide && doc.id === mySessionId) {
          if (data.rating !== undefined) {
            setRating(data.rating);
          } else {
            setRating(0);
          }
        }
      });
      setSessions(sess);
      
      if (!isOperatorSide && sess.length > 0) {
        setActiveSessionId(mySessionId);
      }
    }, (error: any) => {
      if (error?.code === 'permission-denied') {
        setSessions([]);
        handlePermissionDenied('sessions');
      } else {
        console.error('SupportChat sessions error:', error);
      }
    });

    return () => unsubscribe();
  }, [isOperatorSide, mySessionId, showArchive, authInitialized, firebaseUser, retryTrigger, mappingSynced]);

  // Clear active session when toggling archive view to prevent "ghosting"
  useEffect(() => {
    if (isOperatorSide) {
      setActiveSessionId(null);
    }
  }, [showArchive, isOperatorSide]);

  // Ensure active session is valid for current list
  useEffect(() => {
    if (isOperatorSide && activeSessionId && sessions.length > 0) {
      const exists = sessions.some(s => s.id === activeSessionId);
      if (!exists) {
        setActiveSessionId(null);
      }
    }
  }, [sessions, activeSessionId, isOperatorSide]);

  // Auto-select first session for admin/tech
  useEffect(() => {
    if (isOperatorSide && !activeSessionId && sessions.length > 0) {
      if (!showArchive) {
        // Select first active session
        const firstActive = sessions.find(s => s.status === 'operator' || s.status === 'tech');
        if (firstActive) {
          setActiveSessionId(firstActive.id);
        } else {
          // If no operator/tech status, maybe select first bot status if any
          const firstBot = sessions.find(s => s.status === 'bot');
          if (firstBot) setActiveSessionId(firstBot.id);
        }
      } else {
        setActiveSessionId(sessions[0].id);
      }
    }
  }, [isOperatorSide, sessions, activeSessionId, showArchive]);

  // Inactivity check (for non-operator side)
  useEffect(() => {
    if (isOperatorSide) return;

    const interval = setInterval(async () => {
      if (!mySessionId) return;
      const sessionDoc = await getDoc(doc(db, 'chatSessions', String(mySessionId)));
      if (sessionDoc.exists()) {
        const data = sessionDoc.data() as ChatSession;
        if ((data.status === 'operator' || data.status === 'tech') && Date.now() - data.lastActivity > INACTIVITY_TIMEOUT && !quotaExceeded) {
          await updateDoc(doc(db, 'chatSessions', String(mySessionId)), {
            status: 'bot',
            lastActivity: Date.now()
          });
          
          await addDoc(collection(db, 'messages'), {
            senderId: 'system',
            senderName: 'Система',
            senderRole: 'other',
            text: 'Чат переведен обратно на бота из-за неактивности.',
            timestamp: Date.now(),
            isBot: true,
            targetUserId: String(mySessionId)
          });
        }
      }
    }, 60000);

    return () => clearInterval(interval);
  }, [isOperatorSide, mySessionId]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const currentSession = sessions.find(s => s.id === (isOperatorSide ? activeSessionId : mySessionId));

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Файл слишком большой. Максимальный размер 2МБ');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeleteMessage = async (messageId: string) => {
    setConfirmDialog({
      isOpen: true,
      title: 'Удалить сообщение',
      message: 'Вы уверены, что хотите удалить это сообщение? Это действие необратимо.',
      confirmText: 'Удалить',
      cancelText: 'Отмена',
      onConfirm: async () => {
        if (quotaExceeded) return;
        try {
          await deleteDoc(doc(db, 'messages', messageId));
        } catch (error) {
          console.error('Error deleting message:', error);
        }
      }
    });
  };

  const startEditing = (msg: Message) => {
    setEditingMessageId(msg.id);
    setEditInputText(msg.text);
  };

  const cancelEditing = () => {
    setEditingMessageId(null);
    setEditInputText('');
  };

  const handleUpdateMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMessageId || !editInputText.trim() || quotaExceeded) return;

    try {
      await updateDoc(doc(db, 'messages', editingMessageId), {
        text: editInputText.trim(),
        isEdited: true
      });
      setEditingMessageId(null);
      setEditInputText('');
    } catch (error) {
      console.error('Error updating message:', error);
    }
  };

  const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!inputText.trim() && !selectedImage) || isBotProcessing) return;

    const text = inputText.trim();
    const targetId = isOperatorSide ? activeSessionId : mySessionId;
    
    if (!targetId) return;
    const finalTargetId = targetId;

    const userMessage: any = {
      senderId: currentUser.id || 'anonymous',
      senderName: currentUser.name,
      senderRole: currentUser.role,
      text: text,
      timestamp: Date.now(),
      isBot: false,
      targetUserId: finalTargetId
    };

    if (selectedImage) {
      userMessage.imageUrl = selectedImage;
    }

    try {
      if (!quotaExceeded) {
        await addDoc(collection(db, 'messages'), userMessage);
      }
      
      setInputText('');
      setSelectedImage(null);

      if (finalTargetId) {
        let newStatus = currentSession?.status || 'bot';
        
        // Если пишет пользователь в закрытый или отработанный чат - переводим в статус нового
        if (!isOperatorSide && (newStatus === 'closed' || newStatus === 'resolved')) {
          newStatus = 'new';
        }

        // Если пишет админ или техподдержка в закрытый чат или чат с ботом - переводим на человека
        if (isOperatorSide && (newStatus === 'bot' || newStatus === 'closed')) {
          newStatus = isTech ? 'tech' : 'operator';
        }

        const sessionUpdate: any = {
          id: finalTargetId,
          userName: isOperatorSide ? (currentSession?.userName || 'Пользователь') : currentUser.name,
          userRole: isOperatorSide ? (currentSession?.userRole || 'user') : currentUser.role,
          status: newStatus,
          lastActivity: Date.now()
        };
        
        if (!currentSession?.sessionStartTime) {
          sessionUpdate.sessionStartTime = Date.now();
        }
        
        if (!quotaExceeded) {
          await setDoc(doc(db, 'chatSessions', finalTargetId), sessionUpdate, { merge: true });
        }
        
        await logAction(currentUser, 'Сообщение в чат', `Текст: ${text.substring(0, 50)}${text.length > 50 ? '...' : ''} ${quotaExceeded ? '(ЛОКАЛЬНО)' : ''}`);

        // Notification for new message
        if (isOperatorSide) {
          // Notify user
          addNotification({
            title: 'Новое сообщение от поддержки',
            message: text.substring(0, 60) + (text.length > 60 ? '...' : ''),
            type: 'chat',
            targetRoles: [currentSession?.userRole || 'user'] as any
          });
        } else if (newStatus === 'operator' || newStatus === 'tech') {
          // Notify operators
          addNotification({
            title: `Сообщение от ${currentUser.name}`,
            message: text.substring(0, 60) + (text.length > 60 ? '...' : ''),
            type: 'chat',
            targetRoles: newStatus === 'tech' ? ['tech'] : ['owner', 'admin']
          });
        }
      }

      // Только если пользователь общается с ботом (или чат переоткрыт), запускаем логику автоответов
      const isAutoReplyNeeded = !isOperatorSide && (
        !currentSession || 
        currentSession.status === 'bot' || 
        currentSession.status === 'closed' ||
        currentSession.status === 'resolved' ||
        currentSession.status === 'new'
      ) && currentUser.id !== 'bot'; // Prevent bot from replying to itself

      if (isAutoReplyNeeded) {
        const lowerText = text.toLowerCase();
        
        // Если чат был закрыт, обработан или уже оценен, сбрасываем историю для пользователя (новая сессия)
        if (mySessionId && (currentSession?.status === 'closed' || currentSession?.status === 'resolved' || (currentSession?.status === 'bot' && rating > 0)) && !quotaExceeded) {
          const newStartTime = Date.now();
          await updateDoc(doc(db, 'chatSessions', mySessionId), {
            status: 'new',
            rating: 0, 
            lastActivity: newStartTime,
            sessionStartTime: newStartTime 
          });
          setRating(0);
        }

        if (isBugReporting) {
          // Обработка деталей ошибки
          setIsBotProcessing(true);
          setTimeout(async () => {
            try {
              // Instead of fetching all tickets (which might be denied and is slow),
              // we generate a unique number based on timestamp or a simple random component.
              const ticketId = generateId();
              const ticketNumber = Math.floor(Math.random() * 90000 + 10000).toString(); // 5 digit number
              
              const newTicket: Ticket = {
                id: ticketId,
                ticketNumber: ticketNumber,
                title: 'Отчет об ошибке из чата',
                description: text,
                creatorId: currentUser.id,
                creatorName: currentUser.name,
                creatorRole: currentUser.role,
                status: 'new',
                priority: 'medium',
                comments: [],
                timestamp: Date.now(),
                updatedAt: Date.now()
              };

              await setDoc(doc(db, 'tickets', ticketId), newTicket);

              addNotification({
                title: 'Новый тикет об ошибке',
                message: `Создан автоматически из чата от ${currentUser.name}`,
                type: 'ticket',
                targetRoles: ['owner', 'admin', 'tech', 'developer']
              });

              if (!quotaExceeded) {
                await addDoc(collection(db, 'messages'), {
                  senderId: 'bot',
                  senderName: 'Бот-помощник',
                  senderRole: 'other',
                  text: `Спасибо за детали! Я создал тикет №${newTicket.ticketNumber} для нашей технической службы. Разработчики изучат проблему. Если у вас еще будут вопросы — я на связи!`,
                  timestamp: Date.now(),
                  isBot: true,
                  targetUserId: mySessionId
                });
              }

              setIsBugReporting(false);
            } catch (err) {
              console.error('Error creating ticket from chat:', err);
              if (!quotaExceeded) {
                await addDoc(collection(db, 'messages'), {
                  senderId: 'bot',
                  senderName: 'Бот-помощник',
                  senderRole: 'other',
                  text: 'Извините, при создании тикета произошла ошибка. Пожалуйста, обратитесь к оператору.',
                  timestamp: Date.now(),
                  isBot: true,
                  targetUserId: mySessionId
                });
              }
            } finally {
              setIsBotProcessing(false);
            }
          }, 1000);
          return;
        }

        const bugKeywords = ['ошибка', 'баг', 'не работает', 'сломалось', 'найдена ошибка', 'глюк', 'косяк', 'проблема'];
        const isPotentialBug = bugKeywords.some(s => lowerText.includes(s));

        // Логика консультации по тикетам
        const ticketMatch = lowerText.match(/(?:#|тикет\s+)?(\d{5})/);
        
        if (ticketMatch) {
          const tNumber = ticketMatch[1];
          setIsBotProcessing(true);
          setTimeout(async () => {
            try {
              const q = query(collection(db, 'tickets'), where('ticketNumber', '==', tNumber));
              const snap = await getDocs(q);
              
              if (!snap.empty) {
                const ticketData = snap.docs[0].data() as Ticket;
                const statusMap: Record<string, string> = {
                  new: 'Новый (ожидает распределения)',
                  investigating: 'В работе (специалист изучает проблему)',
                  commented: 'Получен ответ (ожидает вашей реакции)',
                  resolved: 'Решен (проблема устранена)',
                  closed: 'Закрыт (архив)'
                };
                
                const responseText = `Я нашел информацию по тикету №${tNumber}:
• Тема: ${ticketData.title}
• Статус: ${statusMap[ticketData.status] || ticketData.status}
• Последнее обновление: ${new Date(ticketData.updatedAt).toLocaleString()}
${ticketData.assignedToName ? `• Ответственный: ${ticketData.assignedToName}` : ''}

Вы хотели бы связаться с ответственным специалистом для уточнения деталей? Напишите "Да", если это необходимо.`;
                
                if (!quotaExceeded) {
                  await addDoc(collection(db, 'messages'), {
                    senderId: 'bot',
                    senderName: 'Бот-помощник',
                    senderRole: 'other',
                    text: responseText,
                    timestamp: Date.now(),
                    isBot: true,
                    targetUserId: mySessionId
                  });
                }

                if (ticketData.assignedToId) {
                  await updateDoc(doc(db, 'chatSessions', String(mySessionId)), {
                    pendingTransferId: ticketData.assignedToId,
                    lastActivity: Date.now()
                  });
                }
              } else {
                if (!quotaExceeded) {
                  await addDoc(collection(db, 'messages'), {
                    senderId: 'bot',
                    senderName: 'Бот-помощник',
                    senderRole: 'other',
                    text: `Простите, но тикет №${tNumber} не найден в нашей базе данных. Пожалуйста, убедитесь, что номер указан верно. Обратите внимание, что системные тикеты состоят из 5 цифр.`,
                    timestamp: Date.now(),
                    isBot: true,
                    targetUserId: mySessionId
                  });
                }
              }
            } catch (err) {
              console.error('Error looking up ticket:', err);
            } finally {
              setIsBotProcessing(false);
            }
          }, 1000);
          return;
        }

        // Логика перевода на ответственного за тикет (при согласии или "да")
        if (currentSession?.pendingTransferId && (lowerText === 'да' || lowerText.includes('переведи') || lowerText.includes('хочу'))) {
          const staffId = currentSession.pendingTransferId;
          setIsBotProcessing(true);
          
          setTimeout(async () => {
            try {
              const staffDoc = await getDoc(doc(db, 'staff', staffId));
              const staffData = staffDoc.data() as Staff;
              
              if (!quotaExceeded) {
                await updateDoc(doc(db, 'chatSessions', String(mySessionId)), {
                  status: 'operator',
                  assignedOperatorId: staffId,
                  pendingTransferId: null,
                  lastActivity: Date.now()
                });
              }

              addNotification({
                title: 'Прямой запрос по тикету',
                message: `Пользователь ${currentUser.name} переведен на вас для обсуждения тикета.`,
                type: 'chat',
                targetRoles: [staffData?.role || 'admin'] as any
              });

              if (!quotaExceeded) {
                await addDoc(collection(db, 'messages'), {
                  senderId: 'bot',
                  senderName: 'Бот-помощник',
                  senderRole: 'other',
                  text: `Соединяю вас с ${staffData?.name || 'специалистом'}. Пожалуйста, подождите, пока он изучит историю переписки и ответит вам.`,
                  timestamp: Date.now(),
                  isBot: true,
                  targetUserId: mySessionId
                });
              }
            } catch (err) {
              console.error('Error transferring to assigned staff:', err);
            } finally {
              setIsBotProcessing(false);
            }
          }, 800);
          return;
        }

        // Если пользователь просто хочет узнать о сайте или логике (Guide mode)
        const guideKeywords = ['как работает', 'что это', 'логика', 'инструкция', 'расскажи', 'руководство', 'покажи'];
        const isGuideRequest = guideKeywords.some(s => lowerText.includes(s));

        if (isGuideRequest) {
          setTimeout(async () => {
            const guideText = `Я могу рассказать вам о логике работы системы CafeMaster:
1. **Заказы**: Создаются в разделе "Заказы". После создания они попадают на Кухню.
2. **Кухня**: Здесь повара видят заказы, включают таймеры и отмечают готовность.
3. **Склад**: Все продукты списываются автоматически согласно тех-картам блюд при продаже.
4. **Персонал**: Администраторы могут управлять ролями и доступами сотрудников.
5. **Аналитика**: В разделе статистики отображаются доходы, популярные блюда и KPI сотрудников.

О каком разделе вы хотите узнать подробнее?`;

            if (!quotaExceeded) {
              await addDoc(collection(db, 'messages'), {
                senderId: 'bot',
                senderName: 'Бот-помощник',
                senderRole: 'other',
                text: guideText,
                timestamp: Date.now(),
                isBot: true,
                targetUserId: mySessionId
              });
            }
          }, 1000);
          return;
        }

        if (isPotentialBug) {
          setIsBugReporting(true);
          setTimeout(async () => {
            if (!quotaExceeded) {
              await addDoc(collection(db, 'messages'), {
                senderId: 'bot',
                senderName: 'Бот-помощник',
                senderRole: 'other',
                text: 'Я заметил, что вы столкнулись с проблемой. Пожалуйста, опишите максимально подробно: что именно произошло, на какой странице и после каких действий? Я сразу создам тикет для наших разработчиков.',
                timestamp: Date.now(),
                isBot: true,
                targetUserId: mySessionId
              });
            }
          }, 800);
          return;
        }

        const operatorSynonyms = ['оператор', 'позови оператора', 'помощь', 'связаться', 'поддержка', 'человек', 'специалист', 'админ', 'обращение к оператору'];
        const techSynonyms = ['тех. поддержка', 'техподдержка', 'обращение в тех поддержку'];
        
        const isOperatorRequest = operatorSynonyms.some(s => lowerText.includes(s));
        const isTechRequest = techSynonyms.some(s => lowerText.includes(s));

        if (isOperatorRequest || isTechRequest) {
          const targetStatus: ChatSession['status'] = isTechRequest ? 'tech' : 'operator';
          
          if (mySessionId) {
            await setDoc(doc(db, 'chatSessions', mySessionId), {
              id: mySessionId,
              userName: currentUser.name,
              userRole: currentUser.role,
              status: targetStatus,
              lastActivity: Date.now()
            });

            addNotification({
              title: isTechRequest ? 'Запрос в тех. поддержку' : 'Новый запрос в чат',
              message: `Сотрудник ${currentUser.name} (${ROLE_LABELS[currentUser.role] || currentUser.role}) ожидает ответа`,
              type: 'chat',
              targetRoles: isTechRequest ? ['tech'] : ['owner', 'admin']
            });

            setTimeout(async () => {
              if (mySessionId) {
                if (!quotaExceeded) {
                  await addDoc(collection(db, 'messages'), {
                    senderId: 'system',
                    senderName: 'Система',
                    senderRole: 'other',
                    text: isTechRequest ? 'Вы были переведены на технического специалиста.' : 'Вы были переведены на оператора. Пожалуйста, подождите, оператор скоро ответит.',
                    timestamp: Date.now(),
                    isBot: true,
                    targetUserId: mySessionId
                  });
                }
              }
            }, 500);
          }
        } else if (lowerText.includes('блюдо от шефа') || lowerText.includes('блюдо шефа')) {
          // Специальная логика заказа блюда от шефа
          setIsBotProcessing(true);
          setTimeout(async () => {
            try {
              // 1. Проверяем количество блюд от шефа в готовке (cooking)
              const ordersSnap = await getDocs(collection(db, 'orders'));
              const activeOrders = ordersSnap.docs.map(d => d.data());
              
              const chefDishesInPrep = activeOrders.filter(o => 
                o.status === 'cooking' && 
                o.items.some((item: any) => item.name === 'Блюдо от шефа')
              ).length;

              if (chefDishesInPrep >= 3) {
                if (!quotaExceeded) {
                  await addDoc(collection(db, 'messages'), {
                    senderId: 'bot',
                    senderName: 'Бот-помощник',
                    senderRole: 'other',
                    text: 'К сожалению, на данный момент кухня переполнена заказами именно на "Блюдо от шефа". Пожалуйста, закажите данное блюдо позднее.',
                    timestamp: Date.now(),
                    isBot: true,
                    targetUserId: mySessionId
                  });
                }
                return;
              }

              // 2. Создаем заказ
              const chefDishName = 'Блюдо от шефа';
              const chefPrice = 1200; // Примерная цена
              const currentOrdersCount = activeOrders.length;
              const orderNumber = (currentOrdersCount + 1).toString().padStart(4, '0');
              const orderId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
              
              const newOrder: Order = {
                id: orderId,
                orderNumber: '', // Будет присвоен в addOrder
                tableNumber: 4, // Виртуальный стол для чата (не 0)
                status: 'pending',
                timestamp: Date.now(),
                subtotal: chefPrice,
                total: chefPrice,
                guests: 1,
                items: [
                  { 
                    dishId: 'chef-special-dish', 
                    name: chefDishName, 
                    quantity: 1, 
                    price: chefPrice
                  }
                ]
              };

              const botUser: Staff = {
                id: 'bot',
                name: 'Бот-помощник',
                role: 'other',
                position: 'Бот',
                phone: '',
                login: 'bot_system'
              };

              await logAction(botUser, 'Создание заказа шефа через бота', `Стол №4`);

              const finalOrderNumber = await addOrder(newOrder, botUser);
              
              addNotification({
                title: 'Заказ от бота',
                message: `Бот оформил "Блюдо от шефа". Заказ №${finalOrderNumber}`,
                type: 'order',
                targetRoles: ['owner', 'admin', 'chef', 'bartender', 'waiter', 'tech']
              });

              if (!quotaExceeded) {
                await addDoc(collection(db, 'messages'), {
                  senderId: 'bot',
                  senderName: 'Бот-помощник',
                  senderRole: 'other',
                  text: `Ваш заказ на "${chefDishName}" успешно создан! Номер вашего заказа: №${finalOrderNumber}. Ожидайте готовности.`,
                  timestamp: Date.now(),
                  isBot: true,
                  targetUserId: mySessionId
                });
              }

            } catch (err) {
              console.error('Bot Chef Order Error:', err);
            } finally {
              setIsBotProcessing(false);
            }
          }, 1000);
        } else {
          let found = false;
          for (const [key, value] of Object.entries(FAQ_RESPONSES)) {
            if (lowerText.includes(key)) {
              setTimeout(async () => {
                if (!quotaExceeded) {
                  await addDoc(collection(db, 'messages'), {
                    senderId: 'bot',
                    senderName: 'Бот-помощник',
                    senderRole: 'other',
                    text: value,
                    timestamp: Date.now(),
                    isBot: true,
                    targetUserId: mySessionId
                  });
                }
              }, 1000);
              found = true;
              break;
            }
          }
          
          if (!found) {
            setTimeout(async () => {
              const botText = 'К сожалению, я не нашел ответа на ваш вопрос в своей базе знаний. Пожалуйста, попробуйте переформулировать его или напишите "оператор", чтобы я переключил вас на человека.';

              if (!quotaExceeded) {
                await addDoc(collection(db, 'messages'), {
                  senderId: 'bot',
                  senderName: 'Бот-помощник',
                  senderRole: 'other',
                  text: botText,
                  timestamp: Date.now(),
                  isBot: true,
                  targetUserId: mySessionId
                });
              }
            }, 1000);
          }
        }
      }
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleStatusChange = async (newStatus: ChatSession['status']) => {
    if (!activeSessionId || quotaExceeded) return;
    try {
      await updateDoc(doc(db, 'chatSessions', activeSessionId), {
        status: newStatus,
        lastActivity: Date.now()
      });

      await addDoc(collection(db, 'messages'), {
        senderId: 'system',
        senderName: 'Система',
        senderRole: 'other',
        text: `Статус чата изменен на: ${STATUS_LABELS[newStatus]?.label || newStatus}`,
        timestamp: Date.now(),
        isBot: true,
        targetUserId: activeSessionId
      });
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const handleDeleteSession = async () => {
    if (!activeSessionId || quotaExceeded) return;
    setConfirmDialog({
      isOpen: true,
      title: 'Удалить чат поддержки',
      message: 'Вы уверены, что хотите полностью удалить этот чат поддержки и все его сообщения? Это действие необратимо.',
      confirmText: 'Удалить',
      cancelText: 'Отмена',
      onConfirm: async () => {
        try {
          const sessionId = activeSessionId;
          // 1. Delete all messages for this session
          const q = query(collection(db, 'messages'), where('targetUserId', '==', sessionId));
          const snap = await getDocs(q);
          const batch = writeBatch(db);
          snap.docs.forEach(docMsg => {
            batch.delete(docMsg.ref);
          });
          await batch.commit();
          
          // 2. Delete the session document itself
          await deleteDoc(doc(db, 'chatSessions', sessionId));
          
          // Clear active selection
          setActiveSessionId(null);
        } catch (err) {
          console.error('Delete session error:', err);
          setConfirmDialog({
            isOpen: true,
            title: 'Ошибка',
            message: 'Произошла ошибка при попытке удалить чат. Пожалуйста, попробуйте еще раз.',
            confirmText: 'ОК',
            onConfirm: () => {}
          });
        }
      }
    });
  };

  const handleCloseChat = async () => {
    if (!activeSessionId || currentSession?.status === 'closed' || quotaExceeded) return;
    
    await updateDoc(doc(db, 'chatSessions', activeSessionId), {
      status: 'closed',
      lastActivity: Date.now()
    });
    
    await addDoc(collection(db, 'messages'), {
      senderId: 'system',
      senderName: 'Система',
      senderRole: 'other',
      text: 'Чат закрыт оператором. Пожалуйста, оцените качество обслуживания.',
      timestamp: Date.now(),
      isBot: true,
      targetUserId: activeSessionId
    });
    
    // Мы НЕ сбрасываем activeSessionId сразу, чтобы админ не терял контекст
    // Однако, так как статус стал 'closed', он исчезнет из списка "Активных"
  };

  const handleTransferToTech = async () => {
    if (!activeSessionId || quotaExceeded) return;
    await updateDoc(doc(db, 'chatSessions', activeSessionId), {
      status: 'tech',
      lastActivity: Date.now()
    });

    addNotification({
      title: 'Перевод на тех. поддержку',
      message: `Чат пользователя ${currentSession?.userName} переведен на вас`,
      type: 'chat',
      targetRoles: ['tech']
    });

    await addDoc(collection(db, 'messages'), {
      senderId: 'system',
      senderName: 'Система',
      senderRole: 'other',
      text: 'Вы были переведены на Технического специалиста, ожидайте ответа.',
      timestamp: Date.now(),
      isBot: true,
      targetUserId: activeSessionId
    });

    if (isAdmin || isTech) setActiveSessionId(null);
  };

  const handleRate = async (value: number) => {
    if (quotaExceeded) {
        setRating(value);
        return;
    }
    setRating(value);
    await updateDoc(doc(db, 'chatSessions', mySessionId), {
      rating: value,
      status: 'bot',
      lastActivity: Date.now()
    });
    
    await addDoc(collection(db, 'messages'), {
      senderId: 'system',
      senderName: 'Система',
      senderRole: 'other',
      text: `Спасибо за вашу оценку: ${value} звезд! Теперь вы можете продолжить общение с ботом или позвать оператора.`,
      timestamp: Date.now(),
      isBot: true,
      targetUserId: mySessionId
    });
  };

  const filteredMessages = messages.filter(m => {
    const targetId = (isAdmin || isTech) ? activeSessionId : mySessionId;
    if (!targetId) return false;
    
    const isRelevant = m.targetUserId === targetId || m.senderId === targetId;
    if (!isRelevant) return false;

    // Для пользователя фильтруем сообщения по времени начала текущей сессии
    // Если сессия еще не создана, показываем все релевантные сообщения
    if (!isAdmin && !isTech) {
      if (!currentSession) return true;
      const startTime = currentSession.sessionStartTime || 0;
      return m.timestamp >= startTime;
    }

    return true;
  });

  return (
    <>
      {/* Overlay to close on click outside */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-[90] bg-transparent"
          onClick={() => setIsOpen(false)}
        />
      )}

      <button
        onClick={() => setIsOpen(true)}
        className={cn(
          "fixed bottom-6 right-6 w-14 h-14 rounded-full bg-indigo-600 text-white shadow-2xl flex items-center justify-center hover:scale-110 transition-all z-[100] group",
          isOpen && "scale-0 opacity-0"
        )}
      >
        <MessageCircle size={28} />
        {(isAdmin || isTech) && sessions.length > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full border-2 border-white text-[10px] flex items-center justify-center font-bold">
            {sessions.length}
          </span>
        )}
      </button>

      <div className={cn(
        "fixed bottom-0 right-0 w-full h-[100dvh] sm:bottom-6 sm:right-6 sm:w-[500px] sm:h-[600px] bg-white sm:rounded-2xl shadow-2xl border border-slate-100 flex z-[100] transition-all duration-300 origin-bottom-right overflow-hidden dark:bg-slate-900 dark:border-slate-800",
        !isOpen && "scale-0 opacity-0 pointer-events-none"
      )}>
        {/* Sidebar for Admins/Tech */}
        {(isAdmin || isTech) && (
          <div className="w-1/3 border-r border-slate-100 bg-slate-50 flex flex-col dark:bg-slate-950 dark:border-slate-800">
            <div className="p-4 border-b border-slate-100 bg-white flex items-center justify-between dark:bg-slate-900 dark:border-slate-800">
              <h3 className="font-bold text-[10px] text-slate-400 uppercase tracking-wider">
                {showArchive ? 'Архив' : 'Активные'}
              </h3>
              <button 
                onClick={() => {
                  setShowArchive(!showArchive);
                  setActiveSessionId(null);
                }}
                className={cn("p-1.5 rounded-lg transition-colors", showArchive ? "bg-indigo-100 text-indigo-600 dark:bg-indigo-900 dark:text-indigo-400" : "text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800")}
                title={showArchive ? "Вернуться к активным" : "Показать архив"}
              >
                <Archive size={14} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {sessions.length === 0 ? (
                <div className="p-4 text-center text-slate-400 text-[10px]">Нет {showArchive ? 'архивных' : 'активных'} чатов</div>
              ) : (
                sessions.map(s => (
                  <button
                    key={s.id}
                    onClick={() => setActiveSessionId(s.id)}
                    className={cn(
                      "w-full p-3 text-left hover:bg-white dark:hover:bg-slate-900 transition-colors border-b border-slate-100 dark:border-slate-800",
                      activeSessionId === s.id && "bg-white border-l-4 border-l-indigo-600 dark:bg-slate-900"
                    )}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-bold text-xs text-slate-900 dark:text-slate-100 truncate">{s.userName}</p>
                      <div className="flex gap-1 items-center">
                        <span className={cn(
                          "px-1.5 py-0.5 rounded-full text-[7px] font-black uppercase text-white shadow-sm",
                          STATUS_LABELS[s.status]?.color || 'bg-slate-400'
                        )}>
                          {STATUS_LABELS[s.status]?.label || s.status}
                        </span>
                      </div>
                    </div>
                    {s.userRole && s.userRole !== 'user' && (
                      <p className="text-[9px] text-indigo-500 font-bold uppercase mb-1">
                        {ROLE_LABELS[s.userRole] || s.userRole}
                      </p>
                    )}
                    {s.rating ? (
                      <div className="flex gap-0.5 mb-1">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} size={8} fill={i < s.rating! ? "currentColor" : "none"} className={i < s.rating! ? "text-amber-400" : "text-slate-200 dark:text-slate-700"} />
                        ))}
                      </div>
                    ) : null}
                    <p className="text-[9px] text-slate-500 dark:text-slate-400">
                      {new Date(s.lastActivity).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </button>
                ))
              )}
            </div>
          </div>
        )}

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col min-w-0">
          <div className="p-4 bg-indigo-600 text-white flex items-center justify-between shrink-0 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                {isAdmin ? <ShieldCheck size={24} /> : (isTech ? <Headphones size={24} /> : <Bot size={24} />)}
              </div>
            <div>
              <h3 className="font-bold text-sm truncate">
                {(isAdmin || isTech) ? (currentSession ? currentSession.userName : 'Выберите чат') : 'Поддержка'}
              </h3>
              <div className="flex items-center gap-1">
                {(isAdmin || isTech) && currentSession ? (
                  <select 
                    value={currentSession.status}
                    onChange={(e) => handleStatusChange(e.target.value as any)}
                    className="bg-white/10 hover:bg-white/20 border-none rounded-full px-2 py-0.5 text-[9px] font-bold text-indigo-100 outline-none cursor-pointer h-5"
                  >
                    {Object.entries(STATUS_LABELS).map(([key, info]) => (
                      <option key={key} value={key} className="text-slate-900 bg-white dark:bg-slate-800 dark:text-white">
                        {info.label.toUpperCase()}
                      </option>
                    ))}
                  </select>
                ) : (
                  <p className="text-[10px] text-indigo-100 uppercase font-bold tracking-wider">
                    {(isAdmin || isTech) && currentSession
                      ? (ROLE_LABELS[currentSession.userRole || 'user'])
                      : (isAdmin ? 'Администратор' : (isTech ? 'Тех. Поддержка' : (currentSession?.status === 'operator' || currentSession?.status === 'tech' ? 'Специалист на связи' : 'Бот-помощник')))}
                  </p>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {(isAdmin || isTech) && currentSession && !showArchive && currentSession.status !== 'closed' && (
                <>
                  <button 
                    onClick={handleTransferToTech}
                    title="Перевести на тех. поддержку"
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors text-indigo-100 hover:text-white"
                  >
                    <Headphones size={18} />
                  </button>
                  <button 
                    onClick={handleCloseChat}
                    title="Закрыть чат"
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors text-indigo-100 hover:text-white"
                  >
                    <CheckCircle2 size={18} />
                  </button>
                </>
              )}
              {(isAdmin || isTech) && currentSession && (
                <button 
                  onClick={handleDeleteSession}
                  title="Удалить этот чат поддержки навсегда"
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors text-rose-300 hover:text-rose-100"
                >
                  <Trash2 size={18} />
                </button>
              )}
              <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                <X size={18} />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50 dark:bg-slate-950/50">
            {(isAdmin || isTech) && (!activeSessionId || !currentSession) ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center p-8">
                <MessageCircle size={48} className="mb-4 opacity-20" />
                <p className="text-sm">Выберите {showArchive ? 'архивную' : 'активную'} сессию в списке слева</p>
              </div>
            ) : (
              <>
                {filteredMessages.map((msg) => {
                  const isMe = msg.senderId === currentUser.id;
                  const isSystem = msg.senderId === 'system';
                  const isTechMsg = msg.senderRole === 'tech';

                  if (isSystem) {
                    return (
                      <div key={msg.id} className="flex justify-center">
                        <span className="text-[10px] bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-3 py-1 rounded-full font-medium">
                          {msg.text}
                        </span>
                      </div>
                    );
                  }

                  return (
                    <div key={msg.id} className={cn(
                      "flex flex-col max-w-[85%]",
                      isMe ? "ml-auto items-end" : "items-start"
                    )}>
                      <div className={cn(
                        "flex items-center gap-1.5 mb-1 text-[10px] font-bold text-slate-400 dark:text-slate-500",
                        isMe && "flex-row-reverse"
                      )}>
                        {msg.isBot ? <Bot size={10} /> : <User size={10} />}
                        <span>
                          {isMe ? 'Вы' : msg.senderName}
                          {!isMe && !msg.isBot && msg.senderRole && (
                            <span className="ml-1 opacity-70 font-normal">
                              ({ROLE_LABELS[msg.senderRole] || msg.senderRole})
                            </span>
                          )}
                        </span>
                        {isTechMsg && <Headphones size={10} className="text-red-500" />}
                      </div>
                      <div className={cn(
                        "p-4 rounded-2xl text-[17px] leading-relaxed shadow-sm group/msg relative",
                        isMe ? "bg-indigo-600 text-white rounded-tr-none" : "bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-100 dark:border-slate-700 rounded-tl-none"
                      )}>
                        {isMe && isTech && !msg.isBot && !isSystem && (
                          <div className={cn(
                            "absolute -top-3 opacity-0 group-hover/msg:opacity-100 transition-opacity flex gap-2",
                            isMe ? "right-0" : "left-0"
                          )}>
                            <button 
                              onClick={() => startEditing(msg)}
                              className="p-1.5 bg-white dark:bg-slate-700 shadow-md rounded-full text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 border border-slate-100 dark:border-slate-600"
                            >
                              <Edit3 size={12} />
                            </button>
                            <button 
                              onClick={() => handleDeleteMessage(msg.id)}
                              className="p-1.5 bg-white dark:bg-slate-700 shadow-md rounded-full text-slate-600 dark:text-slate-300 hover:text-red-600 dark:hover:text-red-400 border border-slate-100 dark:border-slate-600"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        )}

                        {editingMessageId === msg.id ? (
                          <form onSubmit={handleUpdateMessage} className="space-y-2">
                            <textarea
                              autoFocus
                              className="w-full bg-indigo-500 text-white border-none rounded-lg p-2 text-sm focus:ring-0 resize-none"
                              value={editInputText}
                              onChange={(e) => setEditInputText(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Escape') cancelEditing();
                                if (e.key === 'Enter' && !e.shiftKey) {
                                  e.preventDefault();
                                  handleUpdateMessage(e as any);
                                }
                              }}
                            />
                            <div className="flex justify-end gap-2">
                              <button type="button" onClick={cancelEditing} className="text-[10px] uppercase font-bold text-indigo-200 hover:text-white">Отмена</button>
                              <button type="submit" className="text-[10px] uppercase font-bold text-white">Сохранить</button>
                            </div>
                          </form>
                        ) : (
                          <>
                            {msg.imageUrl && (
                              <div className="mb-2 rounded-lg overflow-hidden border border-white/20 cursor-zoom-in active:scale-95 transition-transform">
                                <img 
                                  src={msg.imageUrl} 
                                  alt="Attached" 
                                  className="max-w-full h-auto object-contain hover:brightness-95" 
                                  onClick={() => setZoomedImage(msg.imageUrl || null)}
                                />
                              </div>
                            )}
                            <div className="whitespace-pre-wrap">{msg.text}</div>
                          </>
                        )}
                        
                        <div className="flex items-center justify-between gap-4 mt-1">
                          {msg.isEdited && (
                            <span className={cn(
                              "text-[8px] italic",
                              isMe ? "text-indigo-200" : "text-slate-400"
                            )}>изменено</span>
                          )}
                          {msg.timestamp && (
                            <p className={cn(
                              "text-[9px] opacity-60 ml-auto",
                              isMe ? "text-indigo-100" : "text-slate-400"
                            )}>
                              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {!isAdmin && !isTech && currentSession?.status === 'closed' && rating === 0 && (
                  <div className="bg-white dark:bg-slate-800 border-2 border-indigo-100 dark:border-indigo-900 rounded-2xl p-6 text-center space-y-4 animate-in fade-in slide-in-from-bottom-4 transition-colors">
                    <p className="font-bold text-slate-900 dark:text-white">Оцените качество ответа</p>
                    <div className="flex justify-center gap-2">
                      {[1, 2, 3, 4, 5].map((val) => (
                        <button
                          key={val}
                          onClick={() => handleRate(val)}
                          className="p-2 hover:scale-125 transition-transform text-amber-400"
                        >
                          <Star size={24} fill={rating >= val ? "currentColor" : "none"} />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </>
            )}
          </div>

          {(isAdmin || isTech) && activeSessionId && !showArchive && (
          <div className="px-4 py-2 bg-slate-50 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex gap-2 overflow-x-auto no-scrollbar scroll-smooth">
            {ADMIN_SCRIPTS.map((script, idx) => (
              <button
                key={idx}
                onClick={() => setInputText(script)}
                className="whitespace-nowrap px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full text-[11px] font-medium text-slate-600 dark:text-slate-400 hover:border-indigo-500 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all shrink-0 shadow-sm"
              >
                {script.length > 30 ? script.substring(0, 30) + '...' : script}
              </button>
            ))}
          </div>
        )}

        {!isOperatorSide && (!currentSession || currentSession.status === 'bot' || currentSession.status === 'closed') && (
          <div className="px-4 py-2 bg-slate-50 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex gap-2 overflow-x-auto no-scrollbar scroll-smooth">
            {QUICK_ACTIONS.map((action, idx) => (
              <button
                key={idx}
                onClick={async () => {
                  setInputText(action);
                  // Auto-submit quick actions for smoother UX
                  setTimeout(() => {
                    const form = document.querySelector('form[onSubmit*="handleSendMessage"]') as HTMLFormElement;
                    if (form) form.requestSubmit();
                  }, 100);
                }}
                className="whitespace-nowrap px-3 py-1.5 bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-800 rounded-full text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-all shrink-0 shadow-sm"
              >
                {action}
              </button>
            ))}
          </div>
        )}

        <form onSubmit={handleSendMessage} className="p-4 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
          {selectedImage && (
            <div className="mb-2 p-2 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center gap-3 animate-in slide-in-from-bottom-2">
              <div className="relative w-16 h-16 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700">
                <img src={selectedImage} alt="Preview" className="w-full h-full object-cover" />
                <button 
                  type="button"
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-0 right-0 bg-black/50 text-white p-0.5"
                >
                  <X size={12} />
                </button>
              </div>
              <span className="text-xs text-slate-500 dark:text-slate-400 italic">Изображение готово к отправке</span>
            </div>
          )}
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                disabled={((isAdmin || isTech) && !activeSessionId)}
                placeholder={((isAdmin || isTech) && !activeSessionId) ? "Выберите чат..." : "Напишите сообщение..."}
                className="w-full pl-4 pr-12 py-4 bg-slate-100 dark:bg-slate-800 border-none rounded-xl text-lg focus:ring-2 focus:ring-indigo-500/20 dark:focus:ring-indigo-500/10 outline-none transition-all disabled:opacity-50 dark:text-white dark:placeholder:text-slate-500"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
              />
              <button
                type="submit"
                disabled={(!inputText.trim() && !selectedImage) || ((isAdmin || isTech) && !activeSessionId)}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center hover:bg-indigo-700 disabled:opacity-50 disabled:hover:bg-indigo-600 transition-colors"
              >
                <Send size={16} />
              </button>
            </div>
            
            <label className={cn(
              "p-4 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-all cursor-pointer",
              ((isAdmin || isTech) && !activeSessionId) && "opacity-50 pointer-events-none"
            )}>
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                onChange={handleImageSelect}
              />
              <Paperclip size={20} />
            </label>
          </div>
        </form>
      </div>
    </div>
    <AnimatePresence>
      {zoomedImage && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 cursor-zoom-out"
            onClick={() => setZoomedImage(null)}
          />
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="relative max-w-full max-h-full z-10 flex flex-col items-center justify-center"
          >
            <button 
              onClick={() => setZoomedImage(null)}
              className="absolute top-4 right-4 bg-black/60 hover:bg-black text-white hover:text-indigo-400 p-2 rounded-full transition-all"
            >
              <X size={24} />
            </button>
            <img 
              src={zoomedImage} 
              className="max-w-[95vw] max-h-[85vh] rounded-2xl object-contain border border-white/10 shadow-2xl" 
              alt="Zoomed"
            />
          </motion.div>
        </div>
      )}

      {confirmDialog && confirmDialog.isOpen && (
        <div className="fixed inset-0 z-[130] flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0"
            onClick={() => setConfirmDialog(null)}
          />
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="relative w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-2xl z-10 flex flex-col items-center text-center gap-4 animate-in fade-in zoom-in-95 duration-150"
          >
            <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/30 flex items-center justify-center text-rose-500 dark:text-rose-400">
              <Trash2 size={24} />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                {confirmDialog.title}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed px-2">
                {confirmDialog.message}
              </p>
            </div>

            <div className="flex gap-2 w-full mt-2">
              <button
                onClick={() => setConfirmDialog(null)}
                className="flex-1 py-3 px-4 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 transition-all"
              >
                {confirmDialog.cancelText || 'Отмена'}
              </button>
              <button
                onClick={async () => {
                  const onConfirm = confirmDialog.onConfirm;
                  setConfirmDialog(null);
                  await onConfirm();
                }}
                className="flex-1 py-3 px-4 rounded-xl text-xs font-semibold text-white bg-rose-500 hover:bg-rose-600 active:scale-95 transition-all shadow-lg shadow-rose-500/20"
              >
                {confirmDialog.confirmText || 'Удалить'}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  </>
);
}
