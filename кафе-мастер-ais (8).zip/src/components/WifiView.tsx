import React, { useState, useEffect } from 'react';
import { Card, Button, Input, cn } from './UI';
import { Wifi, Lock, ShieldCheck, User, Save, RefreshCw, AlertCircle, QrCode } from 'lucide-react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { Staff } from '../types';
import { getEffectiveRole } from '../lib/auth';
import { QRCodeSVG } from 'qrcode.react';

interface WifiSettings {
  staffSsid: string;
  staffPassword: string;
  customerSsid: string;
  customerPassword: string;
  updatedAt: number;
  updatedBy: string;
}

export default function WifiView({ currentUser }: { currentUser: Staff }) {
  const [settings, setWifiSettings] = useState<WifiSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState<Partial<WifiSettings>>({});
  const [msg, setMsg] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const role = getEffectiveRole(currentUser);
  const canEdit = ['owner', 'admin', 'tech', 'developer'].includes(role);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const docRef = doc(db, 'settings', 'wifi');
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          const data = snap.data() as WifiSettings;
          setWifiSettings(data);
          setFormData(data);
        } else {
          const initial = {
            staffSsid: 'Cafe_Staff_Secure',
            staffPassword: 'staff_pass_2024',
            customerSsid: 'Cafe_Guest_Free',
            customerPassword: '',
            updatedAt: Date.now(),
            updatedBy: 'system'
          };
          setWifiSettings(initial);
          setFormData(initial);
        }
      } catch (err) {
        console.error('Fetch wifi error:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, []);

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!canEdit) return;

    setSaving(true);
    setMsg(null);

    try {
      const newSettings = {
        ...formData,
        updatedAt: Date.now(),
        updatedBy: currentUser.name
      } as WifiSettings;

      await setDoc(doc(db, 'settings', 'wifi'), newSettings);
      setWifiSettings(newSettings);
      setMsg({ type: 'success', text: 'Настройки WiFi успешно сохранены' });
    } catch (err) {
      console.error('Save wifi error:', err);
      setMsg({ type: 'error', text: 'Ошибка при сохранении настроек' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="animate-spin text-indigo-500" size={32} />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center gap-4 mb-2">
        <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-900/40 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
          <Wifi size={24} />
        </div>
        <div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight leading-none">WiFi Сети</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Управление доступом к сети для сотрудников и гостей</p>
        </div>
      </div>

      {msg && (
        <div className={cn(
          "p-4 rounded-2xl flex items-center gap-3 animate-in zoom-in-95 duration-300",
          msg.type === 'success' ? "bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800" : "bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 border border-red-100 dark:border-red-800"
        )}>
          {msg.type === 'success' ? <ShieldCheck size={20} /> : <AlertCircle size={20} />}
          <p className="font-bold text-sm">{msg.text}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Staff Network */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 px-2">
            <Lock size={16} className="text-indigo-500" />
            <h3 className="font-black text-[10px] uppercase text-slate-400 tracking-[0.2em]">Сеть Сотрудников</h3>
          </div>
          <Card className="p-6 space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">SSID (Имя сети)</label>
                <Input 
                  value={formData.staffSsid || ''}
                  onChange={e => setFormData(prev => ({ ...prev, staffSsid: e.target.value }))}
                  disabled={!canEdit}
                  placeholder="Имя сети для персонала"
                  className="font-bold h-12"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Пароль</label>
                <div className="relative">
                  <Input 
                    type="password"
                    value={formData.staffPassword || ''}
                    onChange={e => setFormData(prev => ({ ...prev, staffPassword: e.target.value }))}
                    disabled={!canEdit}
                    placeholder="Пароль сети"
                    className="font-bold h-12 pr-10"
                  />
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                </div>
              </div>
            </div>
            <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 rounded-2xl border border-indigo-100 dark:border-indigo-800/50 space-y-4">
              <p className="text-[10px] text-indigo-600 dark:text-indigo-400 font-bold leading-relaxed italic text-center">
                Эта сеть предназначена только для рабочих устройств: планшетов официантов, терминалов и кухонных мониторов.
              </p>
              
              <div className="flex flex-col items-center gap-2">
                 <div className="bg-white p-2 rounded-xl shadow-inner inline-block">
                    <QRCodeSVG 
                      value={`WIFI:S:${formData.staffSsid};T:WPA;P:${formData.staffPassword};;`} 
                      size={120}
                      level="H"
                    />
                 </div>
                 <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">QR для персонала</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Customer Network */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 px-2">
            <User size={16} className="text-emerald-500" />
            <h3 className="font-black text-[10px] uppercase text-slate-400 tracking-[0.2em]">Гостевая Сеть</h3>
          </div>
          <Card className="p-6 space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">SSID (Имя сети)</label>
                <Input 
                  value={formData.customerSsid || ''}
                  onChange={e => setFormData(prev => ({ ...prev, customerSsid: e.target.value }))}
                  disabled={!canEdit}
                  placeholder="Публичное имя сети"
                  className="font-bold h-12"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Пароль (оставьте пустым для открытой сети)</label>
                <div className="relative">
                  <Input 
                    value={formData.customerPassword || ''}
                    onChange={e => setFormData(prev => ({ ...prev, customerPassword: e.target.value }))}
                    disabled={!canEdit}
                    placeholder="Пароль или пусто"
                    className="font-bold h-12 pr-10"
                  />
                  <Wifi className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                </div>
              </div>
            </div>
            <div className="p-4 bg-emerald-50 dark:bg-emerald-900/10 rounded-2xl border border-emerald-100 dark:border-emerald-800/50 space-y-4">
              <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold leading-relaxed italic text-center">
                Клиенты могут подключаться к этой сети. Рекомендуется использовать систему авторизации (Captive Portal), если оборудование позволяет.
              </p>

              <div className="flex flex-col items-center gap-2">
                 <div className="bg-white p-2 rounded-xl shadow-inner inline-block">
                    <QRCodeSVG 
                      value={`WIFI:S:${formData.customerSsid};T:${formData.customerPassword ? 'WPA' : ''};P:${formData.customerPassword || ''};;`} 
                      size={120}
                      level="H"
                    />
                 </div>
                 <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">QR для гостей</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {canEdit && (
        <div className="flex justify-end pt-4">
          <Button 
            onClick={handleSave} 
            disabled={saving}
            className="h-14 px-10 rounded-2xl shadow-xl shadow-indigo-500/20 font-black uppercase tracking-widest text-sm"
          >
            {saving ? <RefreshCw className="animate-spin mr-2" size={18} /> : <Save className="mr-2" size={18} />}
            Сохранить настройки
          </Button>
        </div>
      )}

      {settings && (
        <div className="text-center text-[10px] text-slate-400 border-t border-slate-100 dark:border-slate-800 pt-6">
          Последнее обновление: {new Date(settings.updatedAt).toLocaleString()} пользователем <b>{settings.updatedBy}</b>
        </div>
      )}
    </div>
  );
}
