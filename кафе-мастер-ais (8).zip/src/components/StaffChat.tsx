import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Message, Staff, ChatRoom } from '../types';
import { Card, Button, Input, cn } from './UI';
import { 
  Send, 
  MessageCircle, 
  Check, 
  CheckCheck, 
  Clock, 
  Plus, 
  Hash, 
  Users, 
  MoreVertical,
  Search,
  ArrowLeft,
  Settings,
  Circle,
  Pin,
  Mic,
  Paperclip,
  X,
  Trash2,
  Edit2,
  UserMinus,
  UserPlus,
  Volume2,
  File as FileIcon,
  Download
} from 'lucide-react';
import { getEffectiveRole } from '../lib/auth';
import { motion, AnimatePresence } from 'motion/react';

interface StaffChatProps {
  rooms: ChatRoom[];
  messages: Message[];
  staff: Staff[];
  sendMessage: (roomId: string, text: string, user: Staff, options?: any) => Promise<void>;
  createRoom: (room: Omit<ChatRoom, 'id' | 'createdAt'>) => Promise<string>;
  updateRoom: (roomId: string, updates: Partial<ChatRoom>) => Promise<void>;
  clearRoomMessages?: (roomId: string) => Promise<void>;
  deleteRoom?: (roomId: string) => Promise<void>;
  pinMessage: (roomId: string, messageId: string) => Promise<void>;
  unpinMessage: (roomId: string) => Promise<void>;
  updateParticipant: (roomId: string, staffId: string, action: 'add' | 'remove') => Promise<void>;
  markAsRead: (messageId: string, userId: string) => Promise<void>;
  currentUser: Staff;
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  onNavigate: (view: any, params?: any) => void;
  targetUserId?: string;
}

export default function StaffChat({ 
  rooms, 
  messages, 
  staff, 
  sendMessage, 
  createRoom, 
  updateRoom,
  clearRoomMessages,
  deleteRoom,
  pinMessage,
  unpinMessage,
  updateParticipant,
  markAsRead, 
  currentUser,
  theme,
  setTheme,
  onNavigate,
  targetUserId
}: StaffChatProps) {
  const [roomSearchQuery, setRoomSearchQuery] = useState('');
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [inputText, setInputText] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showRenameModal, setShowRenameModal] = useState(false);
  const [renameRoomName, setRenameRoomName] = useState('');
  const [showRoomMenu, setShowRoomMenu] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showParticipantsModal, setShowParticipantsModal] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [newRoomName, setNewRoomName] = useState('');
  const [sendingMsgId, setSendingMsgId] = useState<string | null>(null);
  const [isNotificationsEnabled, setIsNotificationsEnabled] = useState(true);
  const [clearingCache, setClearingCache] = useState(false);
  const [isCreatingRoom, setIsCreatingRoom] = useState(false);
  
  const [isMediaLoading, setIsMediaLoading] = useState(false);
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    onConfirm: () => void | Promise<void>;
  } | null>(null);
  
  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const recordingTimeRef = useRef(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const role = getEffectiveRole(currentUser);
  const isAdmin = ['owner', 'admin', 'tech', 'developer'].includes(role);

  const [isTransitioning, setIsTransitioning] = useState(false);
  const lastTargetUserId = useRef<string | null>(null);

  const activeRoom = useMemo(() => {
    if (!activeRoomId) return null;
    return rooms.find(r => String(r.id) === String(activeRoomId));
  }, [rooms, activeRoomId]);

  useEffect(() => {
    if (activeRoomId && window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  }, [activeRoomId]);
  
  const roomDisplayName = useMemo(() => {
    if (!activeRoom) return '';
    if (activeRoom.type === 'dm') {
      const otherId = activeRoom.participants.find(id => id !== currentUser.id);
      const otherUser = staff.find(s => s.id === otherId);
      return otherUser?.name || activeRoom.name;
    }
    return activeRoom.name;
  }, [activeRoom, staff, currentUser.id]);

  const roomDisplayAvatar = useMemo(() => {
    if (!activeRoom) return null;
    if (activeRoom.type === 'dm') {
      const otherId = activeRoom.participants.find(id => id !== currentUser.id);
      const otherUser = staff.find(s => s.id === otherId);
      return otherUser?.avatarUrl || null;
    }
    return null;
  }, [activeRoom, staff, currentUser.id]);
  
  const roomMessages = useMemo(() => {
    if (!activeRoomId) return [];
    let filtered = messages.filter(m => String(m.roomId) === String(activeRoomId));
    if (searchQuery) {
      filtered = filtered.filter(m => (m.text || '').toLowerCase().includes(searchQuery.toLowerCase()));
    }
    return filtered;
  }, [messages, activeRoomId, searchQuery]);

  const filteredGroups = useMemo(() => {
    return rooms.filter(r => r.type === 'group' && (r.name || '').toLowerCase().includes(roomSearchQuery.toLowerCase()));
  }, [rooms, roomSearchQuery]);

  const filteredDMs = useMemo(() => {
    return staff.filter(s => 
      s.id !== currentUser.id && 
      s.role !== 'user' && 
      (s.name || '').toLowerCase().includes(roomSearchQuery.toLowerCase())
    );
  }, [staff, currentUser.id, roomSearchQuery]);

  // Initial room selection and target handling
  useEffect(() => {
    // 1. Handle explicit navigation to a user
    if (targetUserId && staff.length > 0) {
      if (lastTargetUserId.current !== targetUserId) {
        lastTargetUserId.current = targetUserId;
        const member = staff.find(s => s.id === targetUserId);
        if (member) {
          startDM(member);
        }
      }
      return;
    }

    // 2. Default room selection
    if (rooms && rooms.length > 0 && !activeRoomId) {
      const general = rooms.find(r => (r.name || '').toLowerCase().includes('общий') || (r.name || '').toLowerCase().includes('general') || r.id === 'room-general');
      const defaultId = general?.id || rooms[0]?.id || null;
      if (defaultId) {
        setActiveRoomId(defaultId);
      }
    }
  }, [targetUserId, staff, rooms, activeRoomId]);

  // Handle case where activeRoomId is set but room is missing (e.g. deleted or sync delay)
  useEffect(() => {
    if (activeRoomId && rooms && rooms.length > 0) {
      const exists = rooms.some(r => String(r.id) === String(activeRoomId));
      if (!exists && !targetUserId) { // If not found and not a pending DM creation
        console.warn('Active room not found in list, resetting to default');
        const general = rooms.find(r => (r.name || '').toLowerCase().includes('общий') || (r.name || '').toLowerCase().includes('general') || r.id === 'room-general');
        const fallbackId = general?.id || rooms[0]?.id || null;
        if (fallbackId) {
          setActiveRoomId(fallbackId);
        }
      }
    }
  }, [activeRoomId, rooms]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    
    if (activeRoomId) {
      roomMessages.forEach(m => {
        if (m.senderId !== currentUser.id && !m.readBy?.includes(currentUser.id)) {
          markAsRead(m.id, currentUser.id);
        }
      });
    }
  }, [roomMessages.length, activeRoomId]);

  const handleSend = async (text: string = inputText, options: any = {}) => {
    if (!activeRoomId) return;
    if (!text.trim() && !options.fileUrl) return;
    
    setInputText('');
    setSendingMsgId('temp-' + Date.now());
    
    try {
      await sendMessage(activeRoomId, text, currentUser, options);
    } finally {
      setSendingMsgId(null);
    }
  };

  const startVoiceRecording = async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      alert('Ваш браузер не поддерживает запись аудио. Используйте современный браузер.');
      return;
    }

    try {
      // First check if already granted to avoid silent failure (with Safari support)
      try {
        if (navigator.permissions && navigator.permissions.query) {
          const result = await navigator.permissions.query({ name: 'microphone' } as any);
          if (result.state === 'denied') {
            alert('Доступ к микрофону заблокирован. Пожалуйста, разрешите доступ в настройках вашего браузера для этого сайта.');
            return;
          }
        }
      } catch (pErr) {
        console.warn('Permissions API not fully supported or query failed:', pErr);
      }

      // Pre-check for devices to provide better error messages
      const devices = await navigator.mediaDevices.enumerateDevices();
      const hasAudioInput = devices.some(device => device.kind === 'audioinput');
      
      if (!hasAudioInput && devices.length > 0) {
        // If we listed devices but found no audio input
        alert('Микрофон не обнаружен. Пожалуйста, убедитесь, что микрофон подключен и разрешен в настройках системы.');
        return;
      }

      console.log('Requesting microphone access...');
      // Use standard constraints
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });
      
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const finalTime = recordingTimeRef.current;
        
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          const base64Audio = reader.result as string;
          handleSend('', { type: 'voice', fileUrl: base64Audio, duration: finalTime });
        };
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      recordingTimeRef.current = 0;
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => {
          const next = prev + 1;
          recordingTimeRef.current = next;
          return next;
        });
      }, 1000);
    } catch (err: any) {
      console.error('Microphone error:', err.name, err.message);
      if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError' || err.message.includes('device not found')) {
        alert('Микрофон не обнаружен. Пожалуйста, убедитесь, что микрофон подключен и исправен.');
      } else if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError' || err.message.includes('denied')) {
        alert('Доступ к микрофону отклонен. Пожалуйста, разрешите доступ в настройках браузера.');
      } else if (err.name === 'AbortError') {
        alert('Запись была отменена системой или пользователем.');
      } else {
        alert('Ошибка при начале записи: ' + err.message);
      }
      setIsRecording(false);
    }
  };

  const stopVoiceRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      clearInterval(timerRef.current);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        const type = file.type.startsWith('image/') ? 'image' : 'file';
        const options: any = { 
          type, 
          fileUrl: result, 
          fileName: file.name
        };
        if (type === 'image') {
          options.imageUrl = result;
        }
        handleSend(file.name, options);
      };
      reader.readAsDataURL(file);
    }
  };

  const startDM = async (otherUser: Staff) => {
    setIsTransitioning(true);
    try {
      // Deterministic ID for DM to prevent duplicates
      const sortedIds = [currentUser.id, otherUser.id].sort();
      const dmId = `dm-${sortedIds[0]}-${sortedIds[1]}`;
      
      const existing = rooms.find(r => r.id === dmId);

      if (existing) {
        setActiveRoomId(existing.id);
      } else {
        await createRoom({
          id: dmId, // Pass the deterministic ID
          name: otherUser.name,
          type: 'dm',
          participants: [currentUser.id, otherUser.id],
          createdById: currentUser.id
        } as any);
        setActiveRoomId(dmId);
      }
    } catch (err) {
      console.error('Error starting DM:', err);
    } finally {
      setIsTransitioning(false);
    }
  };

  const getRoleLabel = (role: string) => {
    const labels: any = {
      owner: 'Владелец', admin: 'Админ', tech: 'ТП', 
      chef: 'Повар', waiter: 'Официант', bartender: 'Бармен',
      developer: 'Разраб', tester: 'QA'
    };
    return labels[role] || role;
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const pinnedMessage = useMemo(() => {
    if (!activeRoom?.pinnedMessageId) return null;
    return messages.find(m => m.id === activeRoom.pinnedMessageId);
  }, [activeRoom?.pinnedMessageId, messages]);

  return (
    <div className="flex h-[calc(100vh-8rem)] bg-white dark:bg-slate-950 rounded-3xl overflow-hidden shadow-2xl border border-slate-100 dark:border-slate-800 animate-in fade-in duration-500 relative">
      
      {/* Sidebar */}
      <div className={cn(
        "absolute inset-y-0 left-0 z-30 w-full md:relative md:w-80 border-r border-slate-100 dark:border-slate-800 flex flex-col transition-all duration-300 bg-white dark:bg-slate-950",
        !isSidebarOpen && "-translate-x-full md:translate-x-0 md:w-20"
      )}>
        <div className="p-6 border-b border-slate-50 dark:border-slate-800/50 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h3 className={cn("font-black text-xl uppercase tracking-tight dark:text-white", !isSidebarOpen && "hidden")}>Чаты</h3>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setShowCreateModal(true)}
            >
              <Plus size={20} />
            </Button>
          </div>
          
          <div className={cn("relative", !isSidebarOpen && "hidden")}>
             <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
             <input 
               type="text"
               placeholder="Поиск..."
               className="w-full bg-slate-50 dark:bg-slate-900 border-none rounded-xl py-2 pl-9 pr-3 text-xs font-bold focus:ring-1 focus:ring-indigo-500/30"
               value={roomSearchQuery}
               onChange={e => setRoomSearchQuery(e.target.value)}
             />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-6 custom-scrollbar">
          {/* Group Rooms */}
          <div className="space-y-2">
            <div className={cn("px-3 text-[10px] font-black uppercase text-slate-400 tracking-widest flex items-center justify-between", !isSidebarOpen && "sr-only")}>
              <span>Группы</span>
              <Hash size={10} />
            </div>
            {filteredGroups.map(room => (
              <button
                key={room.id}
                onClick={() => {
                  setActiveRoomId(room.id);
                  if (window.innerWidth < 768) {
                    setIsSidebarOpen(false);
                  }
                }}
                className={cn(
                  "w-full p-3 rounded-2xl flex items-center gap-3 transition-all group",
                  activeRoomId === room.id 
                    ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20" 
                    : "hover:bg-slate-50 dark:hover:bg-slate-900 text-slate-600 dark:text-slate-400"
                )}
              >
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                  activeRoomId === room.id ? "bg-white/20" : "bg-slate-100 dark:bg-slate-800"
                )}>
                  <Users size={18} />
                </div>
                <div className={cn("text-left overflow-hidden translate-y-[-1px]", !isSidebarOpen && "hidden")}>
                  <p className="font-bold text-sm truncate">{room.name}</p>
                  <p className={cn("text-[10px] truncate opacity-60 font-medium", activeRoomId === room.id ? "text-white" : "text-slate-400")}>
                    {room.lastMessage || 'Нет сообщений'}
                  </p>
                </div>
              </button>
            ))}
          </div>

          {/* DMs */}
          <div className="space-y-2">
            <div className={cn("px-3 text-[10px] font-black uppercase text-slate-400 tracking-widest flex items-center justify-between", !isSidebarOpen && "sr-only")}>
              <span>Личные</span>
              <Circle size={8} />
            </div>
            {filteredDMs.map(member => {
              const dmRoom = rooms.find(r => 
                r.type === 'dm' && 
                r.participants.includes(member.id) && 
                r.participants.includes(currentUser.id)
              );
              const isActive = activeRoomId === dmRoom?.id;
              
              return (
                <button
                  key={member.id}
                  onClick={() => {
                    startDM(member);
                    if (window.innerWidth < 768) {
                      setIsSidebarOpen(false);
                    }
                  }}
                  className={cn(
                    "w-full p-3 rounded-2xl flex items-center gap-3 transition-all",
                    isActive 
                      ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20" 
                      : "hover:bg-slate-50 dark:hover:bg-slate-900 text-slate-600 dark:text-slate-400"
                  )}
                >
                  <div className="relative shrink-0">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs uppercase overflow-hidden",
                      isActive ? "bg-white/20 text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-500"
                    )}>
                      {member.avatarUrl ? <img src={member.avatarUrl} className="w-full h-full object-cover" /> : (member.name || '•')[0]}
                    </div>
                    {member.isOnline && (
                      <div className="absolute -right-0.5 -bottom-0.5 w-3 h-3 bg-emerald-500 border-2 border-white dark:border-slate-950 rounded-full" />
                    )}
                  </div>
                  <div className={cn("text-left overflow-hidden translate-y-[-1px]", !isSidebarOpen && "hidden")}>
                    <p className="font-bold text-sm truncate">{member.name}</p>
                    <p className={cn("text-[10px] font-black uppercase tracking-wider opacity-60", isActive ? "text-white" : "text-indigo-500")}>
                      {member.isOnline ? 'В сети' : member.lastSeen ? `Был ${new Date(member.lastSeen).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : 'Не в сети'}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-slate-50/30 dark:bg-transparent relative h-full">
        {!activeRoomId ? (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 p-8 text-center space-y-4">
             <div className="w-20 h-20 bg-slate-100 dark:bg-slate-900 rounded-full flex items-center justify-center">
                <MessageCircle size={40} className="opacity-20" />
             </div>
             <div>
                <p className="font-black uppercase text-xs tracking-widest mb-1">Выберите чат</p>
                <p className="text-sm">Начните общение с коллегами</p>
             </div>
          </div>
        ) : (isTransitioning || (activeRoomId && !activeRoom)) ? (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 p-8 text-center space-y-4">
             <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
             <p className="font-black uppercase text-[10px] tracking-widest">Переход в чат...</p>
             {activeRoomId && !activeRoom && (
               <Button variant="ghost" size="sm" onClick={() => setActiveRoomId(null)} className="mt-4">
                 Отмена
               </Button>
             )}
          </div>
        ) : (
          <>
            {/* Chat header */}
            <div className="h-20 px-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-white dark:bg-slate-950/50 backdrop-blur-md shrink-0 relative z-20">
              <div className="flex items-center gap-4">
                <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl md:hidden">
                  <ArrowLeft size={20} />
                </button>
                <div 
                  className={cn("flex items-center gap-3", activeRoom?.type === 'dm' && "cursor-pointer hover:opacity-80 transition-opacity")}
                  onClick={() => {
                    if (activeRoom?.type === 'dm') {
                      const otherId = activeRoom.participants.find(id => id !== currentUser.id);
                      if (otherId) onNavigate('profile', { userId: otherId });
                    }
                  }}
                >
                   {activeRoom?.type === 'dm' && (
                     <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 overflow-hidden shrink-0">
                        {roomDisplayAvatar ? (
                          <img 
                            src={roomDisplayAvatar} 
                            className="w-full h-full object-cover" 
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center font-black text-slate-400">
                            {(roomDisplayName || '•')[0]}
                          </div>
                        )}
                     </div>
                   )}
                   <div>
                      <h2 className="font-black text-lg dark:text-white leading-tight uppercase tracking-tight">{roomDisplayName}</h2>
                      <p className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest">
                        {activeRoom?.type === 'group' ? `${activeRoom.participants.length} участников` : 'Личный чат'}
                      </p>
                   </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                {isSearching ? (
                  <motion.div 
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: 200, opacity: 1 }}
                    className="flex items-center bg-slate-100 dark:bg-slate-900 rounded-xl px-3"
                  >
                    <Search size={16} className="text-slate-400" />
                    <input 
                      autoFocus
                      className="bg-transparent border-none focus:ring-0 text-sm p-2 w-full dark:text-white"
                      placeholder="Поиск..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      onBlur={() => !searchQuery && setIsSearching(false)}
                    />
                    <button onClick={() => { setSearchQuery(''); setIsSearching(false); }}><X size={16} className="text-slate-400" /></button>
                  </motion.div>
                ) : (
                  <Button variant="ghost" size="sm" onClick={() => setIsSearching(true)}><Search size={18} /></Button>
                )}
                
                <div className="relative">
                  <Button variant="ghost" size="sm" onClick={() => setShowRoomMenu(!showRoomMenu)}><MoreVertical size={18} /></Button>
                  <AnimatePresence>
                    {showRoomMenu && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 top-full mt-2 w-56 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-2xl p-2 z-50 overflow-hidden"
                      >
                         {activeRoom?.type === 'group' && (
                           <>
                             <button 
                               onClick={() => { setShowParticipantsModal(true); setShowRoomMenu(false); }}
                               className="w-full p-3 flex items-center gap-3 text-sm font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-colors"
                             >
                               <Users size={16} /> Участники
                             </button>
                             <div className="h-px bg-slate-50 dark:bg-slate-800 my-1" />
                             <button 
                               onClick={() => {
                                 setRenameRoomName(activeRoom.name);
                                 setShowRenameModal(true);
                                 setShowRoomMenu(false);
                               }}
                               className="w-full p-3 flex items-center gap-3 text-sm font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-colors"
                             >
                               <Edit2 size={16} /> Переименовать
                             </button>
                             {(isAdmin || currentUser.id === activeRoom.createdById) && (
                               <>
                                 <div className="h-px bg-slate-50 dark:bg-slate-800 my-1" />
                                 <button 
                                   onClick={() => {
                                     setShowRoomMenu(false);
                                     setConfirmDialog({
                                       isOpen: true,
                                       title: 'Удалить групповой чат',
                                       message: 'Вы уверены, что хотите полностью удалить этот групповой чат и всю его историю? Чат исчезнет для всех.',
                                       confirmText: 'Удалить',
                                       cancelText: 'Отмена',
                                       onConfirm: async () => {
                                         if (deleteRoom) {
                                           await deleteRoom(activeRoom.id);
                                           setActiveRoomId(null);
                                         } else {
                                           setConfirmDialog({
                                             isOpen: true,
                                             title: 'Недоступно',
                                             message: 'Действие временно недоступно.',
                                             confirmText: 'ОК',
                                             onConfirm: () => {}
                                           });
                                         }
                                       }
                                     });
                                   }}
                                   className="w-full p-3 flex items-center gap-3 text-sm font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 rounded-xl transition-colors"
                                 >
                                   <Trash2 size={16} /> Удалить чат
                                 </button>
                               </>
                             )}
                           </>
                         )}

                         {activeRoom?.type === 'dm' && (
                           <>
                             <button 
                               onClick={() => {
                                 const otherId = activeRoom.participants.find(id => id !== currentUser.id);
                                 if (otherId) onNavigate('profile', { userId: otherId });
                                 setShowRoomMenu(false);
                               }}
                               className="w-full p-3 flex items-center gap-3 text-sm font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-colors"
                             >
                               <Users size={16} /> Профиль
                             </button>
                             <div className="h-px bg-slate-50 dark:bg-slate-800 my-1" />
                             <button 
                               onClick={() => {
                                 setShowRoomMenu(false);
                                 setConfirmDialog({
                                   isOpen: true,
                                   title: 'Очистить переписку',
                                   message: 'Вы уверены, что хотите полностью очистить переписку в этом чате?',
                                   confirmText: 'Очистить',
                                   cancelText: 'Отмена',
                                   onConfirm: async () => {
                                     if (clearRoomMessages) {
                                       await clearRoomMessages(activeRoom.id);
                                     } else {
                                       setConfirmDialog({
                                         isOpen: true,
                                         title: 'Недоступно',
                                         message: 'Действие временно недоступно.',
                                         confirmText: 'ОК',
                                         onConfirm: () => {}
                                       });
                                     }
                                   }
                                 });
                               }}
                               className="w-full p-3 flex items-center gap-3 text-sm font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 rounded-xl transition-colors"
                             >
                               <Trash2 size={16} /> Очистить переписку
                             </button>
                             <div className="h-px bg-slate-50 dark:bg-slate-800 my-1" />
                             <button 
                               onClick={() => {
                                 setShowRoomMenu(false);
                                 setConfirmDialog({
                                   isOpen: true,
                                   title: 'Удалить личный чат',
                                   message: 'Вы уверены, что хотите полностью удалить этот личный чат и всю историю сообщений для обоих участников?',
                                   confirmText: 'Удалить',
                                   cancelText: 'Отмена',
                                   onConfirm: async () => {
                                     if (deleteRoom) {
                                       await deleteRoom(activeRoom.id);
                                       setActiveRoomId(null);
                                     } else {
                                       setConfirmDialog({
                                         isOpen: true,
                                         title: 'Недоступно',
                                         message: 'Действие временно недоступно.',
                                         confirmText: 'ОК',
                                         onConfirm: () => {}
                                       });
                                     }
                                   }
                                 });
                               }}
                               className="w-full p-3 flex items-center gap-3 text-sm font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 rounded-xl transition-colors"
                             >
                               <Trash2 size={16} /> Удалить чат
                             </button>
                           </>
                         )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>

            {/* Pinned Message Bar */}
            <AnimatePresence>
              {pinnedMessage && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="bg-indigo-50/50 dark:bg-indigo-900/10 border-b border-indigo-100 dark:border-indigo-800/30 px-6 py-2 flex items-center justify-between shrink-0 relative z-10"
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <Pin size={14} className="text-indigo-500 shrink-0" />
                    <div className="overflow-hidden">
                       <p className="text-[10px] font-black uppercase text-indigo-500 tracking-widest">Закреплено</p>
                       <p className="text-xs text-slate-600 dark:text-slate-400 truncate">{pinnedMessage.text}</p>
                    </div>
                  </div>
                  {isAdmin && (
                    <button onClick={() => unpinMessage(activeRoom.id)} className="text-slate-400 hover:text-red-500 p-1">
                      <X size={14} />
                    </button>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Messages Feed */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar scroll-smooth">
              {roomMessages.map((msg, idx) => {
                const isMe = msg.senderId === currentUser.id;
                const prevMsg = idx > 0 ? roomMessages[idx - 1] : null;
                const showSender = !prevMsg || prevMsg.senderId !== msg.senderId;
                const isRead = msg.readBy && msg.readBy.length > 1;

                return (
                  <div key={msg.id} className={cn(
                    "flex gap-3 group animate-in slide-in-from-bottom-2 duration-300",
                    isMe ? "flex-row-reverse" : "flex-row"
                  )}>
                    {showSender ? (
                      <button 
                        onClick={() => onNavigate('profile', { userId: msg.senderId })}
                        className="shrink-0 w-8 h-8 rounded-lg bg-slate-200 dark:bg-slate-800 flex items-center justify-center font-bold text-[10px] text-slate-500 overflow-hidden hover:ring-2 hover:ring-indigo-500/50 transition-all"
                      >
                         {staff.find(s => s.id === msg.senderId)?.avatarUrl ? (
                           <img src={staff.find(s => s.id === msg.senderId)?.avatarUrl} className="w-full h-full object-cover" />
                         ) : (msg.senderName || '•')[0]}
                      </button>
                    ) : (
                      <div className="w-8 shrink-0" />
                    )}

                    <div className={cn(
                      "flex flex-col gap-1 max-w-[70%]",
                      isMe ? "items-end" : "items-start"
                    )}>
                      {showSender && !isMe && (
                        <div className="flex items-center gap-2 px-1">
                          <span className="text-[10px] font-black uppercase text-indigo-500 tracking-tighter">
                            {getRoleLabel(msg.senderRole)}
                          </span>
                          <span className="text-[10px] font-bold text-slate-400">
                            {msg.senderName}
                          </span>
                        </div>
                      )}
                      
                      <div className={cn(
                        "p-3 rounded-2xl text-sm shadow-sm relative group",
                        isMe 
                          ? "bg-indigo-600 text-white rounded-tr-none" 
                          : "bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 border border-slate-100 dark:border-slate-800 rounded-tl-none",
                        msg.isPinned && "border-2 border-indigo-400"
                      )}>
                        {/* Context Menu (Hover only) */}
                        {isAdmin && !msg.isPinned && (
                          <button 
                            onClick={() => pinMessage(activeRoom.id, msg.id)}
                            className="absolute -top-2 -right-2 bg-white dark:bg-slate-800 shadow-lg rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity text-indigo-500"
                          >
                            <Pin size={12} fill="currentColor" />
                          </button>
                        )}

                        {msg.type === 'image' && msg.imageUrl && (
                          <div className="mb-2 rounded-xl overflow-hidden border border-white/10 cursor-zoom-in active:scale-95 transition-transform">
                             <img 
                               src={msg.imageUrl} 
                               className="w-full h-auto max-h-60 object-contain hover:brightness-95" 
                               onClick={() => setZoomedImage(msg.imageUrl || null)}
                             />
                          </div>
                        )}

                        {msg.type === 'voice' && msg.fileUrl && (
                          <div className="flex items-center gap-3 py-1 pr-4 min-w-[200px]">
                            <button className={cn("w-10 h-10 rounded-full flex items-center justify-center shrink-0", isMe ? "bg-white/20" : "bg-indigo-50 dark:bg-indigo-900")}>
                               <Volume2 size={20} className={isMe ? "text-white" : "text-indigo-600"} />
                            </button>
                            <div className="flex-1 h-1 bg-white/20 dark:bg-slate-700 rounded-full overflow-hidden">
                               <div className="h-full bg-white dark:bg-indigo-500 w-1/3" />
                            </div>
                            <span className="text-[10px] font-bold opacity-60">{formatTime(msg.duration || 0)}</span>
                          </div>
                        )}

                        {msg.type === 'file' && (
                          <div className={cn(
                            "flex items-center gap-3 p-3 rounded-xl mb-2",
                            isMe ? "bg-white/10" : "bg-slate-50 dark:bg-slate-800"
                          )}>
                             <div className="p-2 bg-indigo-500 rounded-lg text-white">
                                <FileIcon size={20} />
                             </div>
                             <div className="flex-1 overflow-hidden">
                                <p className="text-xs font-bold truncate">{msg.fileName || 'Файл'}</p>
                                <p className="text-[10px] opacity-60 uppercase font-black tracking-widest">Документ</p>
                             </div>
                             <a href={msg.fileUrl} download={msg.fileName} className="p-2 hover:bg-white/20 rounded-lg shrink-0">
                                <Download size={18} />
                             </a>
                          </div>
                        )}

                        {msg.text && <p className="leading-relaxed">{msg.text}</p>}
                        
                        <div className={cn(
                          "flex items-center gap-1.5 mt-2",
                          isMe ? "justify-end text-white/50" : "justify-start text-slate-400"
                        )}>
                          <span className="text-[9px] font-bold">
                            {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          {isMe && (
                            <div className="flex items-center">
                              {isRead ? <CheckCheck size={10} /> : <Check size={10} />}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
              
              {sendingMsgId && (
                <div className="flex flex-row-reverse gap-3 items-end opacity-70">
                   <div className="w-8 shrink-0 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900" />
                   <div className="bg-indigo-600 text-white p-3 rounded-2xl rounded-tr-none text-sm inline-block">
                      <div className="mt-2 text-right">
                         <Clock size={10} className="inline animate-spin" />
                      </div>
                   </div>
                </div>
              )}
              
              <div ref={messagesEndRef} className="h-4" />
            </div>

            {/* Input area */}
            <div className="p-6 bg-white dark:bg-slate-950 border-t border-slate-100 dark:border-slate-800 relative z-20">
              <div className="flex gap-4 items-center">
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  onChange={handleFileUpload}
                  accept="image/*,.pdf,.doc,.docx"
                />
                
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="p-3 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/10 rounded-2xl transition-all"
                >
                  <Paperclip size={22} />
                </button>

                <div className="flex-1 relative">
                  {isRecording ? (
                    <div className="flex items-center justify-between bg-red-50 dark:bg-red-900/10 h-14 px-6 rounded-2xl border border-red-100 dark:border-red-800/50">
                       <div className="flex items-center gap-3">
                          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                          <span className="font-black text-xs uppercase tracking-widest text-red-500">Запись: {formatTime(recordingTime)}</span>
                       </div>
                       <div className="flex gap-2">
                          <button onClick={stopVoiceRecording} className="text-red-500 font-bold text-xs uppercase tracking-widest pr-4 border-r border-red-200">Отмена</button>
                          <button onClick={stopVoiceRecording} className="text-emerald-500 font-bold text-xs uppercase tracking-widest pl-2">Отправить</button>
                       </div>
                    </div>
                  ) : (
                    <>
                      <Input 
                        placeholder="Напишите сообщение..."
                        value={inputText}
                        onChange={e => setInputText(e.target.value)}
                        onKeyPress={e => e.key === 'Enter' && handleSend()}
                        className="pr-12 h-14 rounded-2xl bg-slate-50 dark:bg-slate-900 border-none shadow-inner focus:ring-2 focus:ring-indigo-500/20"
                      />
                      <button 
                        onClick={() => setShowSettings(!showSettings)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-indigo-500 transition-colors"
                      >
                         <Settings size={18} />
                      </button>
                    </>
                  )}
                </div>

                {!inputText.trim() && !isRecording ? (
                  <button 
                    onClick={startVoiceRecording}
                    className="h-14 w-14 rounded-2xl p-0 shrink-0 flex items-center justify-center bg-slate-100 dark:bg-slate-900 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800 transition-all border border-slate-200 dark:border-slate-800"
                  >
                    <Mic size={22} />
                  </button>
                ) : (
                  <Button 
                    onClick={() => handleSend()}
                    disabled={!inputText.trim()}
                    className="h-14 w-14 rounded-2xl p-0 shrink-0 shadow-lg shadow-indigo-500/30"
                  >
                    <Send size={22} />
                  </Button>
                )}
              </div>
            </div>
            
            {/* Settings Dropdown */}
            <AnimatePresence>
               {showSettings && (
                 <>
                   <div className="fixed inset-0 z-40" onClick={() => setShowSettings(false)} />
                   <motion.div 
                     initial={{ opacity: 0, scale: 0.95, y: 10 }}
                     animate={{ opacity: 1, scale: 1, y: 0 }}
                     exit={{ opacity: 0, scale: 0.95, y: 10 }}
                     className="absolute bottom-24 right-24 w-64 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-2xl p-4 z-50 space-y-4"
                   >
                      <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Настройки чата</h4>
                      <div className="space-y-1">
                         <button 
                           onClick={() => setIsNotificationsEnabled(!isNotificationsEnabled)}
                           className="w-full text-left p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-between group transition-colors"
                         >
                            <span className="text-sm font-bold text-slate-600 dark:text-slate-400 group-hover:text-indigo-500">Уведомления</span>
                            <div className={cn(
                              "w-8 h-4 rounded-full relative transition-colors duration-300",
                              isNotificationsEnabled ? "bg-emerald-500" : "bg-slate-200 dark:bg-slate-700"
                            )}>
                               <motion.div 
                                 animate={{ x: isNotificationsEnabled ? 16 : 4 }}
                                 className="absolute top-1 w-2 h-2 bg-white rounded-full shadow-sm" 
                               />
                            </div>
                         </button>
                         <button 
                           onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                           className="w-full text-left p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-between group transition-colors"
                         >
                            <span className="text-sm font-bold text-slate-600 dark:text-slate-400 group-hover:text-indigo-500">Темная тема</span>
                            <div className={cn(
                              "w-8 h-4 rounded-full relative transition-colors duration-300",
                              theme === 'dark' ? "bg-indigo-600" : "bg-slate-200"
                            )}>
                               <motion.div 
                                 animate={{ x: theme === 'dark' ? 16 : 4 }}
                                 className="absolute top-1 w-2 h-2 bg-white rounded-full shadow-sm" 
                               />
                            </div>
                         </button>
                      </div>
                      <div className="h-px bg-slate-100 dark:bg-slate-800" />
                      <button 
                        onClick={() => {
                          setClearingCache(true);
                          setTimeout(() => {
                            setClearingCache(false);
                            alert('Кэш чата успешно очищен');
                          }, 1000);
                        }}
                        disabled={clearingCache}
                        className="w-full p-3 text-red-500 font-bold text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-xl transition-colors disabled:opacity-50"
                      >
                         {clearingCache ? <Clock size={14} className="animate-spin" /> : <Trash2 size={14} />} 
                         {clearingCache ? 'Очистка...' : 'Очистить кэш'}
                      </button>
                   </motion.div>
                 </>
               )}
            </AnimatePresence>
          </>
        )}
      </div>

      {/* Participants Modal */}
      {showParticipantsModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-300">
           <Card className="w-full max-w-md p-8 space-y-6 animate-in zoom-in-95 duration-300 relative overflow-hidden">
             <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 mb-4">
                <div>
                   <h3 className="font-black text-xl uppercase tracking-tighter dark:text-white">Участники</h3>
                   <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{activeRoom?.participants.length} человек</p>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setShowParticipantsModal(false)}><X size={20} /></Button>
             </div>
             
             <div className="max-h-[400px] overflow-y-auto space-y-3 custom-scrollbar pr-2">
                {staff.filter(s => s.role !== 'user').map(member => {
                  const isInRoom = activeRoom?.participants.includes(member.id);
                  const isRoomOwner = activeRoom?.createdById === member.id;
                  
                  return (
                    <div key={member.id} className="flex items-center justify-between p-3 rounded-2xl bg-slate-50/50 dark:bg-slate-900/50 border border-slate-50 dark:border-slate-800">
                       <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-slate-200 dark:bg-slate-800 flex items-center justify-center overflow-hidden shrink-0">
                             {member.avatarUrl ? <img src={member.avatarUrl} className="w-full h-full object-cover" /> : (member.name || '•')[0]}
                          </div>
                          <div>
                             <p className="text-sm font-bold truncate max-w-[150px]">{member.name}</p>
                             <div className="flex items-center gap-2">
                               <p className="text-[10px] font-black uppercase text-indigo-500 tracking-tighter leading-none">{getRoleLabel(member.role)}</p>
                               {isRoomOwner && <span className="text-[8px] bg-amber-500 text-white px-1.5 py-0.5 rounded-full font-black uppercase">Владелец</span>}
                             </div>
                          </div>
                       </div>
                       
                       {isAdmin && activeRoom?.type === 'group' && member.id !== currentUser.id && (
                         <div className="flex gap-1">
                            {isInRoom ? (
                              <button 
                                onClick={() => updateParticipant(activeRoom!.id, member.id, 'remove')}
                                className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-lg transition-colors"
                                title="Исключить"
                              >
                                <UserMinus size={18} />
                              </button>
                            ) : (
                              <button 
                                onClick={() => updateParticipant(activeRoom!.id, member.id, 'add')}
                                className="p-2 text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/10 rounded-lg transition-colors"
                                title="Добавить"
                              >
                                <UserPlus size={18} />
                              </button>
                            )}
                         </div>
                       )}
                    </div>
                  );
                })}
             </div>
           </Card>
        </div>
      )}

      {/* Create Room Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-300">
          <Card className="w-full max-w-md p-8 space-y-6 animate-in zoom-in-95 duration-300">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-black uppercase tracking-tight dark:text-white">Создать группу</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowCreateModal(false)}><X size={20} /></Button>
            </div>
            <div className="space-y-4">
               <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Название группы</label>
                  <Input 
                    placeholder="Напр: Кухня 2.0" 
                    value={newRoomName}
                    onChange={e => setNewRoomName(e.target.value)}
                    className="font-bold h-12"
                  />
               </div>
               <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 rounded-2xl border border-indigo-100 dark:border-indigo-800">
                  <p className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-2 italic leading-relaxed">
                    <Users size={14} /> Вы сможете добавить участников позже в меню управления.
                  </p>
               </div>
            </div>
            <Button className="w-full h-14 rounded-2xl font-black uppercase tracking-widest disabled:opacity-50" disabled={isCreatingRoom || !newRoomName.trim()} onClick={() => {
               setIsCreatingRoom(true);
               createRoom({
                 name: newRoomName,
                 type: 'group',
                 participants: [currentUser.id],
                 createdById: currentUser.id
               }).then(id => {
                  setActiveRoomId(id);
                  if (window.innerWidth < 768) {
                    setIsSidebarOpen(false);
                  }
                  setNewRoomName('');
                  setShowCreateModal(false);
               }).finally(() => {
                  setIsCreatingRoom(false);
               });
            }}>
              Создать
            </Button>
          </Card>
        </div>
      )}

      <AnimatePresence>
        {zoomedImage && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 cursor-zoom-out"
              onClick={() => setZoomedImage(null)}
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative max-w-full max-h-full z-10 flex flex-col items-center justify-center"
            >
              <button 
                onClick={() => setZoomedImage(null)}
                className="absolute top-4 right-4 bg-black/60 hover:bg-black text-white hover:text-indigo-400 p-2 rounded-full transition-all z-[130]"
              >
                <X size={24} />
              </button>
              <img 
                src={zoomedImage} 
                className="max-w-[95vw] max-h-[85vh] rounded-2xl object-contain border border-white/10 shadow-2xl" 
                alt="Zoomed"
              />
            </motion.div>
          </div>
        )}

        {confirmDialog && confirmDialog.isOpen && (
          <div className="fixed inset-0 z-[130] flex items-center justify-center p-4 bg-slate-950/65 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0"
              onClick={() => setConfirmDialog(null)}
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl p-6 shadow-2xl z-10 flex flex-col items-center text-center gap-4 animate-in fade-in zoom-in-95 duration-150"
            >
              <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/30 flex items-center justify-center text-rose-500 dark:text-rose-400">
                <Trash2 size={24} />
              </div>
              
              <div className="space-y-2">
                <h3 className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                  {confirmDialog.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed px-2 block">
                  {confirmDialog.message}
                </p>
              </div>

              <div className="flex gap-2 w-full mt-2">
                <button
                  onClick={() => setConfirmDialog(null)}
                  className="flex-1 py-3 px-4 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 transition-all"
                >
                  {confirmDialog.cancelText || 'Отмена'}
                </button>
                <button
                  onClick={async () => {
                    const onConfirm = confirmDialog.onConfirm;
                    setConfirmDialog(null);
                    await onConfirm();
                  }}
                  className="flex-1 py-3 px-4 rounded-xl text-xs font-semibold text-white bg-rose-500 hover:bg-rose-600 active:scale-95 transition-all shadow-lg shadow-rose-500/20"
                >
                  {confirmDialog.confirmText || 'Удалить'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Rename Room Modal */}
      {showRenameModal && activeRoom && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-300">
          <Card className="w-full max-w-md p-8 space-y-6 animate-in zoom-in-95 duration-300">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-black uppercase tracking-tight dark:text-white">Переименовать группу</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowRenameModal(false)}><X size={20} /></Button>
            </div>
            <div className="space-y-4">
               <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 block">Новое название группы</label>
                  <Input 
                    placeholder="Напр: Кухня 2.0" 
                    value={renameRoomName}
                    onChange={e => setRenameRoomName(e.target.value)}
                    className="font-bold h-12"
                  />
               </div>
            </div>
            <Button className="w-full h-14 rounded-2xl font-black uppercase tracking-widest disabled:opacity-50" disabled={!renameRoomName.trim()} onClick={async () => {
               await updateRoom(activeRoom.id, { name: renameRoomName });
               setShowRenameModal(false);
            }}>
              Сохранить
            </Button>
          </Card>
        </div>
      )}
    </div>
  );
}
