import React, { useState, useMemo, useEffect } from 'react';
import { Ticket, TicketComment, Staff, Role } from '../types';
import { Card, Button, cn, Input } from './UI';
import { 
  Ticket as TicketIcon, 
  MessageSquare, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  User, 
  Search,
  Filter,
  MoreVertical,
  Send,
  Plus,
  X
} from 'lucide-react';
import { getEffectiveRole } from '../lib/auth';

interface TicketsViewProps {
  tickets: Ticket[];
  staff: Staff[];
  addTicket: (ticket: Omit<Ticket, 'id' | 'ticketNumber' | 'timestamp' | 'updatedAt' | 'comments'>) => Promise<string>;
  updateTicket: (ticketId: string, updates: Partial<Ticket>, user: Staff) => Promise<void>;
  addTicketComment: (ticketId: string, text: string, user: Staff) => Promise<void>;
  markTicketAsRead: (ticketId: string, userId: string) => Promise<void>;
  archiveTicket?: (ticketId: string) => Promise<void>;
  currentUser: Staff;
  initialTicketId?: string | null;
  onClose?: () => void;
}

export default function TicketsView({ tickets, staff, addTicket, updateTicket, archiveTicket, addTicketComment, markTicketAsRead, currentUser, initialTicketId, onClose }: TicketsViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | Ticket['status']>('all');
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(initialTicketId || null);
  const [showArchived, setShowArchived] = useState(false);

  useEffect(() => {
    if (initialTicketId) {
      setSelectedTicketId(initialTicketId);
    }
  }, [initialTicketId]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedTicketId(null);
        setIsAddingTicket(false);
        if (onClose) onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const [isAddingTicket, setIsAddingTicket] = useState(false);
  const [newTicketTitle, setNewTicketTitle] = useState('');
  const [newTicketDesc, setNewTicketDesc] = useState('');
  const [newTicketPriority, setNewTicketPriority] = useState<Ticket['priority']>('medium');
  const [commentText, setCommentText] = useState('');
  const [devCommentText, setDevCommentText] = useState('');

  const currentUserRole = getEffectiveRole(currentUser);
  
  const canManageStatus = ['owner', 'tech', 'developer'].includes(currentUserRole);
  const canAssignTicket = ['owner', 'tech', 'developer'].includes(currentUserRole);
  const canCreateTicket = ['owner', 'admin', 'tester', 'developer'].includes(currentUserRole);

  const filteredTickets = useMemo(() => {
    return tickets.filter(t => {
      const matchesSearch = (t.title || '').toLowerCase().includes(searchQuery.toLowerCase()) || 
                           (t.ticketNumber || '').includes(searchQuery) ||
                           (t.description || '').toLowerCase().includes(searchQuery.toLowerCase());
      
      const isArchived = t.status === 'archived';
      const matchesStatus = statusFilter === 'all' 
        ? (!isArchived || showArchived) 
        : t.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [tickets, searchQuery, statusFilter, showArchived]);

  const selectedTicket = useMemo(() => 
    tickets.find(t => t.id === selectedTicketId), 
    [tickets, selectedTicketId]
  );

  useEffect(() => {
    if (selectedTicketId) {
      markTicketAsRead(selectedTicketId, currentUser.id);
      
      const ticket = tickets.find(t => t.id === selectedTicketId);
      if (ticket) {
        setDevCommentText(ticket.devComment || '');
      }
    }
  }, [selectedTicketId, currentUser.id, markTicketAsRead, tickets]);

  const handleAddTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTicketTitle.trim() || !newTicketDesc.trim()) return;

    await addTicket({
      title: newTicketTitle,
      description: newTicketDesc,
      priority: newTicketPriority,
      status: 'new',
      creatorId: currentUser.id,
      creatorName: currentUser.name,
      creatorRole: currentUserRole
    });

    setNewTicketTitle('');
    setNewTicketDesc('');
    setIsAddingTicket(false);
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !selectedTicketId) return;

    await addTicketComment(selectedTicketId, commentText, currentUser);
    setCommentText('');
  };

  const handleUpdateStatus = async (status: Ticket['status']) => {
    if (!selectedTicketId) return;
    await updateTicket(selectedTicketId, { status }, currentUser);
  };

  const handleUpdateDevComment = async () => {
    if (!selectedTicketId) return;
    await updateTicket(selectedTicketId, { devComment: devCommentText }, currentUser);
    setDevCommentText('');
  };

  const getStatusInfo = (status: Ticket['status']) => {
    switch (status) {
      case 'new': return { label: 'Новый', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' };
      case 'investigating': return { label: 'На рассмотрении', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' };
      case 'commented': return { label: 'Есть ответ', color: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400' };
      case 'resolved': return { label: 'Решен', color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' };
      case 'closed': return { label: 'Закрыт', color: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400' };
      case 'archived': return { label: 'В архиве', color: 'bg-slate-200 text-slate-500 dark:bg-slate-800 dark:text-slate-500' };
      default: return { label: status, color: 'bg-slate-100 text-slate-700' };
    }
  };

  const getPriorityInfo = (priority: Ticket['priority']) => {
    switch (priority) {
      case 'low': return { label: 'Низкий', color: 'text-slate-400' };
      case 'medium': return { label: 'Средний', color: 'text-blue-500' };
      case 'high': return { label: 'Высокий', color: 'text-orange-500' };
      case 'urgent': return { label: 'Критический', color: 'text-red-500 font-bold' };
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-8rem)] gap-6 animate-in fade-in duration-500">
      {/* Sidebar - Ticket List */}
      <div className={cn(
        "w-full lg:w-96 flex flex-col gap-4",
        selectedTicketId && "hidden lg:flex"
      )}>
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Тикеты</h2>
          {canCreateTicket && (
            <Button 
              size="sm" 
              onClick={() => setIsAddingTicket(true)}
              className="rounded-xl"
            >
              <Plus size={18} className="mr-1" /> Новый
            </Button>
          )}
        </div>

        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <Input 
              placeholder="Поиск..." 
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pl-10 text-sm"
            />
          </div>
            <button 
              onClick={() => setShowArchived(!showArchived)}
              className={cn(
                "p-2 rounded-xl border transition-all text-xs font-bold uppercase tracking-widest",
                showArchived 
                  ? "bg-slate-100 border-slate-300 dark:bg-slate-700 dark:border-slate-600 text-slate-900 dark:text-white" 
                  : "border-slate-200 dark:border-slate-700 text-slate-400"
              )}
            >
              Архив
            </button>
            <select 
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value as any)}
              className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 text-sm outline-none focus:ring-2 focus:ring-indigo-500/20"
            >
              <option value="all">Активные</option>
              <option value="new">Новые</option>
              <option value="investigating">В работе</option>
              <option value="commented">С ответом</option>
              <option value="resolved">Решенные</option>
              <option value="closed">Закрытые</option>
              {showArchived && <option value="archived">Архивные</option>}
            </select>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
          {filteredTickets.map(ticket => {
            const status = getStatusInfo(ticket.status);
            const priority = getPriorityInfo(ticket.priority);
            return (
              <Card 
                key={ticket.id}
                onClick={() => setSelectedTicketId(ticket.id)}
                className={cn(
                  "p-4 cursor-pointer transition-all border-l-4 hover:shadow-md",
                  selectedTicketId === ticket.id ? "border-indigo-500 bg-indigo-50/30 dark:bg-indigo-900/20" : "border-transparent",
                  ticket.priority === 'urgent' && "border-l-red-500"
                )}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="text-[10px] font-mono font-bold text-slate-400">#{ticket.ticketNumber}</span>
                  <span className={cn("text-[8px] font-black uppercase px-2 py-0.5 rounded-full", status.color)}>
                    {status.label}
                  </span>
                </div>
                <div className="space-y-2 mb-3">
                  <div>
                    <span className="text-[8px] font-black uppercase text-slate-400 tracking-tighter block mb-0.5">Тема:</span>
                    <h4 className="font-bold text-slate-900 dark:text-white line-clamp-1 leading-tight">{ticket.title}</h4>
                  </div>
                  <div>
                    <span className="text-[8px] font-black uppercase text-slate-400 tracking-tighter block mb-0.5">Суть:</span>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed italic">
                      {ticket.description}
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between text-[10px]">
                  <div className="flex items-center gap-2 text-slate-500">
                    <User size={12} />
                    <span className="truncate max-w-[80px]">{ticket.creatorName}</span>
                  </div>
                  <span className={cn("font-bold uppercase tracking-widest", priority.color)}>
                    {priority.label}
                  </span>
                </div>
              </Card>
            );
          })}
          {filteredTickets.length === 0 && (
            <div className="text-center py-20 text-slate-400 italic text-sm">
              Тикеты не найдены
            </div>
          )}
        </div>
      </div>

      {/* Main Content - Ticket Details */}
      <div className={cn(
        "flex-1 flex flex-col gap-6",
        !selectedTicketId && "hidden lg:flex items-center justify-center bg-slate-50/50 dark:bg-white/5 rounded-[2rem] border-2 border-dashed border-slate-200 dark:border-slate-800"
      )}>
        {selectedTicket ? (
          <div className="flex flex-col h-full gap-6">
            <div className="flex items-center justify-between">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => {
                  setSelectedTicketId(null);
                  if (onClose) onClose();
                }}
                className="lg:hidden"
              >
                Назад
              </Button>
              <div className="flex items-center gap-4">
                <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase">Тикет #{selectedTicket.ticketNumber}</h3>
                <span className={cn("text-xs font-black px-3 py-1 rounded-xl uppercase tracking-widest", getStatusInfo(selectedTicket.status).color)}>
                  {getStatusInfo(selectedTicket.status).label}
                </span>
              </div>
              
              {canManageStatus && (
                <div className="flex gap-2">
                  {selectedTicket.status !== 'investigating' && selectedTicket.status !== 'resolved' && selectedTicket.status !== 'closed' && (
                    <Button size="sm" variant="secondary" onClick={() => handleUpdateStatus('investigating')}>В работу</Button>
                  )}
                  {selectedTicket.status !== 'resolved' && selectedTicket.status !== 'closed' && (
                    <Button size="sm" onClick={() => handleUpdateStatus('resolved')} className="bg-emerald-600 hover:bg-emerald-700 uppercase font-black text-[10px]">Решить</Button>
                  )}
                  {selectedTicket.status !== 'closed' && (
                    <Button size="sm" variant="ghost" onClick={() => handleUpdateStatus('closed')}>Закрыть</Button>
                  )}
                  {selectedTicket.status === 'closed' && archiveTicket && (
                    <Button size="sm" variant="secondary" onClick={() => {
                        archiveTicket(selectedTicket.id);
                        setSelectedTicketId(null);
                    }} className="bg-slate-200 dark:bg-slate-700">В архив</Button>
                  )}
                </div>
              )}
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => {
                  setSelectedTicketId(null);
                  if (onClose) onClose();
                }}
                className="ml-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X size={20} />
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-1 overflow-hidden">
              <div className="md:col-span-2 flex flex-col gap-6 overflow-hidden">
                <Card className="p-6">
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex-1">
                      <span className="text-[9px] font-black uppercase text-slate-400 tracking-widest block mb-1">Тема проблемы</span>
                      <h2 className="text-xl font-bold text-slate-900 dark:text-white">{selectedTicket.title}</h2>
                    </div>
                    <span className={cn("text-xs font-bold shrink-0 ml-4", getPriorityInfo(selectedTicket.priority).color)}>
                      Приоритет: {getPriorityInfo(selectedTicket.priority).label}
                    </span>
                  </div>
                  
                  <div className="mb-8">
                    <span className="text-[9px] font-black uppercase text-slate-400 tracking-widest block mb-2">Суть проблемы</span>
                    <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
                      <p className="text-slate-600 dark:text-slate-300 whitespace-pre-wrap leading-relaxed italic">
                        {selectedTicket.description}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6 text-xs text-slate-400 border-t border-slate-100 dark:border-slate-800 pt-4">
                    <div className="flex items-center gap-2">
                      <User size={14} />
                      <span>Автор: <b>{selectedTicket.creatorName}</b> ({selectedTicket.creatorRole})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock size={14} />
                      <span>Создан: {new Date(selectedTicket.timestamp).toLocaleString()}</span>
                    </div>
                  </div>
                </Card>

                <div className="flex-1 flex flex-col gap-4 overflow-hidden">
                  <h4 className="font-black text-slate-400 uppercase text-[10px] tracking-widest flex items-center gap-2 px-2">
                    <MessageSquare size={14} /> Комментарии
                  </h4>
                  <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
                    {selectedTicket.comments.map(comment => (
                      <div key={comment.id} className={cn(
                        "flex flex-col gap-1 max-w-[80%]",
                        comment.authorId === currentUser.id ? "ml-auto items-end" : "mr-auto items-start"
                      )}>
                        <div className={cn(
                          "p-3 rounded-2xl text-sm",
                          comment.authorId === currentUser.id 
                            ? "bg-indigo-600 text-white rounded-tr-none" 
                            : "bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-100 dark:border-slate-700 rounded-tl-none"
                        )}>
                          {comment.text}
                        </div>
                        <div className="flex items-center gap-2 text-[9px] text-slate-400">
                          <span>{comment.authorName}</span>
                          <span>•</span>
                          <span>{new Date(comment.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          {comment.readAt && (
                            <>
                              <span>•</span>
                              <span className="text-emerald-500 font-bold uppercase tracking-tighter">
                                Прочитано: {new Date(comment.readAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                    {selectedTicket.comments.length === 0 && (
                      <div className="text-center py-10 text-slate-400 italic text-xs">
                        Нет комментариев
                      </div>
                    )}
                  </div>
                  <form onSubmit={handleAddComment} className="flex gap-2">
                    <Input 
                      placeholder="Написать ответ..."
                      value={commentText || ''}
                      onChange={e => setCommentText(e.target.value)}
                    />
                    <Button type="submit">
                      <Send size={18} />
                    </Button>
                  </form>
                </div>
              </div>

              <div className="flex flex-col gap-6 overflow-y-auto custom-scrollbar">
                <Card className="p-4 space-y-4">
                  <h5 className="font-black text-[10px] uppercase text-slate-400 tracking-widest">Доп. информация</h5>
                  <div>
                    <span className="block text-[10px] text-slate-400 mb-1">Ответственный</span>
                    {canAssignTicket ? (
                      <select
                        className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-1.5 text-xs outline-none focus:ring-1 focus:ring-indigo-500 font-bold"
                        value={selectedTicket.assignedToId || ""}
                        onChange={(e) => {
                          const s = staff.find(st => st.id === e.target.value);
                          if (s) {
                            updateTicket(selectedTicket.id, { 
                              assignedToId: s.id, 
                              assignedToName: s.login 
                            }, currentUser);
                          } else if (e.target.value === "") {
                            updateTicket(selectedTicket.id, { 
                              assignedToId: undefined, 
                              assignedToName: undefined 
                            }, currentUser);
                          }
                        }}
                      >
                        <option value="">Не назначен</option>
                        {staff
                          .filter(s => ['owner', 'tech', 'developer', 'tester'].includes(getEffectiveRole(s)))
                          .map(s => (
                          <option key={s.id} value={s.id}>{s.name} ({s.login})</option>
                        ))}
                      </select>
                    ) : (
                      <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                        <User size={14} />
                        {selectedTicket.assignedToName || 'Не назначен'}
                      </div>
                    )}
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-400 mb-1">Обновлено</span>
                    <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                      <Clock size={14} />
                      {new Date(selectedTicket.updatedAt).toLocaleString()}
                    </div>
                  </div>
                </Card>

                <Card className="p-4 space-y-4 border-indigo-100 dark:border-indigo-900/30 bg-indigo-50/30 dark:bg-indigo-900/20">
                  <h5 className="font-black text-[10px] uppercase text-indigo-500 tracking-widest">Что сделано (Developer)</h5>
                  <p className="text-xs text-slate-600 dark:text-slate-400 italic">
                    {selectedTicket.devComment || 'Нет записей'}
                  </p>
                  {(currentUserRole === 'developer' || currentUserRole === 'tech' || currentUserRole === 'owner') && (
                    <div className="space-y-2 pt-2 border-t border-indigo-100 dark:border-indigo-800">
                      <textarea 
                        className="w-full h-20 text-xs p-2 bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-900 rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                        placeholder="Опишите внесенные изменения..."
                        value={devCommentText || ''}
                        onChange={e => setDevCommentText(e.target.value)}
                      />
                      <Button size="sm" className="w-full text-[10px]" onClick={handleUpdateDevComment}>
                        Обновить инфо
                      </Button>
                    </div>
                  )}
                </Card>
              </div>
            </div>
          </div>
        ) : isAddingTicket ? (
          <Card className="p-8 max-w-2xl mx-auto w-full animate-in zoom-in-95 duration-300">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Новый тикет</h3>
              <Button variant="ghost" onClick={() => setIsAddingTicket(false)}>Отмена</Button>
            </div>
            <form onSubmit={handleAddTicket} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-black uppercase text-slate-400 tracking-widest">Тема проблемы</label>
                <Input 
                  placeholder="Введите тему..."
                  value={newTicketTitle || ''}
                  onChange={e => setNewTicketTitle(e.target.value)}
                  className="font-bold"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black uppercase text-slate-400 tracking-widest">Суть проблемы</label>
                <textarea 
                  className="w-full h-40 p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-900 dark:text-white"
                  placeholder="Опишите проблему подробно..."
                  value={newTicketDesc || ''}
                  onChange={e => setNewTicketDesc(e.target.value)}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest">Приоритет</label>
                  <select 
                    className="w-full p-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/20"
                    value={newTicketPriority}
                    onChange={e => setNewTicketPriority(e.target.value as any)}
                  >
                    <option value="low">Низкий</option>
                    <option value="medium">Средний</option>
                    <option value="high">Высокий</option>
                    <option value="urgent">Критический</option>
                  </select>
                </div>
              </div>
              <Button type="submit" className="w-full h-14 text-lg font-black uppercase tracking-widest">
                Создать тикет
              </Button>
            </form>
          </Card>
        ) : (
          <div className="flex flex-col items-center gap-4 text-slate-400">
            <TicketIcon size={64} className="opacity-20" />
            <p className="font-bold">Выберите тикет для просмотра или создайте новый</p>
          </div>
        )}
      </div>
    </div>
  );
}
