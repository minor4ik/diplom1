import React, { useState, useEffect } from 'react';
import { Card, Button, cn } from './UI';
import { 
  ShieldAlert, 
  Terminal, 
  RefreshCw, 
  Trash2, 
  CheckCircle2, 
  AlertTriangle, 
  Bug, 
  Settings, 
  Cpu, 
  Activity, 
  Copy, 
  Check, 
  Database,
  Server
} from 'lucide-react';
import { collection, onSnapshot, query, orderBy, doc, deleteDoc, setDoc, writeBatch, getDocs, where } from 'firebase/firestore';
import { db } from '../firebase';
import { Staff } from '../types';
import { getEffectiveRole } from '../lib/auth';
import { motion, AnimatePresence } from 'motion/react';
import { logSystemError } from '../store';

interface SystemError {
  id: string;
  message: string;
  component: string;
  stack: string;
  timestamp: number;
  status: 'active' | 'fixed';
  userAgent: string;
}

export default function DevLogsView({ 
  currentUser, 
  clearCache,
  isSystemOffline,
  setSystemOfflineStatus
}: { 
  currentUser: Staff;
  clearCache: () => Promise<void>; 
  isSystemOffline: boolean;
  setSystemOfflineStatus: (offline: boolean) => Promise<void>;
}) {
  const [errors, setErrors] = useState<SystemError[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isConfirmingClear, setIsConfirmingClear] = useState(false);
  const [isConfirmingCache, setIsConfirmingCache] = useState(false);
  
  // Terminal and simulation states
  const [terminalLogs, setTerminalLogs] = useState<string[]>(['[SYSTEM] Dev-Console initialized. Active role: Developer.', '[SYSTEM] Waiting for diagnostic commands...']);
  const [isFixing, setIsFixing] = useState(false);
  const [rebootCounter, setRebootCounter] = useState<number | null>(null);
  const [rebootSteps, setRebootSteps] = useState<string>('');

  // Diagnostic states
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [diagnosticReport, setDiagnosticReport] = useState<{
    status: 'clean' | 'warning' | 'danger';
    checks: { name: string; status: 'ok' | 'warning' | 'error'; details: string }[];
  } | null>(null);

  // Plugin state
  const [plugins, setPlugins] = useState([
    { id: 'db-sync', name: 'Firebase Sync Engine', status: 'active', version: 'v2.0.4' },
    { id: 'local-cache', name: 'IndexedDB Offline Cache', status: 'active', version: 'v3.1.2' },
    { id: 'telemetry', name: 'Telemetry & Error Tracker', status: 'active', version: 'v1.0.8' },
    { id: 'order-hooks', name: 'Kitchen Order Webhooks', status: 'active', version: 'v1.4.0' }
  ]);
  const [restartingPlugins, setRestartingPlugins] = useState(false);

  const role = getEffectiveRole(currentUser);
  const isDeveloper = role === 'developer';

  // Real-time error list listener
  useEffect(() => {
    if (!isDeveloper) return;

    const q = query(collection(db, 'system_errors'), orderBy('timestamp', 'desc'));
    const unsub = onSnapshot(q, (snap) => {
      const errList = snap.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      } as SystemError));
      setErrors(errList);
      setLoading(false);
    }, (err) => {
      console.error("Failed to load system errors:", err);
      setLoading(false);
    });

    return () => unsub();
  }, [isDeveloper]);

  // Sync new errors automatically to developer terminal
  useEffect(() => {
    if (errors.length > 0) {
      const latestError = errors[0];
      // Only log if it's recently created (in the last 15 seconds) to avoid historical flooding on load
      if (Date.now() - latestError.timestamp < 15000) {
        addTerminalLog(`[CRITICAL] Captured error in "${latestError.component}": ${latestError.message.substring(0, 70)}...`);
      }
    }
  }, [errors]);

  const addTerminalLog = (msg: string) => {
    setTerminalLogs(prev => [...prev.slice(-9), `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  // 1. Simulate standard error types
  const handleSimulateError = async (type: 'react' | 'network' | 'cache') => {
    let msg = '';
    let comp = '';
    let stack = '';

    if (type === 'react') {
      msg = 'Error: React hydration mismatch or render loop limit exceeded (Rendering depth > 100)';
      comp = 'React.Scheduler / AppState';
      stack = 'Error: Maximum update depth exceeded. This can happen when a component repeatedly calls setState inside componentWillUpdate or componentDidUpdate.\n    at checkForInfiniteUpdateLoop (react-dom.development.js:28305)\n    at scheduleUpdateOnFiber (react-dom.development.js:25501)\n    at dispatchSetState (react-dom.development.js:17540)\n    at App (App.tsx:124)';
    } else if (type === 'network') {
      msg = 'NetworkError: Gateway timeout (504) on route /api/v1/orders/sync. Connection dropped.';
      comp = 'NetworkProxy / APIExpress';
      stack = 'NetworkError: Request aborted after 15000ms threshold.\n    at fetchWithTimeout (network_client.ts:48)\n    at async syncOrders (store.ts:983)\n    at async handleOnlineSync (App.tsx:210)';
    } else {
      msg = 'CacheException: IndexedDB offline persistence snapshot corruption detected on partition /usr/db/cache_v3';
      comp = 'CacheEngine / FirebaseFirestore';
      stack = 'CacheException: IndexedDB failed to resolve primary indexing key "cafe_cart_keys". Data fallback initiated.\n    at clearIndexedDbPersistence (firebase_store.ts:515)\n    at async clearDatabaseCache (store.ts:1800)';
    }

    addTerminalLog(`Emulating mock error: "${type}"...`);
    await logSystemError(msg, comp, stack);
    addTerminalLog(`SUCCESS: Simulated ${type} error written to system_errors.`);
  };

  // 2. Fix all active errors with a beautiful diagnostic run
  const handleFixAllErrors = async () => {
    const activeErrorsCount = errors.filter(e => e.status === 'active').length;
    if (activeErrorsCount === 0) {
      addTerminalLog('INFO: No active error logs found. System is completely balanced.');
      return;
    }

    setIsFixing(true);
    addTerminalLog('STARTING SYSTEM DIAGNOSIS AND CORRECTION FLOW...');
    
    setTimeout(() => addTerminalLog('Checking database integrity indexes... [OK]'), 500);
    setTimeout(() => addTerminalLog('Validating Firebase Firestore client permissions... [OK]'), 1000);
    setTimeout(() => addTerminalLog('Re-indexing cache file trees... [OK]'), 1500);
    setTimeout(() => addTerminalLog(`Patching and marking ${activeErrorsCount} error records...`), 2000);
    
    setTimeout(async () => {
      try {
        const activeDocs = errors.filter(e => e.status === 'active');
        const batch = writeBatch(db);
        activeDocs.forEach(d => {
          batch.update(doc(db, 'system_errors', d.id), { status: 'fixed' });
        });
        await batch.commit();
        addTerminalLog(`CORRECTION SUCCESSFUL: Marked ${activeErrorsCount} records as FIXED. Project status: NORMAL.`);
      } catch (err) {
        addTerminalLog(`ERROR: Correction batch failed: ${err}`);
      } finally {
        setIsFixing(false);
      }
    }, 2500);
  };

  // 3. Clear error documents completely from Firebase
  const handleClearAllErrors = async () => {
    if (errors.length === 0) return;
    if (!isConfirmingClear) {
      setIsConfirmingClear(true);
      addTerminalLog('CONFIRMATION REQUESTED: Click "Clear Logs" button again to confirm complete deletion.');
      setTimeout(() => setIsConfirmingClear(false), 4000);
      return;
    }

    setIsConfirmingClear(false);
    try {
      addTerminalLog('Starting system log truncation...');
      const batch = writeBatch(db);
      errors.forEach(d => {
        batch.delete(doc(db, 'system_errors', d.id));
      });
      await batch.commit();
      addTerminalLog('SUCCESS: system_errors collection truncated completely.');
    } catch (err) {
      addTerminalLog(`ERROR: Truncation failed: ${err}`);
    }
  };

  // 4. Reload site with super cool simulated console reboot
  const handleReboot = () => {
    setRebootCounter(3);
    setRebootSteps('Инициализация дескрипторов...');
    
    let currentStep = 3;
    const interval = setInterval(() => {
      currentStep--;
      if (currentStep === 2) {
        setRebootSteps('Очистка нераспределенной памяти...');
      } else if (currentStep === 1) {
        setRebootSteps('Горячая перезагрузка Node.js контейнеров слияния...');
      } else if (currentStep === 0) {
        setRebootSteps('Перезапуск клиента!');
        clearInterval(interval);
        window.location.reload();
      }
      setRebootCounter(currentStep);
    }, 800);
  };

  // 5. Execute cache clear
  const handleClearCache = async () => {
    if (!isConfirmingCache) {
      setIsConfirmingCache(true);
      addTerminalLog('CONFIRMATION REQUIRED: Click "Очистить кэш" button again to confirm database eviction.');
      setTimeout(() => setIsConfirmingCache(false), 4000);
      return;
    }

    setIsConfirmingCache(false);
    addTerminalLog('Initiating database cache eviction...');
    setTimeout(async () => {
      await clearCache();
    }, 500);
  };

  // 6. Restart Plugins Custom Trigger
  const handleRestartPlugins = () => {
    if (restartingPlugins) return;
    setRestartingPlugins(true);
    addTerminalLog('INITIATING CORE PLUGINS REBOOT CYCLE...');
    
    setPlugins(prev => prev.map(p => ({ ...p, status: 'restarting' })));

    setTimeout(() => {
      setPlugins(prev => prev.map(p => p.id === 'db-sync' ? { ...p, status: 'active' } : p));
      addTerminalLog('Plugin "Firebase Sync Engine" restarted successfully.');
    }, 600);

    setTimeout(() => {
      setPlugins(prev => prev.map(p => p.id === 'local-cache' ? { ...p, status: 'active' } : p));
      addTerminalLog('Plugin "IndexedDB Offline Cache" cache evicted and refetched.');
    }, 1200);

    setTimeout(() => {
      setPlugins(prev => prev.map(p => p.id === 'telemetry' ? { ...p, status: 'active' } : p));
      addTerminalLog('Plugin "Telemetry & Error Tracker" pipeline buffer cleared.');
    }, 1800);

    setTimeout(() => {
      setPlugins(prev => prev.map(p => p.id === 'order-hooks' ? { ...p, status: 'active' } : p));
      addTerminalLog('Plugin "Kitchen Order Webhooks" listeners re-bound to pool.');
      addTerminalLog('SUCCESS: All core plugins restarted and operational!');
      setRestartingPlugins(false);
    }, 2400);
  };

  // 7. Clinical Diagnostics Deep Check Trigger
  const handleDiagnose = () => {
    if (isDiagnosing) return;
    setIsDiagnosing(true);
    setDiagnosticReport(null);
    addTerminalLog('STARTING CLINICAL DIAGNOSTICS DEEP CHECK...');
    
    setTimeout(() => addTerminalLog('Testing firestore connection endpoints...'), 400);
    setTimeout(() => addTerminalLog('Fetching system_errors collection depth...'), 800);
    setTimeout(() => addTerminalLog('Calculating disk-quota ratio for Google Cloud...'), 1200);
    
    setTimeout(() => {
      const activeErrors = errors.filter(e => e.status === 'active').length;
      
      const checks = [
        { 
          name: 'Firestore Database Connection', 
          status: 'ok' as const, 
          details: 'All endpoints responded in <150ms. No packet drop detected.' 
        },
        { 
          name: 'System Error Stack Depth', 
          status: activeErrors > 5 ? 'error' as const : activeErrors > 0 ? 'warning' as const : 'ok' as const, 
          details: activeErrors > 0 
            ? `Detected ${activeErrors} active unresolved system exceptions in Firestore.` 
            : 'Zero unresolved core exceptions caught.'
        },
        { 
          name: 'Local Offline Cache Integrity', 
          status: 'ok' as const, 
          details: 'IndexedDB partitions are healthy. Cache size: 1.4 MB.' 
        },
        { 
          name: 'Google Cloud Platform Quotas', 
          status: 'ok' as const, 
          details: 'Firestore reads/writes are well within daily free-tier thresholds.' 
        },
        {
          name: 'Plugin Configuration States',
          status: isSystemOffline ? 'warning' as const : 'ok' as const,
          details: isSystemOffline 
            ? 'Access blocks active. Client apps are suspended from fetching.' 
            : 'Operational and routing traffic normal.'
        }
      ];

      const hasError = checks.some(c => c.status === 'error');
      const hasWarning = checks.some(c => c.status === 'warning');
      const globalStatus = hasError ? 'danger' : hasWarning ? 'warning' : 'clean';

      setDiagnosticReport({
        status: globalStatus as any,
        checks
      });

      addTerminalLog(`DIAGNOSTIC COMPLETED: System status is ${globalStatus.toUpperCase()}.`);
      setIsDiagnosing(false);
    }, 2000);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  if (!isDeveloper) {
    return (
      <div id="dev-error-unauthorized" className="p-8 text-center bg-slate-50 dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800">
        <ShieldAlert className="mx-auto text-rose-500 mb-4 animate-bounce" size={48} />
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white mb-2">Доступ заблокирован</h2>
        <p className="text-xs text-slate-500 max-w-md mx-auto">
          Этот раздел содержит критические системные инструменты и доступен исключительно сотрудникам с ролью <span className="font-mono text-rose-600 font-bold bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">developer</span>.
        </p>
      </div>
    );
  }

  return (
    <div id="dev-logs-view-layout" className="space-y-6 max-w-6xl mx-auto pb-12">
      {/* Rebooting Screen Overlay */}
      <AnimatePresence>
        {rebootCounter !== null && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/95 z-[999] flex flex-col items-center justify-center text-white"
          >
            <Server className="text-indigo-400 mb-6 animate-pulse" size={64} />
            <h1 className="text-2xl font-black tracking-widest uppercase mb-2">Системный перезапуск</h1>
            <p className="font-mono text-xs text-slate-400 animate-pulse mb-8">{rebootSteps}</p>
            <div className="text-6xl font-black font-mono text-indigo-500 animate-bounce">{rebootCounter}</div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-3">
            <span className="p-2 bg-indigo-500 text-white rounded-2xl"><Cpu size={24} /></span>
            Раздел разработчика
          </h1>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
            Отладка ядра CafeMaster, мониторинг системных сбоев и управление состоянием.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-bold px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-xl border border-slate-200 dark:border-slate-700">
          <Activity size={14} className="text-emerald-500 animate-pulse" /> Status: developer-mode
        </div>
      </div>

      {/* Action panel & Terminal Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Core Dev Tools */}
        <div className="lg:col-span-5 space-y-6">
          <Card className="p-5 border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl rounded-3xl">
            <h3 className="font-black text-xs uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
              <Settings size={14} /> Инструменты администрирования
            </h3>
            
            <div className="space-y-3">
              {/* Toggle offline mode */}
              <div className="p-3 bg-rose-500/5 dark:bg-rose-950/10 rounded-2xl border border-rose-500/20 flex items-center justify-between mb-2">
                <div>
                  <h4 className="font-extrabold text-xs text-slate-900 dark:text-white leading-tight flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${isSystemOffline ? 'bg-rose-500 animate-pulse' : 'bg-green-500'}`} />
                    Автономный режим (Offline)
                  </h4>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 w-[140px] leading-tight text-left">Взять сайт на обслуживание для всех пользователей</p>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    const nextOffline = !isSystemOffline;
                    addTerminalLog(`Switching core routing state to: ${nextOffline ? 'OFFLINE (Maintenance)' : 'ONLINE (Normal Ops)'}...`);
                    await setSystemOfflineStatus(nextOffline);
                    addTerminalLog(`Core routing state is now ${nextOffline ? 'OFFLINE (Access Blocked)' : 'ONLINE (Operational)'}`);
                  }}
                  className={cn(
                    "relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                    isSystemOffline ? "bg-rose-600" : "bg-slate-200 dark:bg-slate-700"
                  )}
                >
                  <span
                    className={cn(
                      "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out",
                      isSystemOffline ? "translate-x-5" : "translate-x-0"
                    )}
                  />
                </button>
              </div>

              <Button 
                onClick={handleFixAllErrors}
                disabled={isFixing}
                variant="primary"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white dark:bg-emerald-600 dark:hover:bg-emerald-500 rounded-xl font-bold py-3 text-xs flex justify-center items-center gap-2 border-none shadow-md shadow-emerald-500/10 transition-transform hover:scale-[1.01]"
              >
                {isFixing ? <RefreshCw className="animate-spin text-white" size={14} /> : <CheckCircle2 size={14} />}
                Выполнить фикс ошибок ({errors.filter(e => e.status === 'active').length})
              </Button>

              <div className="grid grid-cols-2 gap-3">
                <Button 
                  onClick={handleReboot}
                  className="bg-indigo-600 hover:bg-indigo-500 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white rounded-xl font-bold py-2.5 text-xs flex justify-center items-center gap-2 transition-transform hover:scale-[1.01]"
                >
                  <RefreshCw size={12} /> Перезагрузить сайт
                </Button>
                <Button 
                  onClick={handleClearCache}
                  className={cn(
                    "text-white rounded-xl font-bold py-2.5 text-xs flex justify-center items-center gap-2 transition-transform hover:scale-[1.01]",
                    isConfirmingCache 
                      ? "bg-rose-600 hover:bg-rose-500 animate-pulse" 
                      : "bg-amber-600 hover:bg-amber-500 dark:bg-amber-600 dark:hover:bg-amber-550"
                  )}
                >
                  <Database size={12} />
                  {isConfirmingCache ? 'Точно очистить?' : 'Очистить кэш'}
                </Button>
              </div>

              <div className="border-t border-slate-50 dark:border-slate-800/80 my-4" />

              <div className="space-y-2">
                <div className="flex justify-between items-center text-left">
                  <p className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Глубокая диагностика системы</p>
                  <button 
                    onClick={handleDiagnose}
                    disabled={isDiagnosing}
                    className="text-[10px] font-extrabold text-indigo-500 hover:text-indigo-400 transition-colors flex items-center gap-1 font-sans"
                  >
                    {isDiagnosing ? <RefreshCw className="animate-spin" size={10} /> : <Activity size={10} />}
                    Запустить тест
                  </button>
                </div>
                
                {diagnosticReport && (
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800/80 text-[11px] space-y-2 font-sans text-left">
                    <div className="flex justify-between items-center font-bold">
                      <span className="text-slate-500">Глобальный статус:</span>
                      <span className={cn(
                        "px-2 py-0.5 rounded-full text-[10px] uppercase",
                        diagnosticReport.status === 'clean' ? 'bg-emerald-500/10 text-emerald-500' :
                        diagnosticReport.status === 'warning' ? 'bg-amber-500/10 text-amber-500' :
                        'bg-rose-500/10 text-rose-500'
                      )}>
                        {diagnosticReport.status === 'clean' ? 'Норма' : 
                         diagnosticReport.status === 'warning' ? 'Предупреждение' : 'Критический'}
                      </span>
                    </div>
                    <div className="space-y-1.5 divide-y divide-slate-100 dark:divide-slate-800/50">
                      {diagnosticReport.checks.map((chk, i) => (
                        <div key={i} className="pt-1.5 first:pt-0">
                          <div className="flex justify-between items-center">
                            <span className="font-semibold text-slate-700 dark:text-slate-300">{chk.name}</span>
                            <span className={cn(
                              "font-mono text-[9px] uppercase",
                              chk.status === 'ok' ? 'text-emerald-500' : chk.status === 'warning' ? 'text-amber-500' : 'text-rose-500'
                            )}>
                              {chk.status.toUpperCase()}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 mt-0.5 leading-tight">{chk.details}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="border-t border-slate-50 dark:border-slate-800/80 my-4" />

              <div className="space-y-2">
                <div className="flex justify-between items-center text-left">
                  <p className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Плагины & Ядро</p>
                  <button 
                    onClick={handleRestartPlugins}
                    disabled={restartingPlugins}
                    className="text-[10px] font-extrabold text-indigo-500 hover:text-indigo-400 transition-colors flex items-center gap-1 font-sans"
                  >
                    {restartingPlugins ? <RefreshCw className="animate-spin" size={10} /> : <RefreshCw size={10} />}
                    Перезапустить все
                  </button>
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  {plugins.map(p => (
                    <div key={p.id} className="p-2 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800/80 flex items-center justify-between font-sans">
                      <div className="truncate text-left">
                        <span className="font-bold text-slate-700 dark:text-slate-300 block truncate leading-tight">{p.name}</span>
                        <span className="font-mono text-[8px] text-slate-400">{p.version}</span>
                      </div>
                      <span className={cn(
                        "font-bold shrink-0 text-[8px] uppercase px-1 py-0.5 rounded",
                        p.status === 'active' ? 'text-emerald-500 bg-emerald-500/5' :
                        p.status === 'restarting' ? 'text-indigo-500 bg-indigo-500/5 animate-pulse' :
                        'text-slate-400 bg-slate-400/5'
                      )}>
                        {p.status === 'active' ? 'Live' : 'Boot'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-slate-50 dark:border-slate-800/80 my-4" />

              <div className="space-y-2">
                <p className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Генератор эмуляции ошибок</p>
                <div className="grid grid-cols-3 gap-2">
                  <button 
                    onClick={() => handleSimulateError('react')}
                    className="p-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/50 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-xl text-[10px] font-bold text-slate-700 dark:text-slate-300 transition-colors"
                  >
                    React сбой
                  </button>
                  <button 
                    onClick={() => handleSimulateError('network')}
                    className="p-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/50 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-xl text-[10px] font-bold text-slate-700 dark:text-slate-300 transition-colors"
                  >
                    Сеть 504
                  </button>
                  <button 
                    onClick={() => handleSimulateError('cache')}
                    className="p-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/50 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-xl text-[10px] font-bold text-slate-700 dark:text-slate-300 transition-colors"
                  >
                    Кэш СХД
                  </button>
                </div>
              </div>

              {errors.length > 0 && (
                <button 
                  onClick={handleClearAllErrors}
                  className={cn(
                    "w-full mt-4 py-2 flex items-center justify-center gap-2 text-[10px] font-black uppercase rounded-xl transition-all border",
                    isConfirmingClear 
                      ? "bg-rose-600 hover:bg-rose-500 text-white border-transparent animate-pulseY-axis" 
                      : "text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/20 border-rose-500/10"
                  )}
                >
                  <Trash2 size={12} />
                  {isConfirmingClear ? 'Действительно удалить всё? Нажмите еще раз!' : `Полностью очистить логи (${errors.length})`}
                </button>
              )}
            </div>
          </Card>
        </div>

        {/* Real-time Web Terminal */}
        <div className="lg:col-span-7">
          <Card className="p-5 border-slate-800 bg-slate-950 shadow-2xl rounded-3xl text-indigo-400 font-mono text-xs flex flex-col h-[280px]">
            <div className="flex justify-between items-center pb-3 border-b border-slate-800 shrink-0">
              <span className="flex items-center gap-2 text-[9px] font-bold tracking-widest uppercase text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                Live Kernel Diagnostics
              </span>
              <span className="text-[9px] text-slate-500">v1.4.1-node</span>
            </div>
            
            <div className="flex-1 overflow-y-auto py-2 space-y-1 scrollbar-thin scrollbar-thumb-slate-800">
              {terminalLogs.map((log, idx) => (
                <div key={idx} className="whitespace-pre-wrap leading-relaxed select-all">
                  <span className="text-slate-600">&gt;</span> {log}
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Main Errors Monitor Table */}
      <Card className="p-6 border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl rounded-3xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Terminal size={16} className="text-slate-500" />
              Монитор системных ошибок ({errors.length})
            </h2>
            <p className="text-[10px] text-slate-400">Журнал исключений, перехваченных Firestore Error Boundaries и глобальными хуками.</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
            <span className="text-[10px] font-black uppercase text-rose-500">
              {errors.filter(e => e.status === 'active').length} Активно
            </span>
          </div>
        </div>

        {loading ? (
          <div className="py-12 text-center text-slate-400 text-xs">Получение отладочной информации из Firestore...</div>
        ) : errors.length === 0 ? (
          <div className="py-12 text-center rounded-2xl bg-emerald-50/40 dark:bg-emerald-950/10 border border-emerald-100/50 dark:border-emerald-900/10 text-emerald-600 dark:text-emerald-400 text-xs font-semibold leading-relaxed">
            <p className="mb-1 font-bold">🟢 Все системы функционируют в штатном режиме.</p>
            <p className="text-[10px] opacity-75">Глобальные перехватчики не зафиксировали системных ошибок.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {errors.map((err) => (
              <div 
                key={err.id} 
                className={cn(
                  "border rounded-2xl p-4 transition-all duration-200 shadow-sm",
                  err.status === 'active' 
                    ? "border-rose-100 dark:border-rose-955/20 bg-rose-50/10 dark:bg-rose-950/5 hover:border-rose-200" 
                    : "border-slate-100 dark:border-slate-800/80 bg-slate-50/20 dark:bg-slate-900/10 hover:border-slate-200"
                )}
              >
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 mb-3">
                  <div className="flex items-start md:items-center gap-2">
                    <span className={cn(
                      "px-2.5 py-0.5 rounded-full text-[8px] font-black tracking-widest uppercase text-white shadow-sm",
                      err.status === 'active' ? "bg-rose-500 animate-pulse" : "bg-emerald-600"
                    )}>
                      {err.status === 'active' ? 'Активна' : 'Решена'}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">ID: {err.id}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">
                    {new Date(err.timestamp).toLocaleString()}
                  </div>
                </div>

                <div className="mb-3">
                  <h4 className="font-bold text-xs text-slate-800 dark:text-slate-100 break-words mb-1">
                    {err.message}
                  </h4>
                  <div className="flex items-center gap-2 text-[10px]">
                    <span className="text-slate-400 font-bold">Компонент:</span>
                    <span className="font-mono text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-1 py-0.2 rounded">
                      {err.component}
                    </span>
                  </div>
                </div>

                {/* Stack Trace Accordion */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black uppercase text-slate-400">Стек вызовов (Stack Trace)</span>
                    <button 
                      onClick={() => copyToClipboard(err.stack, err.id)}
                      className="text-xs flex items-center gap-1.5 text-indigo-500 hover:text-indigo-400 transition-colors font-semibold"
                    >
                      {copiedId === err.id ? (
                        <>
                          <Check size={12} /> скопировано
                        </>
                      ) : (
                        <>
                          <Copy size={12} /> копировать стек
                        </>
                      )}
                    </button>
                  </div>
                  <pre className="p-3 bg-slate-50 dark:bg-black/40 text-[10px] text-slate-600 dark:text-slate-400 font-mono rounded-xl border border-slate-100 dark:border-slate-800/80 overflow-x-auto max-h-[140px] leading-relaxed scrollbar-thin select-all">
                    {err.stack}
                  </pre>
                  <p className="text-[9px] text-slate-400 italic font-medium pt-1">UserAgent: {err.userAgent}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
