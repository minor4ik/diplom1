import React, { useState } from 'react';
import { Users, Plus, Trash2, Edit2, X, Phone, User as UserIcon, Shield, Search, Filter } from 'lucide-react';
import { Staff } from '../types';
import { getEffectiveRole } from '../lib/auth';
import { Card, Button, cn } from './UI';
import { motion, AnimatePresence } from 'motion/react';

interface UserManagerProps {
  staff: Staff[];
  updateStaff: (member: Staff) => Promise<void>;
  deleteStaff: (id: string) => Promise<void>;
  currentUser: Staff;
  generateId: () => string;
}

export default function UserManager({ staff, updateStaff, deleteStaff, currentUser, generateId }: UserManagerProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingMember, setEditingMember] = useState<Staff | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRole, setFilterRole] = useState<string>('all');
  
  const [newMember, setNewMember] = useState<Partial<Staff>>({
    name: '',
    position: 'Пользователь',
    role: 'user',
    phone: '',
    login: ''
  });

  const effectiveUserRole = getEffectiveRole(currentUser);
  const isOwner = ['owner', 'developer'].includes(effectiveUserRole);

  // Фильтруем системные аккаунты
  const manageableStaff = (staff || []).filter(s => {
    if (!s) return false;
    // Скрываем владельца, тех. поддержку и системный логин из основного списка управления
    const role = getEffectiveRole(s);
    if (role === 'owner' || role === 'tech') return false;
    if (s.login === 'AdminVIVT') return false;
    return true;
  });

  const filteredStaff = manageableStaff
    .filter(s => {
      const query = searchQuery.toLowerCase().trim();
      const matchesSearch = !query || 
                           (s.name || '').toLowerCase().includes(query) || 
                           (s.login || '').toLowerCase().includes(query) ||
                           (s.phone && s.phone.includes(query));
      const matchesFilter = filterRole === 'all' || s.role === filterRole;
      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => (a.name || '').localeCompare(b.name || ''));

  const handleAdd = async () => {
    if (!newMember.name || !newMember.login) return;
    
    const id = generateId();
    const member: Staff = {
      id,
      name: newMember.name!,
      position: newMember.position!,
      role: newMember.role as any || 'user',
      phone: newMember.phone || '',
      login: newMember.login!,
      password: newMember.password || ''
    };
    
    try {
      // Сбрасываем фильтры перед добавлением, чтобы пользователь точно увидел результат
      setSearchQuery('');
      setFilterRole('all');
      
      await updateStaff(member);
      setIsAdding(false);
      setNewMember({ name: '', position: 'Пользователь', role: 'user', phone: '', login: '' });
    } catch (error) {
      console.error('Ошибка при добавлении пользователя:', error);
    }
  };

  const handleUpdate = async () => {
    if (!editingMember || !editingMember.name || !editingMember.login) return;
    
    try {
      await updateStaff(editingMember);
      setEditingMember(null);
    } catch (error) {
      console.error('Ошибка при обновлении пользователя:', error);
    }
  };

  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    try {
      await deleteStaff(id);
      setDeletingId(null);
    } catch (error) {
      console.error('Ошибка при удалении пользователя:', error);
    }
  };

  const positions = [
    'Администратор',
    'Официант',
    'Повар',
    'Бармен',
    'Тестировщик',
    'Кадровик',
    ...(isOwner ? ['Разработчик'] : []),
    'Пользователь'
  ];

  const getRoleFromPosition = (pos: string) => {
    switch (pos) {
      case 'Владелец': return 'owner';
      case 'Администратор': return 'admin';
      case 'Повар': return 'chef';
      case 'Официант': return 'waiter';
      case 'Бармен': return 'bartender';
      case 'Тестировщик': return 'tester';
      case 'Разработчик': return 'developer';
      case 'Кадровик': return 'hr';
      default: return 'user';
    }
  };

  const getPositionStyles = (position: string) => {
    const safePos = (position || '').toLowerCase();
    const isTechPos = position === 'Тех. Администратор' || position === 'Тех. Поддержка' || safePos.includes('технический');
    
    if (isTechPos || position === 'Владелец') {
      return 'bg-red-100 text-red-700 border-red-200';
    }

    switch (position) {
      case 'Администратор':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'Повар':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'Официант':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Бармен':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Кадровик':
        return 'bg-teal-100 text-teal-700 border-teal-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Управление пользователями</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
            Всего пользователей в управлении: {manageableStaff.length}
          </p>
        </div>
        <Button onClick={() => setIsAdding(true)} className="w-full sm:w-auto">
          <Plus size={18} />
          Добавить пользователя
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Поиск по имени или логину..."
            className="w-full pl-10 pr-4 py-2 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500/20 outline-none"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <select 
              className="pl-9 pr-6 py-2 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500/20 outline-none appearance-none"
              value={filterRole}
              onChange={e => setFilterRole(e.target.value)}
            >
              <option value="all">Все роли</option>
              <option value="admin">Админы</option>
              <option value="chef">Повара</option>
              <option value="waiter">Официанты</option>
              <option value="bartender">Бармены</option>
              <option value="hr">Отдел кадров</option>
              <option value="tester">Тестировщики</option>
              {isOwner && <option value="developer">Разработчики</option>}
              <option value="user">Пользователи</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {filteredStaff.map((member) => (
            <motion.div
              key={member.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.2 }}
            >
              <Card className="h-full hover:shadow-lg transition-all border-slate-100 dark:border-slate-800 flex flex-col group">
                <div className="p-6 flex-1">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-800 group-hover:bg-indigo-600 group-hover:text-white transition-colors duration-300">
                      <UserIcon size={24} />
                    </div>
                    <span className={cn(
                      "px-2.5 py-1 rounded-full border text-[10px] font-black uppercase tracking-widest bg-white dark:bg-slate-950 text-slate-700 dark:text-white border-slate-200 dark:border-slate-800",
                      getPositionStyles(member.position).replace(/bg-[^ ]+ text-[^ ]+ border-[^ ]+/, "")
                    )}>
                      {member.position}
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1 line-clamp-1">{member.name}</h3>
                  <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 text-xs mb-4">
                    <Shield size={14} className="text-indigo-400 dark:text-white" />
                    <span className="font-medium uppercase tracking-tighter dark:text-white">Роль: {member.role}</span>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-slate-600 dark:text-slate-200">
                      <Phone size={14} className="text-slate-400 dark:text-white" />
                      <span>{member.phone || 'Нет телефона'}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-600 dark:text-slate-200">
                      <Users size={14} className="text-slate-400 dark:text-white" />
                      <span className="font-mono text-xs dark:text-white">{member.login}</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-50/50 dark:bg-slate-950/30 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                  {deletingId === member.id ? (
                    <div className="flex-1 flex gap-2 animate-in fade-in zoom-in duration-200">
                      <Button 
                        variant="secondary" 
                        className="flex-1 py-2 text-xs bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 border-red-100 dark:border-red-900/30 hover:bg-red-100 dark:hover:bg-red-900/40"
                        onClick={() => handleDelete(member.id)}
                      >
                        Удалить?
                      </Button>
                      <Button 
                        variant="secondary" 
                        className="flex-1 py-2 text-xs bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-300"
                        onClick={() => setDeletingId(null)}
                      >
                        Отмена
                      </Button>
                    </div>
                  ) : (
                    <>
                      <Button 
                        variant="secondary" 
                        className="flex-1 py-2 text-xs gap-1.5 bg-white dark:bg-slate-800 shadow-sm"
                        onClick={() => setEditingMember(member)}
                      >
                        <Edit2 size={14} />
                        Изменить
                      </Button>
                      <Button 
                        variant="secondary" 
                        className="aspect-square p-0 flex items-center justify-center text-slate-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:border-red-100 dark:hover:border-red-900/30 bg-white dark:bg-slate-800 shadow-sm"
                        onClick={() => setDeletingId(member.id)}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </>
                  )}
                </div>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filteredStaff.length === 0 && (
        <div className="text-center py-20 bg-slate-50 dark:bg-slate-900 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-800">
          <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center text-slate-400 mx-auto mb-4">
            <Users size={32} />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">Пользователи не найдены</h3>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Попробуйте изменить параметры поиска или фильтры</p>
        </div>
      )}

      {/* Модальное окно редактирования / добавления */}
      {(isAdding || editingMember) && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="w-full max-w-2xl"
          >
            <Card className="p-6 sm:p-8 shadow-2xl border-0 overflow-hidden relative dark:bg-slate-900">
              <div className="absolute top-0 left-0 w-full h-2 bg-indigo-600" />
              
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-white">
                    {isAdding ? 'Новый пользователь' : 'Редактирование'}
                  </h3>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">Заполните данные учетной записи</p>
                </div>
                <button 
                  onClick={() => { setIsAdding(false); setEditingMember(null); }} 
                  className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors text-slate-400"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">ФИО</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all"
                    placeholder="Иван Иванов"
                    value={(isAdding ? newMember.name : editingMember?.name) || ''}
                    onChange={e => isAdding 
                      ? setNewMember({...newMember, name: e.target.value})
                      : setEditingMember(prev => prev ? {...prev, name: e.target.value} : null)
                    }
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Должность</label>
                  <select 
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all appearance-none"
                    value={(isAdding ? newMember.position : editingMember?.position) || 'Пользователь'}
                    onChange={e => {
                      const pos = e.target.value;
                      const role = getRoleFromPosition(pos);
                      if (isAdding) {
                        setNewMember({...newMember, position: pos, role: role as any});
                      } else {
                        setEditingMember(prev => prev ? {...prev, position: pos, role: role as any} : null);
                      }
                    }}
                  >
                    {positions.map(p => <option key={p} value={p} className="dark:bg-slate-900">{p}</option>)}
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Телефон</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all"
                    placeholder="+7 (___) ___-__-__"
                    value={(isAdding ? newMember.phone : editingMember?.phone) || ''}
                    onChange={e => isAdding 
                      ? setNewMember({...newMember, phone: e.target.value})
                      : setEditingMember(prev => prev ? {...prev, phone: e.target.value} : null)
                    }
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Логин</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all"
                    placeholder="user123"
                    value={(isAdding ? newMember.login : editingMember?.login) || ''}
                    onChange={e => isAdding 
                      ? setNewMember({...newMember, login: e.target.value})
                      : setEditingMember(prev => prev ? {...prev, login: e.target.value} : null)
                    }
                  />
                </div>

                <div className="space-y-2 sm:col-span-2">
                  <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Пароль (оставьте пустым чтобы не менять)</label>
                  <input 
                    type="password" 
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-900 dark:text-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all"
                    placeholder="••••••••"
                    value={(isAdding ? newMember.password : editingMember?.password) || ''}
                    onChange={e => isAdding 
                      ? setNewMember({...newMember, password: e.target.value})
                      : setEditingMember(prev => prev ? {...prev, password: e.target.value} : null)
                    }
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3">
                <Button 
                  variant="secondary" 
                  className="px-8 py-3"
                  onClick={() => { setIsAdding(false); setEditingMember(null); }}
                >
                  Отмена
                </Button>
                <Button 
                  className="px-8 py-3 bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-100"
                  onClick={isAdding ? handleAdd : handleUpdate}
                >
                  {isAdding ? 'Создать аккаунт' : 'Сохранить изменения'}
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      )}
    </div>
  );
}
