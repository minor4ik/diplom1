import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Shield, Hammer, Server, Terminal, Lock, LogOut } from 'lucide-react';
import Login from './Login';
import { Staff } from '../types';

interface MaintenanceModeProps {
  staff: Staff[];
  onLogin: (user: Staff) => void;
  currentUser: Staff | null;
  onLogout: () => void;
}

export default function MaintenanceMode({
  staff,
  onLogin,
  currentUser,
  onLogout
}: MaintenanceModeProps) {
  const [showLogin, setShowLogin] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between p-6 md:p-12 relative overflow-hidden font-sans">
      {/* Visual background decoration */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-indigo-950/20 via-slate-950 to-slate-950 pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-indigo-500/5 rounded-full blur-[120px] pointer-events-none animate-pulse" />

      {/* Top logo header */}
      <header className="flex justify-between items-center z-10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-2xl">
            <Server size={22} className="animate-pulse" />
          </div>
          <div>
            <span className="font-sans font-black tracking-wider text-xs uppercase text-slate-400">CafeMaster</span>
            <div className="text-[10px] font-mono text-indigo-400 leading-none">KERNEL v1.4.1</div>
          </div>
        </div>
        <div className="flex items-center gap-2 text-[10px] font-mono px-3 py-1.5 bg-rose-500/10 text-rose-400 rounded-full border border-rose-500/20">
          <span className="w-1.5 h-1.5 bg-rose-400 rounded-full animate-ping" />
          MAINTENANCE ACTIVE
        </div>
      </header>

      {/* Main card */}
      <main className="max-w-2xl mx-auto w-full flex flex-col items-center justify-center py-12 z-10 text-center flex-1">
        {!showLogin ? (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
          >
            <div className="relative inline-block mx-auto mb-2">
              <div className="p-6 bg-rose-500/10 border border-rose-500/30 text-rose-500 rounded-[2.5rem] relative z-10">
                <Shield size={56} className="animate-pulse" />
              </div>
              <div className="absolute -bottom-2 -right-2 p-2.5 bg-slate-900 border border-slate-800 text-amber-500 rounded-2xl z-20 shadow-xl">
                <Hammer size={16} />
              </div>
            </div>

            <div className="space-y-3">
              <h1 className="text-3xl md:text-4xl font-sans font-black tracking-tight text-white">
                Технические работы
              </h1>
              <p className="text-sm text-slate-400 max-w-md mx-auto leading-relaxed font-medium">
                Разработчик временно приостановил обслуживание сайта для проведения диагностики, обновления плагинов и устранения неполадок ядра.
              </p>
            </div>

            {/* Diagnostic Logs Panel */}
            <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-3xl text-left max-w-lg mx-auto font-mono text-[11px] leading-relaxed shadow-2xl relative">
              <div className="flex justify-between items-center text-[10px] text-slate-500 pb-3 border-b border-slate-800 mb-3">
                <span className="flex items-center gap-1.5 font-bold"><Terminal size={12} /> STATUS REPORT</span>
                <span>SECURE MODE</span>
              </div>
              <div className="space-y-1.5 text-slate-400">
                <div><span className="text-slate-600">&gt;</span> SYSTEM STATE: <span className="text-rose-400 font-bold">OFFLINE</span></div>
                <div><span className="text-slate-600">&gt;</span> ROUTING: <span className="text-amber-500">PAUSED_REWRITING_ACTIVE</span></div>
                <div><span className="text-slate-600">&gt;</span> PLUGINS STATUS: <span className="text-slate-500">STANDBY_WAITING_RESTART</span></div>
                {currentUser && (
                  <div className="border-t border-slate-800 pt-2 mt-2 text-[10px] flex items-center justify-between">
                    <span className="text-slate-500">Ваша текущая роль: {currentUser.role}</span>
                    <span className="text-rose-400 font-bold">Доступ ограничен</span>
                  </div>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
              {currentUser ? (
                <button
                  onClick={onLogout}
                  className="px-6 py-3 font-semibold text-xs bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-2xl transition-all flex items-center gap-2"
                >
                  <LogOut size={14} /> Выйти из аккаунта
                </button>
              ) : (
                <button
                  onClick={() => setShowLogin(true)}
                  className="px-6 py-3 font-bold text-xs bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl transition-all shadow-lg shadow-indigo-600/15 flex items-center gap-2"
                >
                  <Lock size={14} /> Вход для разработчиков
                </button>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-[2rem] p-6 text-left shadow-2xl relative"
          >
            <div className="mb-4 flex justify-between items-center">
              <span className="text-slate-400 text-xs font-bold font-mono">Авторизация персонала</span>
              <button
                onClick={() => setShowLogin(false)}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-bold transition-colors"
              >
                Вернуться назад
              </button>
            </div>
            
            <Login onLogin={(user) => {
              onLogin(user);
              if (user.role === 'developer') {
                setShowLogin(false);
              }
            }} staff={staff} />
          </motion.div>
        )}
      </main>

      {/* Footer credits */}
      <footer className="text-center z-10 shrink-0">
        <span className="font-mono text-[9px] text-slate-600 tracking-wider">
          CAFEMASTER CLOUD SECURITY GATEWAY &bull; STRICT AUTHORIZATION ENFORCED
        </span>
      </footer>
    </div>
  );
}
