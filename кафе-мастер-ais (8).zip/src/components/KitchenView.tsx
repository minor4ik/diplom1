import React, { useState, useEffect, useMemo } from 'react';
import { Clock, CheckCircle2, Play, Check, ChefHat, AlertCircle, Trash2, Timer, Zap } from 'lucide-react';
import { Order, Dish, Staff } from '../types';
import { Card, Button, cn } from './UI';
import { motion, AnimatePresence } from 'motion/react';

interface KitchenViewProps {
  orders: Order[];
  updateStatus: (id: string, status: Order['status'], user?: Staff) => void;
  dishes: Dish[];
  currentUser: Staff;
  clearKitchen?: () => void;
}

export default function KitchenView({ orders, updateStatus, dishes, currentUser, clearKitchen }: KitchenViewProps) {
  const [now, setNow] = useState(Date.now());
  const [loadingId, setLoadingId] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const activeOrders = useMemo(() => {
    const sixteenHoursAgo = Date.now() - (16 * 60 * 60 * 1000);
    return orders.filter(o => 
      ['pending', 'cooking', 'ready'].includes(o.status) && 
      o.timestamp > sixteenHoursAgo
    ).sort((a, b) => a.timestamp - b.timestamp);
  }, [orders]);

  const handleUpdateStatus = async (id: string, status: Order['status']) => {
    if (loadingId) return;
    setLoadingId(id);
    try {
      await updateStatus(id, status, currentUser);
    } finally {
      setLoadingId(null);
    }
  };

  const getEstimatedTime = (order: Order) => {
    let baseTime = 15;
    if (order.total > 3000) baseTime = 25;
    if (order.total > 5000) baseTime = 35;
    if (order.total > 10000) baseTime = 45;

    const hasChefDish = order.items.some(item => item.dishId === 'chef_special' || item.name === 'Блюдо от шефа');
    if (hasChefDish) baseTime = Math.max(baseTime, 30);

    let maxDishPrepTime = 0;
    order.items.forEach(item => {
      const dish = dishes.find(d => d.id === item.dishId);
      const prep = dish?.prepTime || 10;
      if (prep > maxDishPrepTime) maxDishPrepTime = prep;
    });

    const finalBase = Math.max(baseTime, maxDishPrepTime);
    return finalBase + (order.items.length - 1) * 2;
  };

  const getTimeStatus = (order: Order) => {
    const estimatedMinutes = getEstimatedTime(order);
    const elapsedSeconds = Math.floor((now - order.timestamp) / 1000);
    const estimatedSeconds = estimatedMinutes * 60;
    const remainingSeconds = estimatedSeconds - elapsedSeconds;
    const isOverdue = remainingSeconds < 0;

    let absSeconds = Math.abs(remainingSeconds);
    if (isOverdue && absSeconds > 900) absSeconds = 900;

    const mins = Math.floor(absSeconds / 60);
    const secs = absSeconds % 60;
    const timeStr = `${mins}:${secs.toString().padStart(2, '0')}`;

    return { timeStr, isOverdue };
  };

  const isPrivileged = ['owner', 'admin', 'tech', 'developer'].includes(currentUser.role);

  const handleCancelOrder = async (id: string) => {
    if (!window.confirm('Вы уверены, что хотите отменить этот заказ?')) return;
    try {
      await updateStatus(id, 'cancelled', currentUser);
    } catch (error) {
      console.error('Error cancelling order:', error);
    }
  };

  return (
    <div className="space-y-8 max-w-[1600px] mx-auto">
      {/* Dynamic Header Toolbar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-6 bg-white dark:bg-slate-900/40 rounded-[2rem] border border-slate-100 dark:border-white/5 shadow-sm">
        <div className="flex items-center gap-5">
          <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-500/20">
            <ChefHat size={32} />
          </div>
          <div>
            <h2 className="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight leading-none mb-1">Кухня</h2>
            <p className="text-sm text-slate-500 dark:text-white/40 font-bold uppercase tracking-widest">
              {activeOrders.length === 0 ? 'Все заказы выданы' : `Активно: ${activeOrders.length} чека`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden lg:flex items-center gap-4 px-5 py-2.5 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5">
            <div className="flex flex-col items-center">
              <span className="text-[10px] font-black text-slate-400 dark:text-white/30 uppercase tracking-[0.2em]">В работе</span>
              <span className="text-lg font-black text-indigo-600 dark:text-white">
                {activeOrders.filter(o => o.status === 'cooking').length}
              </span>
            </div>
            <div className="w-px h-8 bg-slate-200 dark:bg-white/10" />
            <div className="flex flex-col items-center">
              <span className="text-[10px] font-black text-slate-400 dark:text-white/30 uppercase tracking-[0.2em]">Ожидание</span>
              <span className="text-lg font-black text-amber-500">
                {activeOrders.filter(o => o.status === 'pending').length}
              </span>
            </div>
          </div>

          {isPrivileged && activeOrders.length > 0 && (
            <Button 
              variant="secondary" 
              className="h-12 px-6 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 border-red-100 dark:border-white/10 bg-white dark:bg-slate-950 font-black uppercase text-xs tracking-widest transition-all active:scale-95"
              onClick={() => {
                if (window.confirm('Вы уверены, что хотите очистить все активные заказы с кухни?')) {
                  clearKitchen?.();
                }
              }}
            >
              <Trash2 size={16} />
              Очистить кухню
            </Button>
          )}
        </div>
      </div>

      {/* Orders Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <AnimatePresence mode="popLayout">
          {activeOrders.map(order => {
            const { timeStr, isOverdue } = getTimeStatus(order);
            
            return (
              <motion.div
                key={order.id}
                layout
                initial={{ opacity: 0, y: 30, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8, transition: { duration: 0.2 } }}
                className="h-full"
              >
                <Card className={cn(
                  "h-full flex flex-col border-0 bg-white dark:bg-slate-950 shadow-2xl shadow-slate-200/50 dark:shadow-none overflow-hidden group rounded-[2rem]",
                  order.status === 'pending' ? "ring-4 ring-amber-500/10" : 
                  order.status === 'cooking' ? "ring-4 ring-indigo-500/10" : "ring-4 ring-emerald-500/10"
                )}>
                  <div className={cn(
                    "h-2 w-full",
                    isOverdue && order.status !== 'ready' ? "bg-red-500 animate-pulse" :
                    order.status === 'pending' ? "bg-amber-400" : 
                    order.status === 'cooking' ? "bg-indigo-500" : "bg-emerald-500"
                  )} />

                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-black text-3xl text-slate-900 dark:text-white leading-none tracking-tighter">№{order.tableNumber}</h3>
                          <span className="text-[10px] font-black text-slate-400 dark:text-white/40 bg-slate-100 dark:bg-white/10 px-2.5 py-1 rounded-lg uppercase tracking-tighter shadow-inner">
                            {order.orderNumber || '0000'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] font-black text-slate-400 dark:text-white/30 uppercase tracking-widest">
                          <Clock size={12} className="text-indigo-500" />
                          {new Date(order.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          {order.guests > 0 && <span className="bg-slate-50 dark:bg-white/5 px-1.5 py-0.5 rounded ml-1 text-slate-500">{order.guests} Г</span>}
                        </div>
                      </div>
                      
                      <div className="flex flex-col items-end gap-2">
                        <div className={cn(
                          "px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-[0.1em] shadow-sm flex items-center gap-1.5",
                          isOverdue && order.status !== 'ready' ? "bg-red-500 text-white" :
                          order.status === 'pending' ? "bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400 border border-amber-100 dark:border-amber-900/30" : 
                          order.status === 'cooking' ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/30" : 
                          "bg-emerald-500 text-white shadow-emerald-200"
                        )}>
                          {order.status === 'cooking' && <Zap size={10} className="animate-pulse" />}
                          {isOverdue && order.status !== 'ready' ? 'ОПАЗДЫВАЕТ' :
                           order.status === 'pending' ? 'В ОЧЕРЕДИ' : 
                           order.status === 'cooking' ? 'ГОТОВИТСЯ' : 'ГОТОВО'}
                        </div>
                        {isPrivileged && (
                          <button 
                            onClick={() => handleCancelOrder(order.id)}
                            className="text-[10px] font-black text-red-500 uppercase tracking-widest hover:text-red-600 transition-colors"
                          >
                            Отменить
                          </button>
                        )}
                      </div>
                    </div>

                    {order.status !== 'ready' && (
                      <div className={cn(
                        "mb-6 p-4 rounded-3xl flex items-center justify-between border relative overflow-hidden group-hover:scale-[1.02] transition-transform",
                        isOverdue 
                          ? "bg-red-50 dark:bg-red-950/40 border-red-100 dark:border-red-900/30 text-red-600" 
                          : "bg-slate-50 dark:bg-white/5 border-slate-100 dark:border-white/10 text-slate-900 dark:text-white"
                      )}>
                        <div className="flex items-center gap-3 z-10">
                          <div className={cn(
                            "w-10 h-10 rounded-2xl flex items-center justify-center shadow-lg",
                            isOverdue ? "bg-red-600 text-white shadow-red-200" : "bg-indigo-600 text-white shadow-indigo-200 dark:shadow-none"
                          )}>
                            <Timer size={20} />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-[9px] font-black uppercase tracking-[0.2em] opacity-50">
                              {isOverdue ? 'ЗАДЕРЖКА' : 'ОСТАЛОСЬ'}
                            </span>
                            <span className={cn(
                              "text-2xl font-black tabular-nums leading-none tracking-tight",
                              isOverdue && "animate-pulse"
                            )}>{timeStr}</span>
                          </div>
                        </div>
                        {isOverdue && (
                          <div className="absolute inset-0 bg-red-500/5 animate-pulse" />
                        )}
                      </div>
                    )}

                    <div className="space-y-4 mb-8">
                      {order.items.map((item, i) => (
                        <div key={i} className="flex items-center justify-between group/item">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-slate-50 dark:bg-white/5 flex items-center justify-center text-base font-black text-slate-900 dark:text-white border-2 border-slate-100 dark:border-white/10 group-hover/item:border-indigo-500 transition-all">
                              {item.quantity}
                            </div>
                            <span className="text-base font-bold text-slate-700 dark:text-white/80 line-clamp-1">{item.name}</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-auto">
                      {order.status === 'pending' && (
                        <Button 
                          className="w-full h-14 text-sm font-black uppercase tracking-widest bg-indigo-600 hover:bg-indigo-700 shadow-xl shadow-indigo-500/20 dark:shadow-none transition-all active:scale-95 rounded-2xl gap-3" 
                          onClick={() => handleUpdateStatus(order.id, 'cooking')}
                          disabled={loadingId === order.id}
                        >
                          {loadingId === order.id ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : (
                            <>
                              <Play size={20} fill="currentColor" />
                              Начать готовить
                            </>
                          )}
                        </Button>
                      )}
                      {order.status === 'cooking' && (
                        <Button 
                          className="w-full h-14 text-sm font-black uppercase tracking-widest bg-emerald-500 hover:bg-emerald-600 shadow-xl shadow-emerald-500/20 dark:shadow-none transition-all active:scale-95 rounded-2xl gap-3 text-white" 
                          onClick={() => handleUpdateStatus(order.id, 'ready')}
                          disabled={loadingId === order.id}
                        >
                          {loadingId === order.id ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : (
                            <>
                              <CheckCircle2 size={24} />
                              Готово
                            </>
                          )}
                        </Button>
                      )}
                      {order.status === 'ready' && (
                        <Button 
                          variant="secondary" 
                          className="w-full h-14 text-sm font-black uppercase tracking-widest bg-slate-900 dark:bg-white text-white dark:text-slate-950 hover:bg-slate-800 dark:hover:bg-slate-100 transition-all active:scale-95 rounded-2xl gap-3 border-0 shadow-lg" 
                          onClick={() => handleUpdateStatus(order.id, 'completed')}
                          disabled={loadingId === order.id}
                        >
                          {loadingId === order.id ? <div className="w-5 h-5 border-2 border-slate-500 border-t-slate-900 rounded-full animate-spin" /> : (
                            <>
                              <Check size={24} strokeWidth={3} />
                              Выдано
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Enhanced Empty State */}
      {activeOrders.length === 0 && (
        <div className="flex flex-col items-center justify-center py-40 text-center animate-in fade-in zoom-in duration-1000">
          <div className="relative mb-10">
            <div className="w-32 h-32 bg-indigo-50 dark:bg-white/5 rounded-[3rem] flex items-center justify-center text-indigo-500 dark:text-white rotate-12 transition-all hover:rotate-0 duration-700 group cursor-default shadow-sm border border-slate-100 dark:border-white/5">
              <ChefHat size={72} strokeWidth={1} className="group-hover:scale-110 transition-transform" />
            </div>
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.5, type: 'spring' }}
              className="absolute -bottom-3 -right-3 w-14 h-14 bg-emerald-500 rounded-3xl flex items-center justify-center text-white border-8 border-slate-50 dark:border-slate-950 shadow-xl"
            >
              <Check size={28} strokeWidth={4} />
            </motion.div>
          </div>
          <h3 className="text-4xl font-black text-slate-900 dark:text-white uppercase tracking-tighter mb-4">На кухне штиль!</h3>
          <p className="text-slate-500 dark:text-white/40 max-w-sm font-medium leading-relaxed text-lg">
            Все активные заказы успешно выданы. Можно протереть столы и подготовиться к следующему наплыву гостей.
          </p>
          <div className="mt-10 flex gap-2">
             {[1, 2, 3].map(i => (
               <div key={i} className="w-1.5 h-1.5 rounded-full bg-slate-200 dark:bg-white/10" />
             ))}
          </div>
        </div>
      )}
    </div>
  );
}
