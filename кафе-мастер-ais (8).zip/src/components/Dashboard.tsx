import React, { useMemo, useState, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
} from 'recharts';
import { TrendingUp, Users, RussianRuble, ShoppingBag, Wifi, Lock } from 'lucide-react';
import { Order, Staff } from '../types';
import { Card, cn } from './UI';
import { getValidOrders } from '../lib/stats';
import { db } from '../firebase';
import { doc, getDoc } from 'firebase/firestore';
import { QRCodeSVG } from 'qrcode.react';

import { View } from '../types';

interface DashboardProps {
  orders: Order[];
  onNavigate: (view: View, params?: { ticketId?: string }) => void;
  currentUser: Staff;
}

export default function Dashboard({ orders, onNavigate, currentUser }: DashboardProps) {
  const [isMounted, setIsMounted] = useState(false);
  const [wifiInfo, setWifiInfo] = useState<{ ssid: string, pass: string } | null>(null);
  
  useEffect(() => {
     const fetchWifi = async () => {
       const snap = await getDoc(doc(db, 'settings', 'wifi'));
       if (snap.exists()) {
         const data = snap.data();
         const isStaff = currentUser.role !== 'user';
         setWifiInfo({
           ssid: isStaff ? data.staffSsid : data.customerSsid,
           pass: isStaff ? data.staffPassword : data.customerPassword
         });
       }
     };
     fetchWifi();
  }, [currentUser.role]);

  useEffect(() => {
    const timer = setTimeout(() => setIsMounted(true), 500);
    return () => clearTimeout(timer);
  }, []);

  const stats = useMemo(() => {
    const validOrders = getValidOrders(orders);
    
    const totalRevenue = validOrders.reduce((sum, o) => sum + o.total, 0);
    const totalGuests = validOrders.reduce((sum, o) => sum + (o.guests || 0), 0);
    const avgOrder = validOrders.length > 0 ? totalRevenue / validOrders.length : 0;
    
    return [
      { label: 'Общая выручка', value: `${totalRevenue.toLocaleString()} ₽`, icon: RussianRuble, color: 'text-emerald-600', bg: 'bg-emerald-50', target: 'reports' as View },
      { label: 'Заказы', value: validOrders.length, icon: ShoppingBag, color: 'text-indigo-600', bg: 'bg-indigo-50', target: 'reports' as View },
      { label: 'Ср. чек', value: `${Math.round(avgOrder).toLocaleString()} ₽`, icon: TrendingUp, color: 'text-amber-600', bg: 'bg-amber-50', target: 'reports' as View },
      { label: 'Посетители', value: totalGuests, icon: Users, color: 'text-rose-600', bg: 'bg-rose-50', target: 'reports' as View },
    ];
  }, [orders]);

  const chartData = useMemo(() => {
    const hourlyData: Record<string, number> = {};
    
    // Инициализируем часы
    for (let i = 9; i <= 22; i++) {
      const hour = `${i.toString().padStart(2, '0')}:00`;
      hourlyData[hour] = 0;
    }

    getValidOrders(orders).forEach(order => {
      const date = new Date(order.timestamp);
      const hour = `${date.getHours().toString().padStart(2, '0')}:00`;
      if (hourlyData[hour] !== undefined) {
        hourlyData[hour] += order.total;
      }
    });

    return Object.entries(hourlyData).map(([time, value]) => ({
      time,
      продажи: value
    }));
  }, [orders]);

  const categoryData = useMemo(() => {
    const categories: Record<string, number> = {};
    getValidOrders(orders).forEach(order => {
      order.items.forEach(item => {
        categories[item.name] = (categories[item.name] || 0) + item.quantity;
      });
    });

    return Object.entries(categories)
      .map(([name, количество]) => ({ name, количество }))
      .sort((a, b) => b.количество - a.количество)
      .slice(0, 5);
  }, [orders]);

  return (
    <div className="space-y-4 sm:space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {wifiInfo && (
            <Card className="p-6 bg-indigo-600 border-none text-white overflow-hidden relative group">
                <div className="absolute -right-4 -top-4 opacity-10 group-hover:scale-110 transition-transform duration-700">
                    <Wifi size={120} />
                </div>
                <div className="relative z-10 flex flex-col h-full">
                    <div className="flex justify-between items-start">
                        <div>
                            <div className="flex items-center gap-2 mb-1">
                                <Wifi size={14} className="text-indigo-200" />
                                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-200">WiFi Доступ</span>
                            </div>
                            <h4 className="text-lg font-black truncate max-w-[120px]">{wifiInfo.ssid}</h4>
                        </div>
                        <div className="bg-white p-1.5 rounded-lg shadow-inner shrink-0 scale-90 origin-top-right">
                           <QRCodeSVG 
                             value={`WIFI:S:${wifiInfo.ssid};T:${wifiInfo.pass ? 'WPA' : ''};P:${wifiInfo.pass || ''};;`} 
                             size={64}
                             level="H"
                           />
                        </div>
                    </div>
                    <div className="mt-2 pt-2 border-t border-indigo-500/30">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <Lock size={12} className="text-indigo-200" />
                                <span className="font-mono text-sm font-bold tracking-widest">{wifiInfo.pass || 'БЕЗ ПАРОЛЯ'}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </Card>
        )}
        {stats.map((stat, i) => (
          <Card 
            key={i} 
            className="p-6 cursor-pointer hover:shadow-lg hover:scale-[1.02] transition-all active:scale-95"
            onClick={() => onNavigate(stat.target)}
          >
            <div className="flex items-center gap-4">
              <div className={cn(stat.bg, "p-3 rounded-xl", stat.color, "dark:bg-slate-800")}>
                <stat.icon size={24} />
              </div>
              <div>
                <p className="text-sm text-slate-500 font-medium dark:text-slate-400">{stat.label}</p>
                <p className="text-2xl font-bold text-slate-900 dark:text-white">{stat.value}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-8">
        <Card className="p-4 sm:p-6">
          <h3 className="text-lg font-bold mb-4 sm:mb-6 text-slate-900 dark:text-white">Динамика продаж</h3>
          <div className="h-64 sm:h-80 w-full min-h-[250px]">
            {isMounted && (
              <ResponsiveContainer width="99%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                  <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                  <Tooltip 
                    contentStyle={{ 
                      borderRadius: '12px', 
                      border: 'none', 
                      boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                      backgroundColor: document.documentElement.classList.contains('dark') ? '#1e293b' : 'rgba(255, 255, 255, 0.95)',
                      color: document.documentElement.classList.contains('dark') ? '#f1f5f9' : '#0f172a'
                    }}
                    itemStyle={{ color: '#4f46e5' }}
                    formatter={(value: any) => [`${value.toLocaleString()} ₽`, 'Продажи']}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="продажи" 
                    stroke="#4f46e5" 
                    strokeWidth={4} 
                    dot={{ r: 4, fill: '#4f46e5', strokeWidth: 2, stroke: '#fff' }} 
                    activeDot={{ r: 6, stroke: '#fff', strokeWidth: 2 }}
                    isAnimationActive={true}
                    animationDuration={1500}
                    animationEasing="ease-in-out"
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>

        <Card className="p-4 sm:p-6">
          <h3 className="text-lg font-bold mb-4 sm:mb-6 text-slate-900 dark:text-white">Популярные блюда</h3>
          <div className="h-64 sm:h-80 w-full min-h-[250px]">
            {isMounted && (
              <ResponsiveContainer width="99%" height="100%">
                <BarChart data={categoryData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                  <Tooltip 
                    contentStyle={{ 
                      borderRadius: '12px', 
                      border: 'none', 
                      boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                      backgroundColor: document.documentElement.classList.contains('dark') ? '#1e293b' : 'rgba(255, 255, 255, 0.95)',
                      color: document.documentElement.classList.contains('dark') ? '#f1f5f9' : '#0f172a'
                    }}
                    itemStyle={{ color: '#818cf8' }}
                  />
                  <Bar 
                    dataKey="количество" 
                    fill="#818cf8" 
                    radius={[6, 6, 0, 0]} 
                    isAnimationActive={true}
                    animationDuration={1500}
                    animationEasing="ease-in-out"
                  />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
