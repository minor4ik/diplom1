import React, { useState, useMemo } from 'react';
import { Search, Filter, History, User, Shield, Terminal, RefreshCw, Trash2, CheckCircle2, XCircle, AlertCircle, ShoppingBag, Wallet } from 'lucide-react';
import { ActivityLog, Role, Staff } from '../types';
import { Card, Input, cn } from './UI';

interface LogsViewProps {
  logs: ActivityLog[];
  staff: Staff[];
}

const ROLE_LABELS: Record<Role, string> = {
  owner: 'Владелец',
  admin: 'Администратор',
  chef: 'Шеф-повар',
  waiter: 'Официант',
  bartender: 'Бармен',
  tech: 'Тех. поддержка',
  tester: 'Тестировщик',
  developer: 'Разработчик',
  hr: 'Отдел кадров',
  user: 'Пользователь',
  other: 'Сотрудник'
};

export default function LogsView({ logs, staff }: LogsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<Role | 'all'>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const getActionStyles = (action: string) => {
    const a = (action || '').toLowerCase();
    if (a.includes('созд') || a.includes('добав')) return 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 px-2 py-0.5 rounded';
    if (a.includes('удал') || a.includes('отмен')) return 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-900/20 px-2 py-0.5 rounded';
    if (a.includes('измен') || a.includes('обнов')) return 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 px-2 py-0.5 rounded';
    if (a.includes('заказ')) return 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/20 px-2 py-0.5 rounded';
    return 'text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800 px-2 py-0.5 rounded';
  };

  const getActionIcon = (action: string) => {
    const a = (action || '').toLowerCase();
    if (a.includes('созд') || a.includes('добав')) return <CheckCircle2 size={12} />;
    if (a.includes('удал') || a.includes('отмен')) return <XCircle size={12} />;
    if (a.includes('заказ')) return <ShoppingBag size={12} />;
    if (a.includes('баланс') || a.includes('кошел')) return <Wallet size={12} />;
    return <Terminal size={12} />;
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      const matchesSearch = 
        (log.userName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (log.action || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (log.details || '').toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesRole = roleFilter === 'all' || log.userRole === roleFilter;
      
      return matchesSearch && matchesRole;
    });
  }, [logs, searchTerm, roleFilter]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={handleRefresh}
            className={cn(
               "p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all",
               isRefreshing && "animate-spin"
            )}
          >
            <RefreshCw size={20} className="text-slate-400" />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Логи активности</h2>
            <p className="text-slate-500 dark:text-slate-400">История всех действий в системе</p>
          </div>
        </div>
      </div>

      <Card className="p-4 bg-slate-50/50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-800">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <Input
              placeholder="Поиск по действию, пользователю или деталям..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <div className="flex items-center gap-2 bg-white dark:bg-slate-800 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700">
              <Filter size={16} className="text-slate-400" />
              <select 
                className="bg-transparent text-sm font-medium outline-none text-slate-900 dark:text-slate-100 cursor-pointer"
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value as Role | 'all')}
              >
                <option value="all" className="text-slate-900 bg-white dark:bg-slate-800 dark:text-slate-100 font-medium">Все роли</option>
                <option value="admin" className="text-slate-900 bg-white dark:bg-slate-800 dark:text-slate-100 font-medium">Админы</option>
                <option value="chef" className="text-slate-900 bg-white dark:bg-slate-800 dark:text-slate-100 font-medium">Повара</option>
                <option value="waiter" className="text-slate-900 bg-white dark:bg-slate-800 dark:text-slate-100 font-medium">Официанты</option>
                <option value="bartender" className="text-slate-900 bg-white dark:bg-slate-800 dark:text-slate-100 font-medium">Бармены</option>
                <option value="user" className="text-slate-900 bg-white dark:bg-slate-800 dark:text-slate-100 font-medium">Пользователи</option>
              </select>
            </div>
          </div>
        </div>
      </Card>

      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="overflow-x-auto hidden sm:block">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
                <th className="px-4 py-4 text-[11px] font-bold text-slate-400 dark:text-white uppercase tracking-wider whitespace-nowrap">Дата и время</th>
                <th className="px-4 py-4 text-[11px] font-bold text-slate-400 dark:text-white uppercase tracking-wider whitespace-nowrap">Пользователь</th>
                <th className="px-4 py-4 text-[11px] font-bold text-slate-400 dark:text-white uppercase tracking-wider whitespace-nowrap">Действие</th>
                <th className="px-4 py-4 text-[11px] font-bold text-slate-400 dark:text-white uppercase tracking-wider whitespace-nowrap">Детали</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-900 bg-white dark:bg-slate-900">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-slate-400 dark:text-slate-600">
                    <div className="flex flex-col items-center gap-2">
                      <Terminal size={32} className="opacity-20 dark:text-white" />
                      <p className="dark:text-white/40">Логи не найдены</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/20 transition-colors">
                    <td className="px-4 py-4">
                      <div className="flex flex-col">
                        <span className="text-sm font-medium text-slate-900 dark:text-white">
                          {new Date(log.timestamp).toLocaleDateString()}
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-white/60">
                          {new Date(log.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-white/10 text-indigo-600 dark:text-white flex items-center justify-center shrink-0">
                          <User size={14} />
                        </div>
                        <div className="flex flex-col min-w-0">
                          <span className="text-sm font-bold text-slate-900 dark:text-white truncate max-w-[120px]">{log.userName}</span>
                          <span className="text-[10px] text-indigo-500 dark:text-white font-bold uppercase truncate">
                            {ROLE_LABELS[log.userRole] || log.userRole}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2">
                        <span className={cn("text-xs font-bold flex items-center gap-1.5 whitespace-nowrap", getActionStyles(log.action))}>
                          {getActionIcon(log.action)}
                          {log.action}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs">{log.details || '—'}</p>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile Vertical View */}
        <div className="sm:hidden divide-y divide-slate-100 dark:divide-slate-800">
          {filteredLogs.length === 0 ? (
            <div className="px-6 py-12 text-center text-slate-400 dark:text-slate-600 bg-white dark:bg-slate-900">
              <div className="flex flex-col items-center gap-2">
                <Terminal size={32} className="opacity-20 dark:text-white" />
                <p className="dark:text-white/40 text-sm">Логи не найдены</p>
              </div>
            </div>
          ) : (
            filteredLogs.map(log => (
              <div key={log.id} className="p-4 bg-white dark:bg-slate-900 space-y-3">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-white/10 text-indigo-600 dark:text-white flex items-center justify-center">
                      <User size={14} />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm font-bold text-slate-900 dark:text-white">{log.userName}</span>
                      <span className="text-[10px] text-indigo-500 dark:text-white font-bold uppercase">
                        {ROLE_LABELS[log.userRole] || log.userRole}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-medium text-slate-500 dark:text-slate-400 block">
                      {new Date(log.timestamp).toLocaleDateString()}
                    </span>
                    <span className="text-[10px] font-medium text-slate-400 dark:text-slate-500 block">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={cn("text-[10px] font-bold flex items-center gap-1.5", getActionStyles(log.action))}>
                    {getActionIcon(log.action)}
                    {log.action}
                  </span>
                </div>
                {log.details && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 pl-1 border-l-2 border-slate-100 dark:border-slate-800 italic">
                    {log.details}
                  </p>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
