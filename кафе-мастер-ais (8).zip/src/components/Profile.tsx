import React, { useRef, useState, useEffect } from 'react';
import { Staff, Order, Ticket } from '../types';
import { Card, Button, Input, cn } from './UI';
import { User, Shield, Phone, Key, Calendar, LayoutDashboard, Ticket as TicketIcon, Clock, Camera, CheckCircle, AlertCircle, PlayCircle, Lock, Wifi, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getEffectiveRole } from '../lib/auth';
import { db } from '../firebase';
import { doc, getDoc } from 'firebase/firestore';
import { QRCodeSVG } from 'qrcode.react';

interface ProfileProps {
  currentUser: Staff;
  staff: Staff[];
  orders: Order[];
  tickets: Ticket[];
  onNavigate: (view: any, params?: any) => void;
  updateProfile: (id: string, updates: Partial<Staff>) => Promise<void>;
  viewUserId?: string;
}

export default function Profile({ currentUser, staff, orders, tickets, onNavigate, updateProfile, viewUserId }: ProfileProps) {
  const targetUser = viewUserId ? staff.find(s => s.id === viewUserId) || currentUser : currentUser;
  const isOwnProfile = targetUser.id === currentUser.id;
  const role = getEffectiveRole(targetUser);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [wifiInfo, setWifiInfo] = useState<{ ssid: string, pass: string } | null>(null);

  const [showChangePasswordModal, setShowChangePasswordModal] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');

  const handleSavePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    const actualOldPassword = targetUser.password || '1234';
    if (currentPassword !== actualOldPassword) {
      setPasswordError('Неверный текущий пароль');
      return;
    }

    if (newPassword.length < 4) {
      setPasswordError('Новый пароль должен быть не менее 4 символов');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError('Пароли не совпадают');
      return;
    }

    setIsChangingPassword(true);
    try {
      await updateProfile(targetUser.id, { password: newPassword });
      setPasswordSuccess('Пароль успешно изменен');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => {
        setShowChangePasswordModal(false);
        setPasswordSuccess('');
      }, 1500);
    } catch (err: any) {
      setPasswordError(err?.message || 'Ошибка смены пароля');
    } finally {
      setIsChangingPassword(false);
    }
  };

  useEffect(() => {
    const fetchWifi = async () => {
      const snap = await getDoc(doc(db, 'settings', 'wifi'));
      if (snap.exists()) {
        const data = snap.data();
        const isStaff = targetUser.role !== 'user';
        setWifiInfo({
          ssid: isStaff ? data.staffSsid : data.customerSsid,
          pass: isStaff ? data.staffPassword : data.customerPassword
        });
      }
    };
    fetchWifi();
  }, [targetUser.role]);
  
  const myTickets = tickets.filter(t => t.creatorId === targetUser.id || t.assignedToId === targetUser.id);
  const myRecentActivity = orders.filter(o => o.status === 'completed').slice(0, 5);

  const getStatusInfo = (status: Ticket['status']) => {
    switch (status) {
      case 'new': return { label: 'Новый', color: 'bg-indigo-100 text-indigo-700', icon: AlertCircle };
      case 'investigating': return { label: 'В работе', color: 'bg-amber-100 text-amber-700', icon: PlayCircle };
      case 'commented': return { label: 'Ответ', color: 'bg-purple-100 text-purple-700', icon: Clock };
      case 'resolved': return { label: 'Решён', color: 'bg-emerald-100 text-emerald-700', icon: CheckCircle };
      case 'closed': return { label: 'Закрыт', color: 'bg-slate-100 text-slate-700', icon: Lock };
      default: return { label: status, color: 'bg-slate-100 text-slate-700', icon: AlertCircle };
    }
  };

  const handleAvatarClick = () => {
    if (isOwnProfile) fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isOwnProfile) return;
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        await updateProfile(targetUser.id, { avatarUrl: base64String });
      };
      reader.readAsDataURL(file);
    }
  };

  const canSeeCRM = ['owner', 'admin', 'tech', 'tester', 'developer'].includes(role);
  const canSeeStats = ['owner', 'admin', 'tech', 'developer', 'tester'].includes(role);

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-500 max-w-6xl mx-auto pb-24 text-slate-900 dark:text-slate-100 p-4 sm:p-0">
      {!isOwnProfile && (
        <div className="flex items-center gap-4 mb-4 sm:mb-0">
          <Button variant="ghost" size="sm" onClick={() => onNavigate('staff-chat', { chatId: targetUser.id })} className="rounded-xl px-4 py-2 h-auto text-xs uppercase font-black tracking-widest">
             <LayoutDashboard size={14} className="mr-2" /> В чат
          </Button>
          <h2 className="text-lg sm:text-xl font-black uppercase tracking-tight">Профиль коллеги</h2>
        </div>
      )}
      <div className="flex flex-col lg:flex-row gap-6 sm:gap-8">
        
        {/* Left Side: Photo and Main Info */}
        <div className="w-full lg:w-80 xl:w-96 space-y-6">
          <Card className="p-6 sm:p-8 text-center relative overflow-hidden shadow-2xl border-none bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl">
            <div className="absolute top-0 left-0 w-full h-32 bg-indigo-600/10 dark:bg-indigo-500/20" />
            <div className="relative pt-4 sm:pt-6">
              <div 
                className={cn(
                  "group relative w-24 h-24 sm:w-32 sm:h-32 mx-auto mb-4 sm:mb-6",
                  isOwnProfile && "cursor-pointer"
                )}
                onClick={handleAvatarClick}
              >
                <div className="w-full h-full rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-black text-3xl sm:text-4xl shadow-2xl border-4 border-white dark:border-slate-800 overflow-hidden">
                  {targetUser?.avatarUrl ? (
                    <img src={targetUser.avatarUrl} alt={targetUser?.name || 'Пользователь'} className="w-full h-full object-cover" />
                  ) : (
                    (targetUser?.name || 'Пользователь').split(' ').filter(Boolean).map(n => n[0]).join('').toUpperCase()
                  )}
                </div>
                {isOwnProfile && (
                  <div className="absolute inset-0 bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Camera className="text-white" size={20} />
                  </div>
                )}
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={handleFileChange}
                />
              </div>
              
              <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight leading-none mb-2">{targetUser.name}</h2>
              <p className="text-[10px] sm:text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.2em]">{targetUser.position}</p>
              {targetUser.isOnline && (
                <div className="flex items-center justify-center gap-2 mt-2">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                  <span className="text-[9px] font-black uppercase tracking-widest text-emerald-500">В сети</span>
                </div>
              )}
            </div>

            <div className="mt-6 space-y-3 sm:space-y-4 text-left p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-4 text-sm">
                <div className="w-8 h-8 rounded-lg bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center shrink-0">
                  <Shield size={14} className="text-indigo-600" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[9px] text-slate-400 uppercase font-black tracking-widest">Роль</span>
                  <b className="uppercase truncate block">{role === 'tech' ? 'Техподдержка' : role}</b>
                </div>
              </div>
              
              <div className="flex items-center gap-4 text-sm mt-3">
                <div className="w-8 h-8 rounded-lg bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center shrink-0">
                  <Key size={14} className="text-indigo-600" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[9px] text-slate-400 uppercase font-black tracking-widest">Логин</span>
                  <b className="truncate block leading-none pt-1">{targetUser.login}</b>
                </div>
              </div>

              <div className="flex items-center gap-4 text-sm mt-3">
                <div className="w-8 h-8 rounded-lg bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center shrink-0">
                  <Phone size={14} className="text-indigo-600" />
                </div>
                <div className="min-w-0">
                  <span className="block text-[9px] text-slate-400 uppercase font-black tracking-widest">Телефон</span>
                  <b className="truncate block leading-none pt-1">{targetUser.phone}</b>
                </div>
              </div>
            </div>

            {isOwnProfile && (
              <Button 
                onClick={() => setShowChangePasswordModal(true)} 
                variant="secondary" 
                className="w-full mt-6 sm:mt-8 rounded-xl h-11 sm:h-12 text-[10px] font-black uppercase tracking-widest" 
                size="sm"
              >
                <Key size={12} className="mr-2" /> Сменить пароль
              </Button>
            )}
          </Card>

          {canSeeCRM && (
            <Card className="p-6 bg-indigo-600 text-white border-none shadow-xl overflow-hidden relative">
              <div className="absolute -right-4 -bottom-4 opacity-10 rotate-12">
                <LayoutDashboard size={120} />
              </div>
              <h3 className="text-[10px] font-black uppercase tracking-widest mb-6 opacity-60">Статистика CRM</h3>
              <div className="space-y-4 relative z-10">
                <button 
                  onClick={() => onNavigate('tickets')}
                  className="w-full flex justify-between items-center bg-white/10 hover:bg-white/20 p-3 rounded-xl transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <TicketIcon size={16} />
                    <span className="text-sm font-bold">Ваши тикеты</span>
                  </div>
                  <span className="text-sm font-black bg-white text-indigo-600 px-3 py-0.5 rounded-lg shadow-sm group-hover:scale-110 transition-transform">{myTickets.length}</span>
                </button>
                
                <div className="w-full flex justify-between items-center bg-white/10 p-3 rounded-xl">
                  <div className="flex items-center gap-3">
                    <CheckCircle size={16} />
                    <span className="text-sm font-bold">Выполнено</span>
                  </div>
                  <span className="text-sm font-black bg-white/20 px-3 py-0.5 rounded-lg">
                    {myTickets.filter(t => t.status === 'resolved' || t.status === 'closed').length}
                  </span>
                </div>
              </div>
            </Card>
          )}

          {wifiInfo && (
            <Card className="p-5 sm:p-6 bg-slate-900 dark:bg-indigo-900 border-none text-white overflow-hidden relative shadow-2xl">
                <div className="absolute -right-4 -top-4 opacity-10">
                    <Wifi size={100} className="sm:w-[120px] sm:h-[120px]" />
                </div>
                <div className="relative z-10 flex flex-col gap-5 sm:gap-6">
                    <div className="flex justify-between items-start gap-4">
                        <div className="min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                                <Wifi size={12} className="text-indigo-400" />
                                <span className="text-[9px] font-black uppercase tracking-[0.2em] text-indigo-400">WiFi доступ</span>
                            </div>
                            <h4 className="text-lg sm:text-xl font-black truncate">{wifiInfo.ssid}</h4>
                        </div>
                        <div className="bg-white p-2 rounded-xl shadow-2xl shrink-0">
                           <QRCodeSVG 
                             value={`WIFI:S:${wifiInfo.ssid};T:${wifiInfo.pass ? 'WPA' : ''};P:${wifiInfo.pass || ''};;`} 
                             size={60}
                             level="H"
                             className="sm:w-[80px] sm:h-[80px]"
                           />
                        </div>
                    </div>
                    <div className="p-3 sm:p-4 bg-white/5 rounded-2xl border border-white/10">
                        <div className="flex flex-col gap-1">
                            <span className="text-[8px] font-black uppercase text-white/40 tracking-widest">Пароль от сети</span>
                            <div className="flex items-center gap-2 min-w-0">
                                <Lock size={12} className="text-indigo-400 shrink-0" />
                                <span className="font-mono text-base sm:text-lg font-bold tracking-widest leading-none pt-1 truncate">{wifiInfo.pass || 'ОТКРЫТАЯ СЕТЬ'}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </Card>
          )}
        </div>

        {/* Right Side: CRM and Activity */}
        <div className="flex-1 space-y-6 sm:space-y-8">
          {canSeeCRM && (
            <div>
              <div className="flex items-center justify-between mb-4 sm:mb-6">
                <h3 className="text-lg sm:text-xl font-black uppercase tracking-tight flex items-center gap-3">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl flex items-center justify-center text-indigo-600 animate-pulse">
                    <TicketIcon size={18} sm:size={20} />
                  </div>
                  Задачи (CRM)
                </h3>
                <Button size="sm" variant="ghost" onClick={() => onNavigate('tickets')} className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest">
                  Все тикеты
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {myTickets.length > 0 ? myTickets.filter(t => t.status !== 'closed').slice(0, 4).map(ticket => {
                  const statusInfo = getStatusInfo(ticket.status);
                  return (
                    <Card 
                      key={ticket.id} 
                      className="p-5 hover:shadow-2xl hover:-translate-y-1 cursor-pointer border-none bg-white dark:bg-slate-900 group transition-all duration-300 shadow-lg" 
                      onClick={() => onNavigate('tickets', { ticketId: ticket.id })}
                    >
                      <div className="flex justify-between items-start mb-3">
                        <span className="text-[9px] font-mono font-bold text-slate-300 group-hover:text-indigo-400 transition-colors">#{ticket.ticketNumber}</span>
                        <div className={cn("flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider", statusInfo.color)}>
                          <statusInfo.icon size={8} />
                          {statusInfo.label}
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-bold line-clamp-1 group-hover:text-indigo-600 transition-colors text-sm sm:text-base leading-tight">
                            {ticket.title}
                          </h4>
                        </div>
                        
                        <div>
                          <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 italic leading-relaxed">
                            {ticket.description}
                          </p>
                        </div>
                      </div>
                      
                      <div className="mt-4 pt-3 border-t border-slate-50 dark:border-slate-800 flex items-center justify-between overflow-hidden">
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 rounded-full bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center text-[7px] font-bold text-indigo-600">
                            {(ticket.creatorName || 'С').split(' ')[0][0]}
                          </div>
                          <span className="text-[9px] text-slate-400 truncate max-w-[80px]">от {(ticket.creatorName || 'Система').split(' ')[0]}</span>
                        </div>
                        <div className="flex items-center gap-1 text-[9px] text-slate-300 shrink-0">
                          <Clock size={8} />
                          <span>{new Date(ticket.updatedAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </Card>
                  );
                }) : (
                  <Card className="col-span-full p-8 sm:p-12 text-center border-2 border-dashed border-slate-100 dark:border-slate-800 bg-transparent">
                    <TicketIcon size={40} className="mx-auto mb-3 text-slate-200" />
                    <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Нет активных задач</p>
                  </Card>
                )}
              </div>
            </div>
          )}

          {canSeeStats && (
            <div>
               <h3 className="text-lg sm:text-xl font-black uppercase tracking-tight flex items-center gap-3 mb-4 sm:mb-6">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl flex items-center justify-center text-indigo-600">
                    <Clock size={18} sm:size={20} />
                  </div>
                  История событий
                </h3>
              <Card className="overflow-hidden shadow-xl border-none bg-white dark:bg-slate-900">
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {myRecentActivity.length > 0 ? myRecentActivity.map(order => (
                    <div key={order.id} className="p-3 sm:p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors gap-4">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400 rounded-2xl flex items-center justify-center font-black text-[9px] uppercase shadow-sm shrink-0">
                          ЧЕК
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs sm:text-sm font-bold truncate">Заказ №{order.orderNumber}</p>
                          <p className="text-[9px] sm:text-[10px] text-slate-500 font-medium">{new Date(order.timestamp).toLocaleString()}</p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-sm sm:text-base font-black whitespace-nowrap">{order.total} ₽</span>
                        <p className="text-[7px] sm:text-[8px] font-black uppercase text-emerald-500 tracking-widest text-right">Успешно</p>
                      </div>
                    </div>
                  )) : (
                    <div className="p-8 sm:p-12 text-center text-slate-300">
                      <Clock size={24} className="mx-auto mb-2 opacity-20" />
                      <p className="text-[10px] font-black uppercase tracking-widest">Действий нет</p>
                    </div>
                  )}
                </div>
                {myRecentActivity.length > 0 && (
                  <button 
                    onClick={() => onNavigate('orders')} 
                    className="w-full py-4 bg-slate-50 dark:bg-slate-800 font-black text-[9px] sm:text-[10px] text-indigo-600 uppercase tracking-[0.2em] hover:text-indigo-700 transition-colors border-t border-slate-100 dark:border-slate-700"
                  >
                    Все транзакции
                  </button>
                )}
              </Card>
            </div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {showChangePasswordModal && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-300">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0"
              onClick={() => {
                if (!isChangingPassword) {
                  setShowChangePasswordModal(false);
                  setPasswordError('');
                  setPasswordSuccess('');
                }
              }}
            />
            
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 dark:border-slate-800/80 z-10 flex flex-col gap-4 select-none"
            >
              <button 
                disabled={isChangingPassword}
                onClick={() => {
                  setShowChangePasswordModal(false);
                  setPasswordError('');
                  setPasswordSuccess('');
                }}
                className="absolute top-4 right-4 bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-2 rounded-full transition-all disabled:opacity-50"
              >
                <X size={18} />
              </button>

              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-indigo-50 dark:bg-indigo-900/30 rounded-2xl flex items-center justify-center text-indigo-600 shrink-0">
                  <Lock size={20} />
                </div>
                <div>
                  <h3 className="text-lg sm:text-xl font-black uppercase tracking-tight">Смена пароля</h3>
                  <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest mt-0.5">Обновите ваши учетные данные</p>
                </div>
              </div>

              <form onSubmit={handleSavePassword} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block">Текущий пароль</label>
                  <Input 
                    type="password"
                    placeholder="Введите текущий пароль"
                    value={currentPassword}
                    onChange={e => setCurrentPassword(e.target.value)}
                    required
                    disabled={isChangingPassword}
                    className="h-11 sm:h-12"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block">Новый пароль</label>
                  <Input 
                    type="password"
                    placeholder="Не менее 4 символов"
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    required
                    disabled={isChangingPassword}
                    className="h-11 sm:h-12"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-black uppercase tracking-widest text-slate-400 block">Подтверждение пароля</label>
                  <Input 
                    type="password"
                    placeholder="Повторите новый пароль"
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    required
                    disabled={isChangingPassword}
                    className="h-11 sm:h-12"
                  />
                </div>

                {passwordError && (
                  <div className="text-xs font-bold text-red-500 bg-red-50 dark:bg-red-950/20 p-3 rounded-xl border border-red-100 dark:border-red-900/50 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-red-500 rounded-full shrink-0" />
                    <span>{passwordError}</span>
                  </div>
                )}

                {passwordSuccess && (
                  <div className="text-xs font-bold text-emerald-500 bg-emerald-50 dark:bg-emerald-950/20 p-3 rounded-xl border border-emerald-100 dark:border-emerald-900/50 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full shrink-0 animate-pulse animate-duration-1000" />
                    <span>{passwordSuccess}</span>
                  </div>
                )}

                <div className="flex gap-3 pt-2">
                  <Button 
                    type="button" 
                    variant="ghost" 
                    disabled={isChangingPassword}
                    onClick={() => {
                      setShowChangePasswordModal(false);
                      setPasswordError('');
                      setPasswordSuccess('');
                    }}
                    className="flex-1 rounded-2xl h-11 sm:h-12 font-black text-xs uppercase tracking-widest"
                  >
                    Отмена
                  </Button>
                  <Button 
                    type="submit" 
                    variant="primary" 
                    disabled={isChangingPassword}
                    className="flex-2 w-full max-w-[60%] rounded-2xl h-11 sm:h-12 font-black text-xs uppercase tracking-widest bg-indigo-600 font-bold"
                  >
                    {isChangingPassword ? 'Сохранение...' : 'Сохранить'}
                  </Button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
