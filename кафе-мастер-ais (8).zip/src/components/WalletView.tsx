import React, { useState, useEffect } from 'react';
import { 
  Wallet as WalletIcon, 
  Plus, 
  History, 
  CreditCard, 
  Gift, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Filter, 
  Search, 
  Shield,
  ChevronRight,
  QrCode,
  Eye,
  EyeOff,
  Edit3,
  AlertCircle,
  CheckCircle2,
  Clock,
  XCircle,
  Settings as SettingsIcon,
  ToggleLeft,
  ToggleRight,
  Lock,
  BellRing,
  Smartphone,
  ShieldCheck,
  CreditCard as CardIcon,
  Fingerprint,
  Users,
  List
} from 'lucide-react';
import { Wallet, WalletTransaction, Staff, TransactionType, TransactionStatus } from '../types';
import { formatRUB, TRANSACTION_TYPE_LABELS, TRANSACTION_STATUS_LABELS } from '../lib/walletUtils';
import { cn } from './UI';
import { db } from '../firebase';
import { collection, query, where, orderBy, onSnapshot, addDoc, doc, updateDoc, getDoc, runTransaction, setDoc, limit } from 'firebase/firestore';
import { useCafeStore, handleFirestoreErrorGlobal, OperationType } from '../store';
import { motion, AnimatePresence } from 'motion/react';

interface WalletViewProps {
  currentUser: Staff;
}

export default function WalletView({ currentUser }: WalletViewProps) {
  const { authInitialized } = useCafeStore();

  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCardNumber, setShowCardNumber] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'deposits' | 'spendings' | 'bonuses' | 'orders' | 'admin'>('all');
  const [isTopUpOpen, setIsTopUpOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState('');
  const [isQrZoomed, setIsQrZoomed] = useState(false);
  
  // Admin Management State
  const [searchStaffQuery, setSearchStaffQuery] = useState('');
  const [staffList, setStaffList] = useState<Staff[]>([]);
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  const [selectedStaffWallet, setSelectedStaffWallet] = useState<Wallet | null>(null);
  const [adminActionAmount, setAdminActionAmount] = useState('');
  const [adminActionBonus, setAdminActionBonus] = useState('');
  const [adminActionReason, setAdminActionReason] = useState('');
  const [isAdminActionProcessing, setIsAdminActionProcessing] = useState(false);

  const isAdmin = ['owner', 'admin', 'tech', 'developer'].includes(currentUser.role);
  const [filterDate, setFilterDate] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [orders, setOrders] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [isAdminLogsOpen, setIsAdminLogsOpen] = useState(false);

  const [isEditingName, setIsEditingName] = useState(false);
  const [newHolderName, setNewHolderName] = useState('');

  // PIN setup state
  const [isPinSetupOpen, setIsPinSetupOpen] = useState(false);
  const [pinDraft, setPinDraft] = useState('');
  const [tempPin, setTempPin] = useState('');

  // Settings State (local draft for the form)
  const [settings, setSettings] = useState({
    twoFactorEnabled: true,
    pinEnabled: false,
    dailyLimit: 10000,
    notificationsEnabled: true,
    pinCode: ''
  });

  const resetDraftSettings = () => {
    if (wallet) {
      setSettings({
        twoFactorEnabled: wallet.settings?.twoFactorEnabled ?? true,
        pinEnabled: wallet.settings?.pinEnabled ?? false,
        dailyLimit: wallet.settings?.dailyLimit ?? 10000,
        notificationsEnabled: wallet.settings?.notificationsEnabled ?? true,
        pinCode: wallet.settings?.pinCode ?? ''
      });
    }
  };

  useEffect(() => {
    resetDraftSettings();
  }, [wallet]);

  const updateDraftSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleSaveSettings = async () => {
    if (!wallet) return;
    try {
      const walletRef = doc(db, 'wallets', currentUser.id);
      await updateDoc(walletRef, {
        settings: settings,
        lastUpdate: Date.now()
      });
      setIsSettingsOpen(false);
    } catch (err) {
      handleFirestoreErrorGlobal(err, OperationType.WRITE, `wallets/${currentUser.id}`);
      alert('Ошибка при сохранении настроек');
    }
  };

  useEffect(() => {
    if (wallet?.virtualCard?.holderName) {
      setNewHolderName(wallet.virtualCard.holderName);
    } else {
      setNewHolderName(currentUser.name || '');
    }
  }, [wallet, currentUser.name]);

  const saveHolderName = async () => {
    if (!wallet) return;
    try {
      const walletRef = doc(db, 'wallets', currentUser.id);
      await updateDoc(walletRef, {
        'virtualCard.holderName': newHolderName || currentUser.name || 'Staff',
        lastUpdate: Date.now()
      });
      setIsEditingName(false);
    } catch (err) {
      handleFirestoreErrorGlobal(err, OperationType.WRITE, `wallets/${currentUser.id}`);
    }
  };

  const handleExportCSV = () => {
    if (!transactions || transactions.length === 0) {
      alert("Нет транзакций для экспорта");
      return;
    }

    const sorted = [...transactions].sort((a, b) => b.timestamp - a.timestamp);

    const headers = [
      "ID Транзакции",
      "Дата и Время",
      "Тип Операции",
      "Сумма (₽)",
      "Бонусы",
      "Статус",
      "Описание"
    ];

    const rows = sorted.map(tx => {
      const date = new Date(tx.timestamp).toLocaleString('ru-RU');
      const typeLabel = TRANSACTION_TYPE_LABELS[tx.type] || tx.type;
      const amountRUB = (tx.amount / 100).toFixed(2);
      const bonusStr = tx.bonusAmount !== undefined ? tx.bonusAmount.toString() : "-";
      const statusLabel = TRANSACTION_STATUS_LABELS[tx.status] || tx.status;
      const description = (tx.description || "").replace(/"/g, '""');

      return [
        tx.id,
        date,
        typeLabel,
        amountRUB,
        bonusStr,
        statusLabel,
        `"${description}"`
      ];
    });

    const csvContent = "\uFEFF" + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `wallet_transactions_${currentUser.id}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const generate16DigitCard = () => {
    return Array.from({ length: 4 }, () => 
      Math.floor(Math.random() * 9000 + 1000).toString()
    ).join(' ');
  };

  const renderVirtualCard = () => {
    return (
      <motion.div 
        whileHover={{ scale: 1.01 }}
        className="bg-slate-900 rounded-3xl p-4 xs:p-5 sm:p-6 text-white aspect-[1.586/1] w-full flex flex-col justify-between shadow-2xl shadow-indigo-505/25 relative overflow-hidden group shrink-0 select-none border border-slate-800"
      >
        <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-br from-indigo-500/15 via-transparent to-purple-500/15 pointer-events-none" />
        <div className="absolute -right-16 -bottom-16 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -top-16 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        
        {/* Card Header */}
        <div className="relative z-10 flex justify-between items-start">
          <div className="space-y-1">
            <p className="text-[7px] xs:text-[9px] sm:text-[10px] uppercase tracking-[0.2em] font-black text-indigo-400 opacity-90">Виртуальная Карта</p>
            <div className="h-5 w-7 xs:h-6 xs:w-8 sm:h-8 sm:w-11 bg-gradient-to-br from-amber-350 via-amber-400 to-amber-600 rounded border border-amber-500/30 flex flex-col justify-between p-0.5 xs:p-1 shadow-inner relative overflow-hidden">
               <div className="absolute inset-0 bg-black/5 flex items-center justify-center pointer-events-none">
                 <div className="w-full h-[1px] bg-amber-250/40" />
                 <div className="h-full w-[1px] bg-amber-250/40" />
               </div>
            </div>
          </div>
          <p className="text-base xs:text-lg sm:text-2xl font-black italic tracking-tighter bg-gradient-to-r from-indigo-200 to-white bg-clip-text text-transparent">Уют</p>
        </div>

        {/* Card Details */}
        <div className="relative z-10 space-y-2 sm:space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 xs:gap-3">
              <p className="text-[11px] xs:text-xs sm:text-lg font-mono tracking-[0.10em] xs:tracking-[0.15em] sm:tracking-[0.2em] font-medium leading-none">
                {showCardNumber ? (wallet?.virtualCard.token || '4000 1234 5678 9010') : '•••• •••• •••• ' + (wallet?.virtualCard.token || '9010').split(' ').pop()}
              </p>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setShowCardNumber(!showCardNumber);
                }}
                className="text-slate-400 hover:text-white transition-colors p-0.5 xs:p-1"
                type="button"
              >
                {showCardNumber ? <EyeOff className="w-3.5 h-3.5 xs:w-4 xs:h-4" /> : <Eye className="w-3.5 h-3.5 xs:w-4 xs:h-4" />}
              </button>
            </div>
          </div>
          <div className="flex justify-between items-end">
            <div className="space-y-1.5 sm:space-y-2 flex-1 mr-4 min-w-0">
              <div className="space-y-0.5">
                <p className="text-[6px] xs:text-[7px] sm:text-[8px] uppercase tracking-widest text-slate-500 font-bold">Срок</p>
                <p className="text-[8px] xs:text-[10px] sm:text-xs font-bold font-mono tracking-wider text-slate-200">05 / 31</p>
              </div>
              <div className="space-y-0.5 relative group/name">
                <p className="text-[6px] xs:text-[7px] sm:text-[8px] uppercase tracking-widest text-slate-500 font-bold">Владелец</p>
                {isEditingName ? (
                  <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                    <input 
                      type="text"
                      autoFocus
                      value={newHolderName}
                      onChange={(e) => setNewHolderName(e.target.value)}
                      onBlur={saveHolderName}
                      onKeyDown={(e) => e.key === 'Enter' && saveHolderName()}
                      className="bg-white/10 border-b border-white/30 text-[8px] xs:text-[10px] sm:text-xs font-bold uppercase tracking-wide outline-none w-full py-0.5 text-white"
                    />
                  </div>
                ) : (
                  <div 
                    className="flex items-center gap-2 cursor-pointer" 
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsEditingName(true);
                    }}
                  >
                    <p className="text-[8px] xs:text-[10px] sm:text-xs font-bold uppercase tracking-wide truncate max-w-[100px] xs:max-w-[120px] sm:max-w-[150px] text-slate-200">
                      {wallet?.virtualCard.holderName || currentUser.name}
                    </p>
                    <Edit3 className="w-2 h-2 xs:w-2.5 xs:h-2.5 sm:w-3 sm:h-3 text-slate-500 opacity-100 md:opacity-0 md:group-hover/name:opacity-100 transition-opacity" />
                  </div>
                )}
              </div>
            </div>
            
            <button 
              onClick={(e) => {
                e.stopPropagation();
                setIsQrZoomed(true);
              }}
              title="Нажмите для увеличения на кассе"
              className="bg-white p-1 xs:p-1.5 rounded-lg w-8 h-8 xs:w-10 xs:h-10 sm:w-14 sm:h-14 flex items-center justify-center shrink-0 hover:scale-105 active:scale-95 transition-transform shadow-lg cursor-pointer border border-slate-200"
              type="button"
            >
              <QrCode className="w-5 h-5 xs:w-7 xs:h-7 sm:w-11 sm:h-11 text-slate-900" />
            </button>
          </div>
        </div>
      </motion.div>
    );
  };

  useEffect(() => {
    if (!currentUser.id || !authInitialized) return;

    // Listen to wallet data
    const walletRef = doc(db, 'wallets', currentUser.id);
    const unsubscribeWallet = onSnapshot(walletRef, (docSnap) => {
      if (docSnap.exists()) {
        setWallet(docSnap.data() as Wallet);
      } else {
        // Initialize wallet
        const initialWallet: Wallet = {
          id: currentUser.id,
          balance: 0,
          bonusBalance: 0,
          virtualCard: {
            id: `UYUT-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
            token: generate16DigitCard(),
            isActive: true,
            holderName: currentUser.name || 'Staff'
          },
          lastUpdate: Date.now()
        };
        // Use setDoc for first time creation to ensure it exists
        setDoc(walletRef, initialWallet).catch(err => handleFirestoreErrorGlobal(err, OperationType.WRITE, `wallets/${currentUser.id}`));
      }
      setLoading(false);
    }, (err) => {
      handleFirestoreErrorGlobal(err, OperationType.GET, `wallets/${currentUser.id}`);
      setLoading(false);
    });

    // Listen to transactions
    const qTx = query(
      collection(db, 'walletTransactions'),
      where('userId', '==', currentUser.id),
      orderBy('timestamp', 'desc')
    );
    const unsubscribeTx = onSnapshot(qTx, (snap) => {
      setTransactions(snap.docs.map(d => ({ id: d.id, ...d.data() } as WalletTransaction)));
    }, (err) => {
      handleFirestoreErrorGlobal(err, OperationType.LIST, 'walletTransactions');
    });

    // Listen to orders
    const qOrders = query(
      collection(db, 'orders'),
      where('userId', '==', currentUser.id),
      orderBy('timestamp', 'desc')
    );
    const unsubscribeOrders = onSnapshot(qOrders, (snap) => {
      const allOrders = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setOrders(allOrders);
    }, (err) => {
      handleFirestoreErrorGlobal(err, OperationType.LIST, 'orders');
    });

    return () => {
      unsubscribeWallet();
      unsubscribeTx();
      unsubscribeOrders();
    };
  }, [currentUser.id, authInitialized]);

  // Admin: Load staff members
  useEffect(() => {
    if (!isAdmin) return;
    const q = query(collection(db, 'staff'), orderBy('name', 'asc'));
    const unsubscribe = onSnapshot(q, (snap) => {
      setStaffList(snap.docs.map(d => ({ id: d.id, ...d.data() } as Staff)));
    });
    return () => unsubscribe();
  }, [isAdmin]);

  // Admin: Load selected staff wallet
  useEffect(() => {
    if (!selectedStaff) {
      setSelectedStaffWallet(null);
      return;
    }
    const walletRef = doc(db, 'wallets', selectedStaff.id);
    const unsubscribe = onSnapshot(walletRef, (snap) => {
      if (snap.exists()) {
        setSelectedStaffWallet(snap.data() as Wallet);
      } else {
        setSelectedStaffWallet(null);
      }
    });
    return () => unsubscribe();
  }, [selectedStaff]);

  // Admin Dashboard: Load all admin actions and transactions
  useEffect(() => {
    if (!isAdmin) return;
    
    // Listen to explicit audit logs
    const qLogs = query(collection(db, 'system_logs'), orderBy('timestamp', 'desc'), limit(100));
    const unsubLogs = onSnapshot(qLogs, (snap) => {
      const systemLogs = snap.docs.map(d => {
        const data = d.data();
        return { 
          id: d.id, 
          ...data, 
          source: 'system',
          // Ensure timestamp is a number for sorting
          timestamp: data.timestamp?.toMillis?.() || data.timestamp || Date.now()
        };
      });
      setLogs(prev => {
        const otherSource = prev.filter((l: any) => l.source !== 'system');
        const combined = [...systemLogs, ...otherSource].sort((a: any, b: any) => (Number(b.timestamp) || 0) - (Number(a.timestamp) || 0));
        return combined.slice(0, 100);
      });
    }, (err) => console.error('System logs error:', err));

    // Also listen to transactions that have admin metadata to show past actions
    const qAdminTx = query(collection(db, 'walletTransactions'), orderBy('timestamp', 'desc'), limit(100));
    const unsubTx = onSnapshot(qAdminTx, (snap) => {
      const adminTx = snap.docs
        .map(d => {
          const tx = d.data() as any;
          return { id: d.id, ...tx };
        })
        .filter((tx: any) => tx.metadata?.adminId)
        .map((tx: any) => ({
          id: tx.id,
          source: 'transaction',
          type: 'admin_adjustment',
          adminId: tx.metadata.adminId,
          adminName: tx.metadata.adminName,
          adminRole: 'Admin',
          targetStaffId: tx.userId,
          targetStaffName: tx.userId ? `Пользователь ID: ${tx.userId.substring(0, 5)}...` : 'Неизвестный',
          adjustmentType: tx.type?.includes('bonus') ? 'bonus' : 'money',
          amount: tx.type?.includes('bonus') ? (tx.bonusAmount || 0) : ((tx.amount || 0) / 100),
          reason: tx.description || '',
          timestamp: tx.timestamp?.toMillis?.() || tx.timestamp || Date.now(),
          severity: 'info'
        }));

      setLogs(prev => {
        const otherSource = prev.filter((l: any) => l.source !== 'transaction');
        const combined = [...adminTx, ...otherSource].sort((a: any, b: any) => (Number(b.timestamp) || 0) - (Number(a.timestamp) || 0));
        return combined.slice(0, 100);
      });
    }, (err) => console.error('Admin transactions error:', err));

    return () => {
      unsubLogs();
      unsubTx();
    };
  }, [isAdmin]);

  const handleAdminAdjustment = async (type: 'money' | 'bonus') => {
    if (!selectedStaff || !adminActionReason.trim()) return;
    const amountVal = parseFloat(adminActionAmount || '0') * 100;
    const bonusVal = parseInt(adminActionBonus || '0');
    
    if (type === 'money' && amountVal === 0) return;
    if (type === 'bonus' && bonusVal === 0) return;

    setIsAdminActionProcessing(true);
    try {
      await runTransaction(db, async (txn) => {
        const walletRef = doc(db, 'wallets', selectedStaff.id);
        const walletSnap = await txn.get(walletRef);
        
        let currentBalance = 0;
        let currentBonus = 0;
        
        if (walletSnap.exists()) {
          const data = walletSnap.data() as Wallet;
          currentBalance = data.balance;
          currentBonus = data.bonusBalance;
        }

        const newBalance = currentBalance + (type === 'money' ? amountVal : 0);
        const newBonus = currentBonus + (type === 'bonus' ? bonusVal : 0);

        if (!walletSnap.exists()) {
          txn.set(walletRef, {
            id: selectedStaff.id,
            balance: newBalance,
            bonusBalance: newBonus,
            virtualCard: {
              id: `UYUT-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
              token: generate16DigitCard(),
              isActive: true,
              holderName: selectedStaff.name || 'Staff'
            },
            lastUpdate: Date.now()
          });
        } else {
          txn.update(walletRef, {
            balance: newBalance,
            bonusBalance: newBonus,
            lastUpdate: Date.now()
          });
        }

        const txRef = doc(collection(db, 'walletTransactions'));
        txn.set(txRef, {
          userId: selectedStaff.id,
          type: type === 'money' ? (amountVal > 0 ? 'deposit' : 'payment') : (bonusVal > 0 ? 'bonus_earn' : 'bonus_redeem'),
          amount: type === 'money' ? amountVal : 0,
          bonusAmount: type === 'bonus' ? bonusVal : 0,
          status: 'success',
          description: `Админ-корректировка: ${adminActionReason} (${currentUser.name})`,
          timestamp: Date.now(),
          idempotencyKey: `admin_${Date.now()}`,
          metadata: { adminId: currentUser.id, adminName: currentUser.name }
        });

        const logRef = doc(collection(db, 'system_logs'));
        txn.set(logRef, {
          type: 'admin_adjustment',
          adminId: currentUser.id,
          adminName: currentUser.name,
          adminRole: currentUser.role,
          targetStaffId: selectedStaff.id,
          targetStaffName: selectedStaff.name,
          adjustmentType: type,
          amount: type === 'money' ? amountVal : bonusVal,
          reason: adminActionReason,
          timestamp: Date.now(),
          severity: 'info'
        });
      });

      setAdminActionReason('');
      setAdminActionAmount('');
      setAdminActionBonus('');
      alert('Баланс успешно обновлен');
    } catch (err) {
      handleFirestoreErrorGlobal(err, OperationType.WRITE, 'admin-adjustment');
      alert('Ошибка при выполнении операции');
    } finally {
      setIsAdminActionProcessing(false);
    }
  };

  const handleRefund = async (order: any) => {
    if (order.status === 'cancelled') return;
    const canCancel = Date.now() - order.timestamp < 15 * 60 * 1000;
    if (!canCancel && order.status !== 'completed') {
       alert('Время для отмены заказа вышло.');
       return;
    }
    try {
      await runTransaction(db, async (txn) => {
        const orderRef = doc(db, 'orders', order.id);
        const walletRef = doc(db, 'wallets', currentUser.id);
        const walletSnap = await txn.get(walletRef);
        if (!walletSnap.exists()) return;
        const walletData = walletSnap.data() as Wallet;
        const moneyToRefund = (order.total || 0) * 100;
        const bonusesToRefund = (order.appliedBonuses || 0);
        const pointsEarnedOnThisOrder = Math.floor((moneyToRefund / 100) * 0.05);

        txn.update(orderRef, { status: 'cancelled', updatedAt: Date.now() });
        txn.update(walletRef, {
          balance: walletData.balance + moneyToRefund,
          bonusBalance: Math.max(0, walletData.bonusBalance + bonusesToRefund - pointsEarnedOnThisOrder),
          lastUpdate: Date.now()
        });

        const refundTxRef = doc(collection(db, 'walletTransactions'));
        txn.set(refundTxRef, {
          userId: currentUser.id,
          type: 'refund',
          amount: moneyToRefund,
          status: 'success',
          description: `Возврат за заказ #${order.orderNumber}`,
          orderId: order.id,
          timestamp: Date.now(),
          idempotencyKey: `refund_${order.id}`
        });
      });
      alert('Заказ отменен, средства возвращены.');
    } catch (err) {
      handleFirestoreErrorGlobal(err, OperationType.WRITE, 'order-refund');
    }
  };

  const getOrderStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: 'Ожидает',
      cooking: 'Готовится',
      ready: 'Готов',
      completed: 'Выполнен',
      cancelled: 'Отменен'
    };
    return labels[status] || status;
  };

  const handleTopUp = async () => {
    const amount = parseFloat(topUpAmount) * 100; // to kopeks
    if (isNaN(amount) || amount <= 0) return;

    const txId = Math.random().toString(36).substr(2, 9);
    const newTx: Omit<WalletTransaction, 'id'> = {
      userId: currentUser.id,
      type: 'deposit',
      amount: amount,
      status: 'success', // For demo we assume instant success
      description: 'Пополнение кошелька (Карта)',
      timestamp: Date.now(),
      idempotencyKey: `topup_${Date.now()}`
    };

    try {
      await runTransaction(db, async (txn) => {
        const walletRef = doc(db, 'wallets', currentUser.id);
        const walletSnap = await txn.get(walletRef);
        
        if (!walletSnap.exists()) {
           // Handle non-existent wallet
           return;
        }

        const currentBalance = walletSnap.data().balance || 0;
        txn.update(walletRef, { 
          balance: currentBalance + amount,
          lastUpdate: Date.now()
        });

        const txRef = doc(collection(db, 'walletTransactions'));
        txn.set(txRef, newTx);
      });

      setIsTopUpOpen(false);
      setTopUpAmount('');
    } catch (err) {
      handleFirestoreErrorGlobal(err, OperationType.WRITE, 'top-up');
    }
  };

  const filteredTransactions = transactions.filter(tx => {
    const matchesTab = 
      activeTab === 'all' ? true :
      activeTab === 'deposits' ? tx.type === 'deposit' :
      activeTab === 'spendings' ? ['payment', 'commission'].includes(tx.type) :
      activeTab === 'bonuses' ? ['bonus_earn', 'bonus_redeem'].includes(tx.type) : true;
    
    const matchesSearch = (tx.description || '').toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (tx.id || '').toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesTab && matchesSearch;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6 sm:space-y-8 pb-24">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white flex items-center gap-3">
            <WalletIcon className="w-6 h-6 sm:w-8 sm:h-8 text-indigo-500" />
            Кошелёк и Лояльность
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Управляйте вашим балансом и бонусной картой</p>
        </div>
      </div>

      {/* Mobile Special Section: Virtual Card + Add-To-Wallet Buttons */}
      <div className="lg:hidden space-y-4">
        {renderVirtualCard()}
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={() => alert("Генерация пропуска Apple Wallet... Пожалуйста, подождите.")}
            className="flex items-center justify-center gap-2 px-3 py-3 bg-black text-white rounded-2xl hover:bg-slate-800 transition-all font-bold text-[10px] uppercase tracking-wider shadow-md"
          >
            <CreditCard className="w-4 h-4 text-white" />
            В Apple Wallet
          </button>
          <button 
            onClick={() => alert("Сохранение в Google Pay... Проверьте приложение.")}
            className="flex items-center justify-center gap-2 px-3 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all font-bold text-[10px] uppercase tracking-wider shadow-sm"
          >
            <QrCode className="w-4 h-4 text-indigo-500" />
            В G-Wallet
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6 sm:gap-8">
        {/* Main Stats Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Balance Cards Grid */}
          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-indigo-600 rounded-3xl p-3 xs:p-4 sm:p-6 text-white shadow-xl shadow-indigo-500/20 relative overflow-hidden flex flex-col justify-between min-h-[120px] xs:min-h-[140px] sm:min-h-[160px] md:min-h-0"
            >
              <div className="relative z-10">
                <p className="text-indigo-100 text-[8px] xs:text-[10px] sm:text-xs font-bold uppercase tracking-wider">Текущий баланс</p>
                <h2 className="text-sm xs:text-lg sm:text-2xl lg:text-4xl font-black mt-1 break-words">{formatRUB(wallet?.balance || 0)}</h2>
              </div>
              <div className="relative z-10 mt-3 sm:mt-6">
                <button 
                  onClick={() => setIsTopUpOpen(true)}
                  className="w-full flex items-center justify-center gap-1 bg-white text-indigo-600 py-2 sm:py-3 rounded-xl sm:rounded-2xl font-black text-[9px] xs:text-[10px] sm:text-sm hover:bg-slate-50 transition-all active:scale-95 shadow-sm"
                >
                  <Plus className="w-3 h-3 sm:w-5 sm:h-5 text-indigo-600" />
                  Пополнить
                </button>
              </div>
              <div className="absolute top-0 right-0 p-4 sm:p-8 opacity-10 pointer-events-none">
                <WalletIcon className="w-16 h-16 sm:w-32 sm:h-32" />
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-amber-500 rounded-3xl p-3 xs:p-4 sm:p-6 text-white shadow-xl shadow-amber-500/20 relative overflow-hidden flex flex-col justify-between min-h-[120px] xs:min-h-[140px] sm:min-h-[160px] md:min-h-0"
            >
              <div className="relative z-10">
                <p className="text-amber-100 text-[8px] xs:text-[10px] sm:text-xs font-bold uppercase tracking-wider">Бонусные баллы</p>
                <h2 className="text-sm xs:text-lg sm:text-2xl lg:text-4xl font-black mt-1 break-words">{(wallet?.bonusBalance || 0).toLocaleString()} <span className="text-[8px] xs:text-[10px] sm:text-base font-medium">баллов</span></h2>
              </div>
              <p className="relative z-10 text-amber-100/80 text-[7px] xs:text-[9px] sm:text-xs mt-3 sm:mt-6 flex items-center gap-1 leading-none">
                <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                Списание: 12.06.2024
              </p>
              <div className="absolute top-0 right-0 p-4 sm:p-8 opacity-10 pointer-events-none">
                <Gift className="w-16 h-16 sm:w-32 sm:h-32" />
              </div>
            </motion.div>
          </div>

          {/* Transactions List */}
          <div className="bg-white dark:bg-slate-950 rounded-3xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden shadow-sm">
            {activeTab !== 'admin' && (
              <div className="p-4 sm:p-6 border-b border-slate-100 dark:border-slate-900 flex flex-col gap-4">
                <div className="flex items-center gap-4 overflow-x-auto no-scrollbar scroll-smooth pb-0.5">
                  {(['all', 'deposits', 'spendings', 'bonuses', 'orders'] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={cn(
                        "pb-4 px-2 text-sm font-bold transition-all border-b-2 whitespace-nowrap",
                        activeTab === tab 
                          ? "text-indigo-600 border-indigo-600" 
                          : "text-slate-500 border-transparent hover:text-slate-700 dark:hover:text-slate-300"
                      )}
                    >
                      {tab === 'all' && 'Все операции'}
                      {tab === 'deposits' && 'Пополнения'}
                      {tab === 'spendings' && 'Траты'}
                      {tab === 'bonuses' && 'Бонусы'}
                      {tab === 'orders' && 'Мои заказы'}
                    </button>
                  ))}
                  {isAdmin && (
                    <button
                      onClick={() => setActiveTab('admin')}
                      className={cn(
                        "pb-4 px-2 text-sm font-bold transition-all border-b-2 whitespace-nowrap flex items-center gap-2",
                        activeTab === 'admin' 
                          ? "text-rose-600 border-rose-600" 
                          : "text-slate-500 border-transparent hover:text-rose-600"
                      )}
                    >
                      <ShieldCheck className="w-4 h-4" />
                      Управление
                    </button>
                  )}
                </div>
                <div className="relative flex-1 max-w-xs">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="text"
                    placeholder="Поиск по описанию..."
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border-none rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            )}
            {activeTab === 'admin' && (
              <div className="p-4 sm:p-6 border-b border-slate-100 dark:border-slate-900 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setActiveTab('all')}
                    className="pb-4 px-2 text-sm font-bold text-slate-500 hover:text-slate-700 transition"
                  >
                    ← К операциям
                  </button>
                  <button
                    onClick={() => setActiveTab('admin')}
                    className="pb-4 px-2 text-sm font-black text-rose-600 border-b-2 border-rose-600 flex items-center gap-2"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    Управление персоналом
                  </button>
                </div>
              </div>
            )}
 
            <div className="overflow-x-auto scrollbar-hide min-h-[400px]">
              {activeTab === 'admin' ? (
                <div className="flex flex-col md:grid md:grid-cols-3 min-h-[500px]">
                  {/* Staff Selection Sidebar */}
                  <div className={cn(
                    "border-b md:border-b-0 md:border-r border-slate-100 dark:border-slate-900 p-4 space-y-4 bg-slate-50/50 dark:bg-slate-900/20 transition-all w-full",
                    selectedStaff && "hidden md:block" // Hide list on mobile if staff is selected
                  )}>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text"
                        placeholder="Найти сотрудника..."
                        className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs outline-none focus:ring-2 focus:ring-indigo-500/20"
                        value={searchStaffQuery}
                        onChange={e => setSearchStaffQuery(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1 overflow-y-auto max-h-[400px] pr-2 custom-scrollbar">
                      {staffList
                        .filter(s => (s.name || '').toLowerCase().includes(searchStaffQuery.toLowerCase()))
                        .map(s => (
                          <button
                            key={s.id}
                            onClick={() => setSelectedStaff(s)}
                            className={cn(
                              "w-full text-left p-3 rounded-xl transition-all flex items-center justify-between group",
                              selectedStaff?.id === s.id 
                                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20" 
                                : "hover:bg-white dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                            )}
                          >
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-bold truncate">{s.name}</p>
                              <p className={cn("text-[10px] uppercase tracking-widest font-black", selectedStaff?.id === s.id ? "text-indigo-200" : "text-slate-400")}>{s.role}</p>
                            </div>
                            <ChevronRight className={cn("w-4 h-4 opacity-0 md:group-hover:opacity-100 transition-all shrink-0", selectedStaff?.id === s.id && "opacity-100")} />
                          </button>
                        ))}
                    </div>
                  </div>

                  {/* Control Panel */}
                  <div className={cn(
                    "col-span-2 p-5 sm:p-8 space-y-8 flex-1 bg-white dark:bg-slate-950",
                    !selectedStaff && "hidden md:block" // Hide control panel on mobile if no staff is selected
                  )}>
                    {selectedStaff ? (
                      <AnimatePresence mode="wait">
                        <motion.div 
                          key={selectedStaff.id}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="space-y-8"
                        >
                          {/* Mobile Back Button */}
                          <button 
                            onClick={() => setSelectedStaff(null)}
                            className="md:hidden flex items-center gap-2 text-slate-500 font-bold text-xs uppercase tracking-widest mb-2"
                          >
                            <ArrowDownLeft className="w-4 h-4 rotate-45 text-indigo-500" />
                            Назад к списку
                          </button>

                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div className="flex-1 min-w-0">
                              <h3 className="text-2xl font-black text-slate-900 dark:text-white truncate">{selectedStaff.name}</h3>
                              <p className="text-sm text-slate-500 flex items-center gap-2 mt-1">
                                <Shield className="w-4 h-4 text-rose-500 shrink-0" /> 
                                <span className="truncate">{selectedStaff.role} • ID: {selectedStaff.id}</span>
                              </p>
                            </div>
                            <div className="text-left sm:text-right bg-slate-50 dark:bg-slate-900/20 p-3.5 rounded-2xl md:bg-transparent">
                              <p className="text-[10px] uppercase font-black text-slate-400 tracking-widest">Баланс сотрудника</p>
                              <p className="text-xl font-black text-indigo-600">{formatRUB(selectedStaffWallet?.balance || 0)}</p>
                              <p className="text-xs font-bold text-amber-500">{selectedStaffWallet?.bonusBalance || 0} баллов</p>
                            </div>
                          </div>

                          <div className="grid sm:grid-cols-2 gap-8 pt-6 border-t border-slate-100 dark:border-slate-900 transition-all">
                            <div className="space-y-4">
                              <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                                <Plus className="w-3.5 h-3.5 text-indigo-500" /> Корректировки
                              </h4>
                              <div className="space-y-4 p-5 sm:p-6 bg-slate-50/50 dark:bg-slate-900/50 rounded-3xl border border-slate-100 dark:border-slate-800">
                                <div className="space-y-3">
                                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Деньги (±₽)</label>
                                  <input 
                                    type="number"
                                    placeholder="Напр: 500 или -200"
                                    className="w-full px-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-indigo-500/20"
                                    value={adminActionAmount}
                                    onChange={e => setAdminActionAmount(e.target.value)}
                                  />
                                </div>
                                <div className="space-y-3">
                                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Бонусы (±балл)</label>
                                  <input 
                                    type="number"
                                    placeholder="Напр: 50 или -30"
                                    className="w-full px-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-bold outline-none focus:ring-2 focus:ring-amber-550/20"
                                    value={adminActionBonus}
                                    onChange={e => setAdminActionBonus(e.target.value)}
                                  />
                                </div>
                                <div className="space-y-3">
                                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Причина</label>
                                  <textarea 
                                    placeholder="Лог операции..."
                                    rows={2}
                                    className="w-full px-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs outline-none focus:ring-2 focus:ring-indigo-500/20 resize-none"
                                    value={adminActionReason}
                                    onChange={e => setAdminActionReason(e.target.value)}
                                  />
                                </div>
                                <div className="grid grid-cols-2 gap-3">
                                  <button 
                                    onClick={() => handleAdminAdjustment('money')}
                                    disabled={isAdminActionProcessing || !adminActionAmount || !adminActionReason.trim()}
                                    className="py-3 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-900 disabled:opacity-50 transition-colors"
                                  >
                                    Рубли
                                  </button>
                                  <button 
                                    onClick={() => handleAdminAdjustment('bonus')}
                                    disabled={isAdminActionProcessing || !adminActionBonus || !adminActionReason.trim()}
                                    className="py-3 bg-amber-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-amber-600 disabled:opacity-50 transition-colors"
                                  >
                                    Баллы
                                  </button>
                                </div>
                              </div>
                            </div>

                            <div className="space-y-4">
                              <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                                 <History className="w-3.5 h-3.5 text-amber-500" /> Быстрые действия
                               </h4>
                               <div className="grid gap-3">
                                 <button 
                                   onClick={() => setIsAdminLogsOpen(true)}
                                   className="flex items-center justify-between p-4 bg-white dark:bg-slate-900 border-2 border-indigo-500/25 rounded-2xl hover:bg-indigo-50 dark:hover:bg-indigo-900/10 transition-all group"
                                 >
                                   <div className="flex items-center gap-3">
                                      <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600">
                                        <List className="w-4 h-4" />
                                      </div>
                                      <span className="text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-300">Лог операций</span>
                                   </div>
                                   <ChevronRight className="w-4 h-4 text-indigo-500" />
                                 </button>
                                 <button 
                                   onClick={() => {
                                     setAdminActionAmount('500');
                                     setAdminActionReason('Премия за смену');
                                   }}
                                  className="flex items-center justify-between p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:bg-emerald-50 dark:hover:bg-emerald-900/10 transition-all group"
                                >
                                  <span className="text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-300">Премия 500 ₽</span>
                                  <ArrowUpRight className="w-4 h-4 text-emerald-500" />
                                </button>
                                <button 
                                  onClick={() => {
                                    setAdminActionBonus('100');
                                    setAdminActionReason('Бонус за активность');
                                  }}
                                  className="flex items-center justify-between p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:bg-amber-50 dark:hover:bg-amber-900/10 transition-all group"
                                >
                                  <span className="text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-300">100 бонусов</span>
                                  <Gift className="w-4 h-4 text-amber-500" />
                                </button>
                                <div className="p-4 bg-rose-50 dark:bg-rose-900/10 rounded-2xl border border-rose-100 dark:border-rose-900/30">
                                  <p className="text-[9px] text-rose-500 font-bold mb-1 uppercase tracking-widest">Зона внимания</p>
                                  <p className="text-[9px] text-slate-500 leading-relaxed">Все корректировки записываются в реестр под Вашей подписью.</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      </AnimatePresence>
                    ) : (
                      <div className="h-full min-h-[300px] flex flex-col items-center justify-center text-slate-350 dark:text-slate-700 gap-4 opacity-50 px-6 text-center">
                        <Users className="w-16 h-16 sm:w-20 sm:h-20 text-indigo-400" />
                        <p className="font-black uppercase tracking-[0.15em] text-[10px] sm:text-sm">Выберите сотрудника из списка</p>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <>
                  {/* Desktop Table - Hidden on Mobile */}
                  <table className="w-full text-left hidden sm:table min-w-[600px] sm:min-w-0">
                    <thead className="bg-slate-50 dark:bg-slate-900 text-[10px] uppercase tracking-wider font-black text-slate-500">
                      <tr>
                        <th className="px-6 py-4">Операция</th>
                        <th className="px-6 py-4">Дата / ID</th>
                        <th className="px-6 py-4 text-right">Сумма</th>
                        <th className="px-6 py-4 text-center">Статус</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-900">
                      {activeTab === 'orders' ? (
                        orders.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="px-6 py-20 text-center text-slate-500">
                              <p className="text-xs uppercase font-black text-slate-400 tracking-wider">История заказов пуста</p>
                            </td>
                          </tr>
                        ) : (
                          orders.map((order, index) => (
                            <tr key={order.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/10 transition-colors">
                              <td className="px-6 py-4">
                                <p className="text-sm font-bold text-slate-900 dark:text-white">Чек №{orders.length - index} <span className="text-xs font-normal text-slate-400 font-mono">({order.orderNumber})</span></p>
                                <p className="text-xs text-slate-500">{order.items.length} поз. • Стол {order.tableNumber}</p>
                              </td>
                              <td className="px-6 py-4 text-xs">
                                 {new Date(order.timestamp).toLocaleString()}
                              </td>
                              <td className="px-6 py-4 text-right font-bold">
                                 {order.total} ₽
                              </td>
                              <td className="px-6 py-4">
                                 <div className="flex items-center justify-between">
                                    <span className={cn(
                                      "px-2 py-1 rounded text-[10px] font-bold uppercase",
                                      order.status === 'completed' && "bg-emerald-100 text-emerald-600",
                                      order.status === 'pending' && "bg-amber-100 text-amber-600",
                                      order.status === 'cancelled' && "bg-rose-100 text-rose-600"
                                    )}>
                                      {getOrderStatusLabel(order.status)}
                                    </span>
                                    {order.status !== 'cancelled' && (
                                      <button 
                                        onClick={() => handleRefund(order)}
                                        className="text-[10px] font-bold text-rose-500 hover:underline"
                                      >
                                        Отменить/Возврат
                                      </button>
                                    )}
                                 </div>
                              </td>
                            </tr>
                          ))
                        )
                      ) : filteredTransactions.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="px-6 py-20 text-center text-slate-500">
                            <div className="flex flex-col items-center gap-3">
                              <History className="w-12 h-12 text-slate-200" />
                              <p className="font-medium uppercase tracking-widest text-[10px] text-slate-400">История по Вашему запросу пуста</p>
                            </div>
                          </td>
                        </tr>
                      ) : (
                        filteredTransactions.map((tx) => (
                          <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/10 transition-colors group">
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className={cn(
                                  "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                                  ['bonus_earn', 'bonus_redeem'].includes(tx.type) 
                                    ? "bg-amber-100 text-amber-600 dark:bg-amber-500/10"
                                    : tx.amount > 0 
                                      ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/10" 
                                      : tx.amount < 0 
                                        ? "bg-rose-100 text-rose-600 dark:bg-rose-500/10"
                                        : "bg-slate-100 text-slate-500 dark:bg-slate-800"
                                )}>
                                  {tx.type === 'deposit' && <ArrowUpRight className="w-5 h-5" />}
                                  {tx.type === 'payment' && <ArrowDownLeft className="w-5 h-5" />}
                                  {tx.type === 'refund' && <ArrowUpRight className="w-5 h-5" />}
                                  {['bonus_earn', 'bonus_redeem'].includes(tx.type) && <Gift className="w-5 h-5" />}
                                </div>
                                <div className="min-w-0">
                                  <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{TRANSACTION_TYPE_LABELS[tx.type]}</p>
                                  <p className="text-xs text-slate-500 truncate max-w-[200px]">{tx.description}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <p className="text-xs font-medium text-slate-700 dark:text-slate-300">
                                {new Date(tx.timestamp).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                              </p>
                              <p className="text-[10px] font-mono text-slate-400 mt-0.5 uppercase tracking-tighter">ID: {tx.id.substr(0, 8)}</p>
                            </td>
                            <td className="px-6 py-4 text-right">
                              <p className={cn(
                                "text-sm font-black",
                                ['bonus_earn', 'bonus_redeem'].includes(tx.type)
                                  ? "text-amber-600"
                                  : tx.amount > 0 
                                    ? "text-emerald-600" 
                                    : tx.amount < 0 
                                      ? "text-rose-600" 
                                      : "text-slate-500 dark:text-slate-400"
                              )}>
                                {tx.amount > 0 ? '+' : ''}{formatRUB(tx.amount)}
                              </p>
                              {tx.bonusAmount && tx.bonusAmount !== 0 ? (
                                <p className="text-[10px] font-bold text-amber-600 mt-1">
                                  {tx.bonusAmount > 0 ? '+' : ''}{tx.bonusAmount} баллов
                                </p>
                              ) : null}
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center justify-center">
                                {tx.status === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-500" title="Успешно" />}
                                {tx.status === 'pending' && <Clock className="w-5 h-5 text-amber-500 animate-pulse" title="В обработке" />}
                                {tx.status === 'failed' && <XCircle className="w-5 h-5 text-rose-500" title="Ошибка" />}
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>

                  {/* Mobile View - Cards */}
                  <div className="sm:hidden divide-y divide-slate-100 dark:divide-slate-900 border-t border-slate-100 dark:border-slate-900">
                    {activeTab !== 'orders' && filteredTransactions.map((tx) => (
                      <div key={tx.id} className="p-4 flex items-center justify-between gap-3 bg-white dark:bg-slate-950">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className={cn(
                            "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                            ['bonus_earn', 'bonus_redeem'].includes(tx.type)
                              ? "bg-amber-100 text-amber-600 dark:bg-amber-500/10"
                              : tx.amount > 0 
                                ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/10" 
                                : tx.amount < 0 
                                  ? "bg-rose-100 text-rose-600 dark:bg-rose-500/10"
                                  : "bg-slate-100 text-slate-500 dark:bg-slate-800"
                          )}>
                            {tx.type === 'deposit' && <ArrowUpRight className="w-5 h-5" />}
                            {tx.type === 'payment' && <ArrowDownLeft className="w-5 h-5" />}
                            {tx.type === 'refund' && <ArrowUpRight className="w-5 h-5" />}
                            {['bonus_earn', 'bonus_redeem'].includes(tx.type) && <Gift className="w-5 h-5" />}
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{tx.description}</p>
                            <p className="text-[10px] text-slate-400">{new Date(tx.timestamp).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <p className={cn(
                            "text-xs font-black",
                            ['bonus_earn', 'bonus_redeem'].includes(tx.type)
                              ? "text-amber-500"
                              : tx.amount > 0 
                                ? "text-emerald-600" 
                                : tx.amount < 0 
                                  ? "text-rose-600" 
                                  : "text-slate-500 dark:text-slate-400"
                          )}>
                            {tx.amount > 0 ? '+' : ''}{formatRUB(tx.amount)}
                          </p>
                          {tx.bonusAmount && tx.bonusAmount !== 0 ? (
                            <p className="text-[10px] font-bold text-amber-500">
                              {tx.bonusAmount > 0 ? '+' : ''}{tx.bonusAmount}
                            </p>
                          ) : null}
                        </div>
                      </div>
                    ))}

                    {activeTab === 'orders' && orders.map((order, index) => (
                      <div key={order.id} className="p-4 space-y-3 bg-white dark:bg-slate-950">
                        <div className="flex justify-between items-start">
                          <div className="min-w-0">
                            <p className="text-sm font-bold text-slate-900 dark:text-white truncate">Чек №{orders.length - index} <span className="text-xs font-normal text-slate-400 font-mono">({order.orderNumber})</span></p>
                            <p className="text-[10px] text-slate-500 uppercase font-black">Стол {order.tableNumber} • {order.items.length} поз.</p>
                          </div>
                          <div className="text-right shrink-0">
                            <p className="text-sm font-black text-indigo-600">{order.total} ₽</p>
                            <span className={cn(
                              "px-1.5 py-0.5 rounded text-[8px] font-black uppercase",
                              order.status === 'completed' && "bg-emerald-100 text-emerald-600",
                              order.status === 'pending' && "bg-amber-100 text-amber-600",
                              order.status === 'cancelled' && "bg-rose-100 text-rose-600"
                            )}>
                              {getOrderStatusLabel(order.status)}
                            </span>
                          </div>
                        </div>
                        {order.status !== 'cancelled' && (
                          <button 
                            onClick={() => handleRefund(order)}
                            className="w-full py-2 bg-rose-50 dark:bg-rose-900/10 text-rose-600 text-[10px] font-bold rounded-xl active:scale-[0.98] transition-transform"
                          >
                            ОТМЕНИТЬ И ВЕРНУТЬ СРЕДСТВА
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar Cards */}
        <div className="space-y-6">
          {/* Virtual Card */}
          <div className="hidden lg:block">
            {renderVirtualCard()}
          </div>

          {/* Add to Wallet Buttons - Hidden on Mobile, rendered on Desktop in the Sidebar */}
          <div className="hidden lg:grid grid-cols-2 gap-3">
            <button 
              onClick={() => alert("Генерация пропуска Apple Wallet... Пожалуйста, подождите.")}
              className="flex items-center justify-center gap-2 px-3 py-3 bg-black text-white rounded-2xl hover:bg-slate-800 transition-all font-bold text-[10px] uppercase tracking-wider shadow-md"
            >
              <CreditCard className="w-4 h-4 text-white" />
              В Apple Wallet
            </button>
            <button 
              onClick={() => alert("Сохранение в Google Pay... Проверьте приложение.")}
              className="flex items-center justify-center gap-2 px-3 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-all font-bold text-[10px] uppercase tracking-wider shadow-sm"
            >
              <QrCode className="w-4 h-4 text-indigo-500" />
              В G-Wallet
            </button>
          </div>

          {/* Quick Info / Settings */}
          <div className="bg-white dark:bg-slate-950 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <h3 className="text-sm font-black uppercase tracking-widest text-slate-400">Безопасность и лимиты</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-500" />
                  2FA подтверждение
                </span>
                <span className="font-bold text-emerald-500">Активно</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">Дневной лимит</span>
                <span className="font-bold text-slate-900 dark:text-white">{formatRUB((wallet?.settings?.dailyLimit || 10000) * 100)}</span>
              </div>
              <div className="relative h-2 bg-slate-100 dark:bg-slate-900 rounded-full overflow-hidden">
                 <div className="absolute top-0 left-0 h-full w-2/3 bg-indigo-500 rounded-full" />
              </div>
              <p className="text-[10px] text-slate-400">Осталось {formatRUB(((wallet?.settings?.dailyLimit || 10000) * 0.66) * 100)} на сегодня</p>
            </div>
            <button 
              onClick={() => setIsSettingsOpen(true)}
              className="w-full mt-4 flex items-center justify-between px-4 py-3 bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-2xl transition-all group"
            >
               <span className="text-sm font-bold text-slate-700 dark:text-slate-300">Настройки кошелька</span>
               <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="bg-slate-50 dark:bg-slate-900/50 rounded-3xl p-6 border-l-4 border-indigo-500">
             <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-indigo-500 flex-shrink-0" />
                <div>
                   <p className="text-xs font-bold text-slate-900 dark:text-white">Программа лояльности</p>
                   <p className="text-[10px] text-slate-500 mt-1">Оплачивайте кошельком или картой и получайте 5% кешбэка баллами на бонусный счет.</p>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* Top Up Modal */}
      <AnimatePresence>
        {isTopUpOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsTopUpOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-md bg-white dark:bg-slate-950 rounded-3xl shadow-2xl overflow-hidden overflow-y-auto max-h-[90vh]"
            >
              <div className="p-8">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-2xl font-black text-slate-900 dark:text-white">Пополнение</h3>
                  <button 
                    onClick={() => setIsTopUpOpen(false)}
                    className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                  >
                    <XCircle className="w-6 h-6 text-slate-400" />
                  </button>
                </div>

                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 dark:text-slate-300 ml-1">Сумма пополнения (₽)</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        value={topUpAmount}
                        onChange={e => setTopUpAmount(e.target.value)}
                        placeholder="0.00"
                        className="w-full pl-6 pr-12 py-4 bg-slate-50 dark:bg-slate-900 border-2 border-transparent focus:border-indigo-500 rounded-2xl text-2xl font-black outline-none transition-all"
                      />
                      <span className="absolute right-6 top-1/2 -translate-y-1/2 text-2xl font-black text-slate-400">₽</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-2">
                    {[500, 1000, 2000, 5000].map(val => (
                      <button 
                        key={val}
                        onClick={() => setTopUpAmount(val.toString())}
                        className="py-2 bg-slate-50 dark:bg-slate-900 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-indigo-600 transition-all border border-transparent hover:border-indigo-200"
                      >
                        +{val}
                      </button>
                    ))}
                  </div>

                  <div className="space-y-4 pt-4">
                    <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl border border-indigo-100 dark:border-indigo-900/50 flex flex-col gap-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-500">Комиссия (0%)</span>
                        <span className="font-bold text-indigo-600">0.00 ₽</span>
                      </div>
                      <div className="flex justify-between items-center text-lg font-black">
                        <span className="text-slate-700 dark:text-slate-200">Итого</span>
                        <span className="text-slate-900 dark:text-white">{formatRUB(parseFloat(topUpAmount || '0') * 100)}</span>
                      </div>
                    </div>

                    <button 
                      onClick={handleTopUp}
                      disabled={!topUpAmount || parseFloat(topUpAmount) <= 0}
                      className="w-full py-4 bg-indigo-500 hover:bg-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-2xl font-black text-lg shadow-lg shadow-indigo-500/30 transition-all active:scale-95"
                    >
                      Оплатить и пополнить
                    </button>

                    <p className="text-[10px] text-center text-slate-400">
                      Нажимая «Оплатить», вы соглашаетесь с условиями оферты и правилами программы лояльности.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* Settings Modal */}
      <AnimatePresence>
        {isSettingsOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSettingsOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-white dark:bg-slate-950 rounded-3xl shadow-2xl overflow-hidden overflow-y-auto max-h-[90vh]"
            >
              <div className="p-8">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white">
                      <SettingsIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-xl font-black text-slate-900 dark:text-white">Настройки</h3>
                      <p className="text-xs text-slate-500">Безопасность и управление кошельком</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setIsSettingsOpen(false)}
                    className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                  >
                    <XCircle className="w-6 h-6 text-slate-400" />
                  </button>
                </div>

                <div className="space-y-8">
                  {/* Security Section */}
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Безопасность</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl">
                        <div className="flex items-center gap-3">
                          <Smartphone className="w-5 h-5 text-indigo-500" />
                          <div>
                            <p className="text-sm font-bold text-slate-900 dark:text-white">Двухфакторная аутентификация</p>
                            <p className="text-[10px] text-slate-500">Подтверждение операций через SMS</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => updateDraftSetting('twoFactorEnabled', !settings.twoFactorEnabled)}
                          className={cn("transition-colors", settings.twoFactorEnabled ? "text-indigo-600" : "text-slate-300")}
                        >
                          {settings.twoFactorEnabled ? <ToggleRight className="w-8 h-8" /> : <ToggleLeft className="w-8 h-8" />}
                        </button>
                      </div>

                      <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Lock className="w-5 h-5 text-indigo-500" />
                            <div>
                              <p className="text-sm font-bold text-slate-900 dark:text-white">Защита PIN-кодом</p>
                              <p className="text-[10px] text-slate-500">Запрашивать PIN при входе в кошелёк</p>
                            </div>
                          </div>
                          <button 
                            onClick={() => updateDraftSetting('pinEnabled', !settings.pinEnabled)}
                            className={cn("transition-colors", settings.pinEnabled ? "text-indigo-600" : "text-slate-300")}
                          >
                            {settings.pinEnabled ? <ToggleRight className="w-8 h-8" /> : <ToggleLeft className="w-8 h-8" />}
                          </button>
                        </div>
                        
                        {settings.pinEnabled && (
                          <button 
                            onClick={() => setIsPinSetupOpen(true)}
                            className="w-full py-2 px-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 transition-all flex items-center justify-between"
                          >
                            <span>{settings.pinCode ? 'Изменить PIN-код' : 'Установить PIN-код'}</span>
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Limits Section */}
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Лимиты</h4>
                    <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl space-y-4">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-bold text-slate-900 dark:text-white">Дневной лимит трат</p>
                        <p className="text-sm font-black text-indigo-600">{formatRUB(settings.dailyLimit * 100)}</p>
                      </div>
                      <input 
                        type="range"
                        min="1000"
                        max="100000"
                        step="1000"
                        value={settings.dailyLimit}
                        onChange={(e) => updateDraftSetting('dailyLimit', parseInt(e.target.value))}
                        className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                      />
                      <div className="flex justify-between text-[10px] text-slate-400 font-bold">
                        <span>1 000 ₽</span>
                        <span>100 000 ₽</span>
                      </div>
                    </div>
                  </div>

                  {/* Card Management */}
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Управление картой</h4>
                    <div className="space-y-3">
                      <button 
                        onClick={async () => {
                          if (confirm('Вы уверены, что хотите перевыпустить карту? Старый номер будет аннулирован.')) {
                            const newCardToken = generate16DigitCard();
                            updateDraftSetting('cardTokenChanged', newCardToken); // Mark for update
                            // Since this is a specialized action, maybe we keep it immediate or draft it.
                            // The user said "Все изменения принимаются после сохранения", so I'll draft the token change too?
                            // Actually, let's keep token change immediate for safety, but the prompt says 
                            // "после сохранения все изменения принимаются, после отмены ничего не меняется".
                            // So I will draft even the card reissue.
                            setSettings(prev => ({
                              ...prev,
                              newCardToken: newCardToken
                            }));
                          }
                        }}
                        className="w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 rounded-2xl transition-all"
                      >
                        <div className="flex items-center gap-3">
                          <CardIcon className="w-5 h-5 text-indigo-500" />
                          <div className="text-left">
                            <p className="text-sm font-bold text-slate-900 dark:text-white">Перевыпустить карту</p>
                            <p className="text-[10px] text-slate-500">
                              { (settings as any).newCardToken ? 'Запланировано: ' + (settings as any).newCardToken : 'Сгенерировать новый 16-значный номер' }
                            </p>
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-slate-400" />
                      </button>

                      <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl">
                        <div className="flex items-center gap-3">
                          <ShieldCheck className="w-5 h-5 text-emerald-500" />
                          <div>
                            <p className="text-sm font-bold text-slate-900 dark:text-white">Активность карты</p>
                            <p className="text-[10px] text-slate-500">Временно заблокировать карту</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => {
                            const val = !((settings as any).cardIsActive ?? wallet?.virtualCard.isActive);
                            updateDraftSetting('cardIsActive', val);
                          }}
                          className={cn("transition-colors", ((settings as any).cardIsActive ?? wallet?.virtualCard.isActive) ? "text-emerald-500" : "text-slate-300")}
                        >
                          {((settings as any).cardIsActive ?? wallet?.virtualCard.isActive) ? <ToggleRight className="w-8 h-8" /> : <ToggleLeft className="w-8 h-8" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Preferences */}
                  <div className="space-y-4">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Уведомления</h4>
                    <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl">
                      <div className="flex items-center gap-3">
                        <BellRing className="w-5 h-5 text-indigo-500" />
                        <div>
                          <p className="text-sm font-bold text-slate-900 dark:text-white">Push-уведомления</p>
                          <p className="text-[10px] text-slate-500">Транзакции, кешбэк, новости</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => updateDraftSetting('notificationsEnabled', !settings.notificationsEnabled)}
                        className={cn("transition-colors", settings.notificationsEnabled ? "text-indigo-600" : "text-slate-300")}
                      >
                        {settings.notificationsEnabled ? <ToggleRight className="w-8 h-8" /> : <ToggleLeft className="w-8 h-8" />}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-10">
                  <button 
                    onClick={() => {
                      resetDraftSettings();
                      setIsSettingsOpen(false);
                    }}
                    className="py-4 bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-slate-200 transition-all"
                  >
                    Отмена
                  </button>
                  <button 
                    onClick={async () => {
                      const finalSettings = {
                        twoFactorEnabled: settings.twoFactorEnabled,
                        pinEnabled: settings.pinEnabled,
                        dailyLimit: settings.dailyLimit,
                        notificationsEnabled: settings.notificationsEnabled,
                        pinCode: settings.pinCode
                      };
                      const updateData: any = { settings: finalSettings };
                      
                      if ((settings as any).newCardToken) {
                        updateData['virtualCard.token'] = (settings as any).newCardToken;
                      }
                      if ((settings as any).cardIsActive !== undefined) {
                        updateData['virtualCard.isActive'] = (settings as any).cardIsActive;
                      }

                      updateData.lastUpdate = Date.now();
                      
                      try {
                        const walletRef = doc(db, 'wallets', currentUser.id);
                        await updateDoc(walletRef, updateData);
                        setIsSettingsOpen(false);
                      } catch (err) {
                        console.error('Save failed:', err);
                        alert('Ошибка при сохранении настроек');
                      }
                    }}
                    className="py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20"
                  >
                    Сохранить
                  </button>
                </div>

                <div className="mt-10 pt-6 border-t border-slate-100 dark:border-slate-900">
                  <p className="text-[10px] text-center text-slate-400">
                    Версия системы кошелька: 2.4.1 (Stable)<br/>
                    Безопасность данных гарантирована шифрованием AES-256.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* PIN Setup Modal */}
      <AnimatePresence>
        {isPinSetupOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsPinSetupOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-sm bg-white dark:bg-slate-950 rounded-3xl shadow-2xl p-8"
            >
              <div className="text-center space-y-6">
                <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl flex items-center justify-center mx-auto text-indigo-600">
                  <Fingerprint className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl font-black text-slate-900 dark:text-white">Установка PIN-кода</h4>
                  <p className="text-xs text-slate-500 mt-2">Введите 4-значный код для защиты входа</p>
                </div>

                <div className="flex justify-center gap-3">
                  {[0, 1, 2, 3].map(i => (
                    <div 
                      key={i}
                      className={cn(
                        "w-12 h-16 rounded-xl border-2 flex items-center justify-center text-2xl font-black transition-all",
                        tempPin.length > i ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600" : "border-slate-100 dark:border-slate-900 text-slate-300"
                      )}
                    >
                      {tempPin[i] ? '•' : ''}
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-3 gap-3">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 'C', 0, '←'].map(key => (
                    <button
                      key={key.toString()}
                      onClick={() => {
                        if (key === 'C') setTempPin('');
                        else if (key === '←') setTempPin(prev => prev.slice(0, -1));
                        else if (tempPin.length < 4) setTempPin(prev => prev + key);
                      }}
                      className={cn(
                        "py-4 rounded-xl font-black transition-all active:scale-95 text-lg",
                        typeof key === 'number' ? "bg-slate-50 dark:bg-slate-900 hover:bg-slate-100" : "text-indigo-600 hover:bg-indigo-50"
                      )}
                    >
                      {key}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4">
                  <button 
                    onClick={() => {
                      setTempPin('');
                      setIsPinSetupOpen(false);
                    }}
                    className="py-3 text-xs font-black uppercase tracking-widest text-slate-400 hover:text-slate-600"
                  >
                    Отмена
                  </button>
                  <button 
                    disabled={tempPin.length !== 4}
                    onClick={() => {
                      updateDraftSetting('pinCode', tempPin);
                      setTempPin('');
                      setIsPinSetupOpen(false);
                    }}
                    className="py-3 bg-indigo-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-indigo-700 disabled:opacity-50 shadow-lg shadow-indigo-500/20"
                  >
                    Применить
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* Admin Logs Modal */}
      <AnimatePresence>
        {isAdminLogsOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAdminLogsOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-4xl bg-white dark:bg-slate-950 rounded-[40px] shadow-2xl overflow-hidden"
            >
              <div className="h-[80vh] flex flex-col">
                <div className="p-8 border-b border-slate-100 dark:border-slate-900 flex items-center justify-between bg-white/50 dark:bg-slate-950/50 backdrop-blur-xl">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
                      <List className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-black text-slate-900 dark:text-white">Лог системных действий</h3>
                      <p className="text-sm text-slate-500 font-medium">История административных корректировок и изменений</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setIsAdminLogsOpen(false)}
                    className="p-3 hover:bg-slate-100 dark:hover:bg-slate-900 rounded-2xl transition-colors"
                  >
                    <XCircle className="w-8 h-8 text-slate-400" />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto p-8 space-y-4 custom-scrollbar">
                  {logs.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-300 dark:text-slate-800 opacity-50 py-20">
                      <Shield className="w-24 h-24 mb-4" />
                      <p className="font-black uppercase tracking-widest">Логов пока нет</p>
                    </div>
                  ) : (
                    logs.map((log) => (
                      <div 
                        key={log.id}
                        className="group flex items-start gap-4 p-5 rounded-3xl bg-slate-50 dark:bg-slate-900/50 border border-transparent hover:border-indigo-500/20 hover:bg-white dark:hover:bg-slate-900 transition-all"
                      >
                        <div className={cn(
                          "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                          log.adjustmentType === 'money' ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/20" : "bg-amber-100 text-amber-600 dark:bg-amber-900/20"
                        )}>
                          {log.adjustmentType === 'money' ? <CardIcon className="w-5 h-5" /> : <Gift className="w-5 h-5" />}
                        </div>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-black text-slate-900 dark:text-white">
                              {log.adminName} 
                              {log.adminRole && (
                                <span className="text-slate-400 font-bold ml-1 uppercase text-[10px]">({log.adminRole})</span>
                              )}
                            </p>
                            <p className="text-[10px] font-bold text-slate-400">
                              {new Date(log.timestamp).toLocaleString('ru-RU')}
                            </p>
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-400 font-medium">
                            {log.adjustmentType === 'money' ? 'Изменение баланса' : 'Корректировка бонусов'}
                            {log.targetStaffName && (
                              <> для <span className="font-black text-slate-900 dark:text-white">{log.targetStaffName}</span></>
                            )}
                          </p>
                          <div className="flex items-center gap-3 pt-1">
                            <div className="px-3 py-1 bg-white dark:bg-slate-800 rounded-lg text-[10px] font-black uppercase tracking-widest border border-slate-100 dark:border-slate-800">
                              {log.adjustmentType === 'money' ? formatRUB(log.amount * 100) : `${log.amount} баллов`}
                            </div>
                            {log.reason && (
                              <p className="text-[10px] text-slate-400 italic">"{log.reason.replace('Админ-корректировка: ', '')}"</p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Zoomed QR Overlay */}
      <AnimatePresence>
        {isQrZoomed && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsQrZoomed(false)}
              className="absolute inset-0 bg-slate-900/70 backdrop-blur-md bg-slate-900/80"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative w-full max-w-sm bg-white dark:bg-slate-950 rounded-3xl shadow-2xl p-6 text-center border border-slate-200 dark:border-slate-800"
            >
              <button 
                onClick={() => setIsQrZoomed(false)}
                className="absolute right-4 top-4 p-2 hover:bg-slate-100 dark:hover:bg-slate-900 rounded-xl transition-colors"
              >
                <XCircle className="w-6 h-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200" />
              </button>

              <div className="pt-4 space-y-6">
                <div>
                  <h4 className="text-lg font-black text-slate-900 dark:text-white">Карта лояльности</h4>
                  <p className="text-xs text-slate-500 mt-1">Покажите на кассе для начисления или списания баллов</p>
                </div>

                <div className="bg-slate-50 dark:bg-slate-900/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 flex flex-col justify-center items-center shadow-inner">
                  <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-100 relative group">
                    <QrCode className="w-56 h-56 text-slate-900" />
                    <div className="absolute inset-0 border border-indigo-500/10 rounded-2xl pointer-events-none group-hover:scale-105 transition-transform" />
                  </div>
                  <div className="mt-4 text-xs font-mono font-bold tracking-[0.25em] text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-200/55 dark:border-slate-800/80">
                    {wallet?.virtualCard?.token || "0000 0000 0000 0000"}
                  </div>
                </div>

                <button 
                  onClick={() => setIsQrZoomed(false)}
                  className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-sm shadow-md transition-colors"
                >
                  Закрыть
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
