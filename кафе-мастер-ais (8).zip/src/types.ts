export interface Dish {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string;
  available: boolean;
  ingredients: { ingredientId: string; amount: number }[];
  prepTime: number; // Время приготовления в минутах
  weight: number; // Вес блюда в граммах
}

export interface Ingredient {
  id: string;
  name: string;
  unit: string;
  quantity: number;
  minStock: number;
  costPrice: number; // Себестоимость за единицу (кг, л, шт)
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: 'inventory' | 'staff' | 'utility' | 'other';
  timestamp: number;
}

export interface OrderItem {
  dishId: string;
  name: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  orderNumber: string; // Номер чека
  tableNumber: number;
  items: OrderItem[];
  status: 'pending' | 'cooking' | 'ready' | 'completed' | 'cancelled';
  timestamp: number;
  subtotal: number;
  discountTotal?: number;
  appliedBonuses?: number;
  promoCode?: string;
  total: number;
  guests: number;
  userId?: string;
  paymentMethod?: 'wallet' | 'cash';
}

export interface PromoCode {
  id: string;
  code: string;
  discountPercent: number; // 0-100
  maxDiscount?: number; // Максимальная сумма скидки в рублях
  isActive: boolean;
  usageCount: number;
  maxUsages?: number;
  expiryDate?: number;
}

export type Role = 'owner' | 'admin' | 'chef' | 'waiter' | 'bartender' | 'tech' | 'user' | 'tester' | 'developer' | 'hr' | 'other';

export interface Staff {
  id: string;
  name: string;
  position: string;
  role: Role;
  phone: string;
  login: string;
  password?: string;
  avatarUrl?: string;
  isOnline?: boolean;
  lastSeen?: number;
  firebaseUid?: string;
  registrationDate?: number;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'inventory' | 'status' | 'info' | 'chat' | 'ticket';
  timestamp: number;
  read: boolean;
  targetRoles?: Role[];
  targetUserId?: string;
}

export interface Message {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  senderRole: Role;
  text: string;
  timestamp: number;
  isBot?: boolean;
  imageUrl?: string;
  isEdited?: boolean;
  readBy?: string[]; // Array of userIds who read this message
  status?: 'sending' | 'sent' | 'read'; // Local-only status for UI
  type?: 'text' | 'voice' | 'file' | 'image';
  fileUrl?: string;
  fileName?: string;
  duration?: number; // for voice messages
  isPinned?: boolean;
}

export interface ChatRoom {
  id: string;
  name: string;
  type: 'group' | 'dm';
  participants: string[]; // Array of staff IDs
  lastMessage?: string;
  lastMessageTimestamp?: number;
  createdById: string;
  createdAt: number;
  pinnedMessageId?: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  userRole: Role;
  action: string;
  details?: string;
  timestamp: number;
}

export interface TicketComment {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: Role;
  text: string;
  timestamp: number;
  readAt?: number;
}

export interface Ticket {
  id: string;
  ticketNumber: string;
  title: string;
  description: string;
  creatorId: string;
  creatorName: string;
  creatorRole: Role;
  status: 'new' | 'investigating' | 'commented' | 'resolved' | 'closed' | 'archived';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignedToId?: string;
  assignedToName?: string;
  comments: TicketComment[];
  timestamp: number;
  updatedAt: number;
  devComment?: string;
}

export interface ChatSession {
  id: string; // userId
  userName: string;
  userRole?: Role;
  status: 'bot' | 'operator' | 'tech' | 'closed' | 'new' | 'processing' | 'pending' | 'resolved';
  lastActivity: number;
  rating?: number;
  sessionStartTime?: number;
  pendingTransferId?: string | null;
  assignedOperatorId?: string | null;
}

export interface Wallet {
  id: string; // Обычно совпадает с userId
  balance: number; // В копейках
  bonusBalance: number; // В баллах
  virtualCard: {
    id: string;
    token: string; // 16 цифр
    isActive: boolean;
    holderName?: string; // Настраиваемое ФИО
  };
  settings?: {
    dailyLimit: number;
    twoFactorEnabled: boolean;
    pinEnabled: boolean;
    notificationsEnabled: boolean;
    pinCode?: string;
  };
  lastUpdate: number;
}

export type TransactionType = 'deposit' | 'payment' | 'refund' | 'bonus_earn' | 'bonus_redeem' | 'bonus_expire' | 'commission' | 'hold';
export type TransactionStatus = 'pending' | 'success' | 'failed' | 'expired';

export interface WalletTransaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number; // В копейках, положительное или отрицательное
  bonusAmount?: number; // В баллах
  status: TransactionStatus;
  description: string;
  orderId?: string;
  timestamp: number;
  idempotencyKey: string;
  metadata?: Record<string, any>;
}

export type View = 'dashboard' | 'menu' | 'orders' | 'kitchen' | 'inventory' | 'staff' | 'reports' | 'changelog' | 'logs' | 'promos' | 'tickets' | 'staff-chat' | 'profile' | 'wallet' | 'wifi' | 'dev-logs' | 'hr-docs';

export interface ElectronicDocument {
  id: string;
  type: 'accounting' | 'hiring' | 'dismissal' | 'candidates' | 'owner' | 'archive';
  title: string;
  employeeName: string;
  employeeId?: string;
  createdBy: string;
  createdById: string;
  createdAt: number;
  status: 'draft' | 'pending_hr' | 'approved' | 'rejected';
  fields: {
    position?: string;
    salary?: number;
    startDate?: string;
    endDate?: string;
    reason?: string;
    notes?: string;
    passport?: string;
    inn?: string;
    snils?: string;
    assignedHrId?: string;
    hrComment?: string;
    phone?: string;
    email?: string;
    resume?: string;
    interviewDate?: string;
  };
}

