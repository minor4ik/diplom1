export const formatRUB = (kopeks: number): string => {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    minimumFractionDigits: 2,
  }).format(kopeks / 100);
};

export const formatBonus = (amount: number): string => {
  return `${amount} баллов`;
};

// Правила лояльности: 5% от суммы оплаты картой/кошельком
export const calculateLoyaltyPoints = (amountKopeks: number): number => {
  return Math.floor(amountKopeks / 100 * 0.05);
};

export const WALLET_LIMITS = {
  MIN_DEPOSIT: 10000, // 100 руб
  MAX_DEPOSIT: 5000000, // 50 000 руб
  MONTHLY_LIMIT: 20000000, // 200 000 руб
};

export const TRANSACTION_STATUS_LABELS: Record<string, string> = {
  pending: 'В обработке',
  success: 'Успешно',
  failed: 'Ошибка',
  expired: 'Истекло'
};

export const TRANSACTION_TYPE_LABELS: Record<string, string> = {
  deposit: 'Пополнение',
  payment: 'Оплата заказа',
  refund: 'Возврат',
  bonus_earn: 'Начисление бонусов',
  bonus_redeem: 'Списание бонусов',
  bonus_expire: 'Сгорание бонусов',
  commission: 'Комиссия',
  hold: 'Удержание'
};
