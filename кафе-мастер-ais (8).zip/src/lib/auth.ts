import { Staff, Role } from '../types';
import { auth } from '../firebase';

export function getEffectiveRole(user: Staff | null): Role {
  // If authenticated user is the project developer/author, grant full owner permissions
  if (auth.currentUser?.email === 'babkinmishel@gmail.com') {
    return 'owner';
  }

  if (!user) return 'other';
  
  // Приоритет прямому полю Role, если оно задано корректно и не является стандартным/заглушкой
  if (user.role && user.role !== 'other' && user.role !== 'user') return user.role;

  const pos = (user.position || '').toLowerCase();
  if (pos === 'владелец' || pos === 'owner') return 'owner';
  if (pos.includes('администратор') || pos.includes('admin') || pos.includes('админ')) return 'admin';
  if (pos === 'пользователь' || pos === 'user') return 'user';
  if (pos.includes('технический') || pos.includes('тех') || pos.includes('tech') || pos.includes('support')) return 'tech';
  if (pos === 'повар' || pos === 'шеф-повар' || pos === 'chef' || pos.includes('кухня')) return 'chef';
  if (pos === 'официант' || pos === 'waiter' || pos.includes('зал')) return 'waiter';
  if (pos === 'бармен' || pos === 'bartender' || pos.includes('бар')) return 'bartender';
  if (pos.includes('тестер') || pos.includes('tester')) return 'tester';
  if (pos.includes('разработчик') || pos.includes('developer') || pos.includes('dev')) return 'developer';
  if (pos.includes('кадр') || pos.includes('hr')) return 'hr';
  
  return user.role || 'other';
}
