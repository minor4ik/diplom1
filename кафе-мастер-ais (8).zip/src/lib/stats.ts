import { Order } from '../types';

export const getValidOrders = (orders: Order[]) => {
  return orders.filter(o => o.status === 'completed');
};

export const calculateRevenue = (orders: Order[]) => {
  return getValidOrders(orders).reduce((sum, o) => sum + o.total, 0);
};
