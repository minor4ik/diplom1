import { useState, useEffect, useRef, useCallback } from 'react';
import { Dish, Ingredient, Order, Staff, Expense, Notification, ActivityLog, PromoCode, OrderItem, Ticket, TicketComment, Message, Role, Wallet, ChatRoom, View, ElectronicDocument } from './types';
import { getEffectiveRole } from './lib/auth';
import { db, auth } from './firebase';
import { doc, setDoc, collection, onSnapshot, query, orderBy, deleteDoc, writeBatch, getDocs, limit, where, runTransaction, addDoc, terminate, clearIndexedDbPersistence } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { calculateLoyaltyPoints } from './lib/walletUtils';

// Начальные демо-данные
const initialStaff: Staff[] = [
  { id: 'admin-main', name: 'Главный Администратор', position: 'Владелец', role: 'owner', phone: '+7 (000) 000-00-00', login: 'AdminVIVT', password: 'AdminVIVT' },
  { id: 'admin-secondary', name: 'Администратор (Резерв)', position: 'Администратор', role: 'admin', phone: '+7 (000) 000-00-01', login: 'qwerty123', password: 'qwerty123' },
  { id: 'teh-admin', name: 'Технический Специалист', position: 'Тех. Администратор', role: 'tech', phone: '+7 (999) 111-11-11', login: 'teh123', password: 'teh123' },
  { id: 'dev-admin', name: 'Разработчик Системы', position: 'Разработчик', role: 'developer', phone: '+7 (999) 222-22-22', login: 'dev', password: 'dev' },
  { id: 'test-qa', name: 'Тестировщик Системы', position: 'Тестировщик', role: 'tester', phone: '+7 (999) 777-77-77', login: 'test', password: 'test' },
  { id: '1', name: 'Иванов Иван', position: 'Администратор', role: 'admin', phone: '+7 (999) 123-45-67', login: 'admin', password: 'admin' },
  { id: '2', name: 'Петров Петр', position: 'Официант', role: 'waiter', phone: '+7 (999) 765-43-21', login: 'waiter1', password: 'waiter1' },
  { id: '3', name: 'Сидоров Сидор', position: 'Повар', role: 'chef', phone: '+7 (999) 000-00-00', login: 'chef1', password: 'chef1' },
  { id: '4', name: 'Александр Петров', position: 'Бармен', role: 'other', phone: '+7 (961) 302-407-23', login: 'bar', password: 'bar' },
  { id: '5', name: 'Салам', position: 'Разработчик', role: 'developer', phone: '+7 (000) 000-00-00', login: 'salam', password: 'salam228' },
];

const initialDishes: Dish[] = [
  { 
    id: '1', 
    name: 'Филадельфия', 
    category: 'Роллы', 
    price: 650, 
    description: 'Премиум ролл с лососем и увеличенной порцией сливочного сыра', 
    available: true, 
    ingredients: [
      { ingredientId: 'i5', amount: 0.18 }, // Рис
      { ingredientId: 'i6', amount: 0.08 }, // Лосось
      { ingredientId: 'i10', amount: 0.06 }, // Сливочный сыр
      { ingredientId: 'i11', amount: 0.02 }  // Нори
    ], 
    prepTime: 12,
    weight: 300
  },
  { 
    id: '2', 
    name: 'Калифорния', 
    category: 'Роллы', 
    price: 480, 
    description: 'Ролл с крабом, авокадо и икрой тобико', 
    available: true, 
    ingredients: [
      { ingredientId: 'i5', amount: 0.15 }, 
      { ingredientId: 'i12', amount: 0.04 }, // Крабовое мясо
      { ingredientId: 'i13', amount: 0.03 }, // Авокадо
      { ingredientId: 'i14', amount: 0.01 }  // Тобико
    ], 
    prepTime: 10,
    weight: 210
  },
  { 
    id: '3', 
    name: 'Маргарита', 
    category: 'Пицца', 
    price: 650, 
    description: 'Классическая пицца с томатами и моцареллой', 
    available: true, 
    ingredients: [
      { ingredientId: 'i7', amount: 0.25 }, // Тесто
      { ingredientId: 'i8', amount: 0.15 }, // Моцарелла
      { ingredientId: 'i15', amount: 0.1 }   // Томатный соус
    ], 
    prepTime: 15,
    weight: 450
  },
  { 
    id: '4', 
    name: 'Пепперони', 
    category: 'Пицца', 
    price: 750, 
    description: 'Острая пицца с колбасками пепперони', 
    available: true, 
    ingredients: [
      { ingredientId: 'i7', amount: 0.25 }, 
      { ingredientId: 'i8', amount: 0.15 }, 
      { ingredientId: 'i9', amount: 0.08 }, // Пепперони
      { ingredientId: 'i15', amount: 0.1 }
    ], 
    prepTime: 15,
    weight: 480
  },
  { 
    id: '5', 
    name: 'Морс Ягодный', 
    category: 'Напитки', 
    price: 150, 
    description: 'Домашний морс из лесных ягод', 
    available: true, 
    ingredients: [
      { ingredientId: 'i16', amount: 0.05 } // Ягоды
    ], 
    prepTime: 2,
    weight: 300
  },
  { 
    id: '6', 
    name: 'Лимонад Классический', 
    category: 'Напитки', 
    price: 200, 
    description: 'Освежающий лимонад с лимоном и мятой', 
    available: true, 
    ingredients: [
      { ingredientId: 'i17', amount: 0.03 }, // Лимон
      { ingredientId: 'i18', amount: 0.005 } // Мята
    ], 
    prepTime: 5,
    weight: 350
  },
  { 
    id: '7', 
    name: 'Мохито Безалкогольный', 
    category: 'Напитки', 
    price: 250, 
    description: 'Классический мохито с лаймом, мятой и содовой', 
    available: true, 
    ingredients: [
      { ingredientId: 'i19', amount: 0.04 }, // Лайм
      { ingredientId: 'i18', amount: 0.01 },  // Мята
      { ingredientId: 'i20', amount: 0.2 }   // Содовая
    ], 
    prepTime: 5,
    weight: 400
  },
  { 
    id: '8', 
    name: 'Апельсиновый сок', 
    category: 'Напитки', 
    price: 180, 
    description: 'Свежевыжатый апельсиновый сок', 
    available: true, 
    ingredients: [
      { ingredientId: 'i21', amount: 0.3 } // Апельсины
    ], 
    prepTime: 3,
    weight: 250
  },
  { 
    id: '9', 
    name: 'Ролл Дракон', 
    category: 'Роллы', 
    price: 680, 
    description: 'Ролл с угрем, авокадо и соусом унаги', 
    available: true, 
    ingredients: [
      { ingredientId: 'i5', amount: 0.15 }, 
      { ingredientId: 'i22', amount: 0.05 }, // Угорь
      { ingredientId: 'i13', amount: 0.03 }, // Авокадо
      { ingredientId: 'i23', amount: 0.01 }  // Соус Унаги
    ], 
    prepTime: 15,
    weight: 240
  },
  { 
    id: '10', 
    name: 'Пицца Четыре Сыра', 
    category: 'Пицца', 
    price: 800, 
    description: 'Пицца с моцареллой, пармезаном, горгонзолой и чеддером', 
    available: true, 
    ingredients: [
      { ingredientId: 'i7', amount: 0.25 }, 
      { ingredientId: 'i8', amount: 0.08 }, // Моцарелла
      { ingredientId: 'i24', amount: 0.04 }, // Пармезан
      { ingredientId: 'i25', amount: 0.04 }, // Горгонзола
      { ingredientId: 'i26', amount: 0.04 }  // Чеддер
    ], 
    prepTime: 15,
    weight: 460
  },
  { 
    id: '11', 
    name: 'Ролл Канада', 
    category: 'Роллы', 
    price: 720, 
    description: 'Премиум ролл с угрем, сливочным сыром и огурцом', 
    available: true, 
    ingredients: [
      { ingredientId: 'i5', amount: 0.15 }, 
      { ingredientId: 'i22', amount: 0.06 }, // Угорь
      { ingredientId: 'i10', amount: 0.04 }, // Сливочный сыр
      { ingredientId: 'i27', amount: 0.02 }, // Огурец
      { ingredientId: 'i23', amount: 0.01 }  // Унаги
    ], 
    prepTime: 15,
    weight: 250
  },
  { 
    id: '12', 
    name: 'Пицца Гавайская', 
    category: 'Пицца', 
    price: 690, 
    description: 'Тропическое сочетание курицы и ананасов', 
    available: true, 
    ingredients: [
      { ingredientId: 'i7', amount: 0.25 }, 
      { ingredientId: 'i8', amount: 0.15 }, 
      { ingredientId: 'i33', amount: 0.1 },  // Курица
      { ingredientId: 'i37', amount: 0.08 }  // Ананас
    ], 
    prepTime: 15,
    weight: 480
  },
  { 
    id: '13', 
    name: 'Пицца Мясная', 
    category: 'Пицца', 
    price: 850, 
    description: 'Сытная пицца с беконом, ветчиной и пепперони', 
    available: true, 
    ingredients: [
      { ingredientId: 'i7', amount: 0.25 }, 
      { ingredientId: 'i8', amount: 0.12 }, 
      { ingredientId: 'i9', amount: 0.05 },  // Пепперони
      { ingredientId: 'i30', amount: 0.06 }, // Ветчина
      { ingredientId: 'i38', amount: 0.05 }  // Бекон
    ], 
    prepTime: 18,
    weight: 520
  },
  { 
    id: 'chef-special-dish', 
    name: 'Блюдо от шефа', 
    category: 'Горячее', 
    price: 1500, 
    description: 'Авторский шедевр от нашего шеф-повара. Набор ингредиентов держится в секрете.', 
    available: true, 
    ingredients: [], 
    prepTime: 30,
    weight: 450
  }
];

// Начальные данные ингредиентов
const initialIngredients: Ingredient[] = [
  { id: 'i5', name: 'Рис для суши', unit: 'кг', quantity: 15, minStock: 5, costPrice: 120 },
  { id: 'i6', name: 'Лосось', unit: 'кг', quantity: 5, minStock: 1, costPrice: 1800 },
  { id: 'i7', name: 'Тесто для пиццы', unit: 'кг', quantity: 10, minStock: 3, costPrice: 80 },
  { id: 'i8', name: 'Сыр Моцарелла', unit: 'кг', quantity: 7, minStock: 2, costPrice: 750 },
  { id: 'i9', name: 'Пепперони', unit: 'кг', quantity: 4, minStock: 1, costPrice: 950 },
  { id: 'i10', name: 'Сливочный сыр', unit: 'кг', quantity: 5, minStock: 1, costPrice: 600 },
  { id: 'i11', name: 'Нори', unit: 'уп', quantity: 20, minStock: 5, costPrice: 450 },
  { id: 'i12', name: 'Крабовое мясо', unit: 'кг', quantity: 3, minStock: 1, costPrice: 1200 },
  { id: 'i13', name: 'Авокадо', unit: 'кг', quantity: 2, minStock: 0.5, costPrice: 550 },
  { id: 'i14', name: 'Икра Тобико', unit: 'кг', quantity: 1, minStock: 0.2, costPrice: 2500 },
  { id: 'i15', name: 'Томатный соус', unit: 'кг', quantity: 10, minStock: 2, costPrice: 150 },
  { id: 'i16', name: 'Ягоды замороженные', unit: 'кг', quantity: 5, minStock: 1, costPrice: 400 },
  { id: 'i17', name: 'Лимон', unit: 'кг', quantity: 3, minStock: 1, costPrice: 180 },
  { id: 'i18', name: 'Мята свежая', unit: 'кг', quantity: 0.5, minStock: 0.1, costPrice: 1200 },
  { id: 'i19', name: 'Лайм', unit: 'кг', quantity: 2, minStock: 0.5, costPrice: 450 },
  { id: 'i20', name: 'Содовая', unit: 'л', quantity: 10, minStock: 2, costPrice: 60 },
  { id: 'i21', name: 'Апельсины', unit: 'кг', quantity: 10, minStock: 3, costPrice: 150 },
  { id: 'i22', name: 'Угорь копченый', unit: 'кг', quantity: 2, minStock: 0.5, costPrice: 2800 },
  { id: 'i23', name: 'Соус Унаги', unit: 'кг', quantity: 1, minStock: 0.2, costPrice: 850 },
  { id: 'i24', name: 'Сыр Пармезан', unit: 'кг', quantity: 2, minStock: 0.5, costPrice: 1400 },
  { id: 'i25', name: 'Сыр Горгонзола', unit: 'кг', quantity: 1, minStock: 0.3, costPrice: 1600 },
  { id: 'i26', name: 'Сыр Чеддер', unit: 'кг', quantity: 3, minStock: 0.5, costPrice: 900 },
  { id: 'i27', name: 'Огурцы свежие', unit: 'кг', quantity: 10, minStock: 2, costPrice: 150 },
  { id: 'i28', name: 'Кунжут', unit: 'кг', quantity: 2, minStock: 0.5, costPrice: 450 },
  { id: 'i29', name: 'Тигровые креветки', unit: 'кг', quantity: 3, minStock: 1, costPrice: 1600 },
  { id: 'i30', name: 'Ветчина', unit: 'кг', quantity: 5, minStock: 1, costPrice: 550 },
  { id: 'i31', name: 'Шампиньоны', unit: 'кг', quantity: 4, minStock: 1, costPrice: 350 },
  { id: 'i32', name: 'Болгарский перец', unit: 'кг', quantity: 3, minStock: 1, costPrice: 250 },
  { id: 'i33', name: 'Куриное филе', unit: 'кг', quantity: 8, minStock: 2, costPrice: 450 },
  { id: 'i34', name: 'Соевый соус', unit: 'л', quantity: 10, minStock: 2, costPrice: 200 },
  { id: 'i35', name: 'Имбирь маринованный', unit: 'кг', quantity: 3, minStock: 1, costPrice: 350 },
  { id: 'i36', name: 'Васаби', unit: 'кг', quantity: 1, minStock: 0.2, costPrice: 800 },
  { id: 'i37', name: 'Ананасы консерв.', unit: 'кг', quantity: 3, minStock: 1, costPrice: 280 },
  { id: 'i38', name: 'Бекон', unit: 'кг', quantity: 3, minStock: 1, costPrice: 850 },
  { id: 'i39', name: 'Маслины', unit: 'кг', quantity: 2, minStock: 0.5, costPrice: 400 },
  { id: 'i40', name: 'Лук красный', unit: 'кг', quantity: 2, minStock: 0.5, costPrice: 80 },
];

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export const logSystemError = async (message: string, component: string, stack?: string) => {
  try {
    const errId = `err_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    if (message?.includes('Quota exceeded') || message?.includes('quota') || message?.includes('resource-exhausted')) {
      console.warn("Muted quota exhausted logging to Firestore to preserve quota");
      return;
    }
    await setDoc(doc(db, 'system_errors', errId), {
      id: errId,
      message,
      component,
      stack: stack || Error().stack || 'No stack trace info',
      timestamp: Date.now(),
      status: 'active',
      userAgent: navigator.userAgent
    });
  } catch (e) {
    console.warn('Logging error to firestore failed:', e);
  }
};

export function handleFirestoreErrorGlobal(error: any, operationType: OperationType | string, path: string | null = null, onQuotaExceeded?: () => void) {
  if (error?.code === 'permission-denied' || error?.message?.includes('permission-denied') || error?.message?.toLowerCase().includes('permissions')) {
    console.warn(`Firestore permission warning muted for ${operationType} on "${path || 'unknown'}":`, error?.message || error);
    return;
  }

  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map((provider: any) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType: operationType as OperationType,
    path: path || 'unknown'
  };

  if (error?.code === 'resource-exhausted' || error?.message?.includes('Quota exceeded')) {
    if (onQuotaExceeded) onQuotaExceeded();
  }

  console.error('Firestore Error: ', JSON.stringify(errInfo));
  logSystemError(errInfo.error, `Firestore ${operationType} (${errInfo.path})`);
  
  if (operationType !== 'list' && operationType !== 'get' && operationType !== OperationType.LIST && operationType !== OperationType.GET) {
    throw new Error(JSON.stringify(errInfo));
  }
}

export function useCafeStore() {
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [staff, setStaff] = useState<Staff[]>(initialStaff);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [staffMessages, setStaffMessages] = useState<Message[]>([]);
  const [documents, setDocuments] = useState<ElectronicDocument[]>([]);
  const [cart, setCart] = useState<OrderItem[]>(() => {
    try {
      const saved = localStorage.getItem('cafe_cart');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.warn('LocalStorage is not available:', e);
      return [];
    }
  });
  const [notifications, setNotifications] = useState<Notification[]>(() => {
    try {
      const saved = localStorage.getItem('cafe_notifications');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.warn('LocalStorage is not available:', e);
      return [];
    }
  });

  const [currentUser, setCurrentUser] = useState<Staff | null>(() => {
    try {
      const saved = localStorage.getItem('cafe_user');
      if (!saved) return null;
      const user = JSON.parse(saved) as Staff;
      user.role = getEffectiveRole(user);
      return user;
    } catch (e) {
      return null;
    }
  });

  const [currentView, setView] = useState<View>(() => {
    try {
      const savedView = localStorage.getItem('cafe_current_view');
      if (savedView) return savedView as View;
      const savedUser = localStorage.getItem('cafe_user');
      if (!savedUser) return 'dashboard';
      const user = JSON.parse(savedUser) as Staff;
      const role = getEffectiveRole(user);
      if (role === 'chef' || role === 'bartender') return 'kitchen';
      if (role === 'waiter') return 'orders';
    } catch (e) {}
    return 'dashboard';
  });

  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem('cafe_theme');
      if (saved === 'dark' || saved === 'light') return saved;
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    } catch (e) {
      return 'light';
    }
  });

  const [loadingTimedOut, setLoadingTimedOut] = useState(false);
  const [quotaExceeded, setQuotaExceeded] = useState(false);
  const [isInitialDataChecked, setIsInitialDataChecked] = useState(false);
  const [isSystemOffline, setIsSystemOffline] = useState(false);

  // Помощник для сохранения данных в localStorage при превышении квоты
  const saveToLocalBackup = (key: string, data: any) => {
    try {
      const existing = localStorage.getItem(`backup_${key}`);
      const list = existing ? JSON.parse(existing) : [];
      localStorage.setItem(`backup_${key}`, JSON.stringify([...list, data]));
    } catch (e) {
      console.warn('Failed to save to local backup:', e);
    }
  };

  // Помощник для загрузки резервной копии
  const loadLocalBackup = <T>(key: string): T[] => {
    try {
      const data = localStorage.getItem(`backup_${key}`);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  };

  const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
  };

  const handleFirestoreError = (error: any, operationType: OperationType | string, path: string | null = null) => {
    handleFirestoreErrorGlobal(error, operationType, path, () => setQuotaExceeded(true));
  };

  const testConnection = useCallback(async () => {
    try {
      const { doc, getDocFromServer } = await import('firebase/firestore');
      await getDocFromServer(doc(db, 'system_test', 'connection'));
      console.log('Firebase connection test: SUCCESS');
    } catch (error) {
      if (error instanceof Error && (error.message.includes('offline') || error.message.includes('permission'))) {
        console.warn("Firebase connection test issues:", error.message);
      }
    }
  }, []);

  const [authInitialized, setAuthInitialized] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState(auth.currentUser);
  const [mappingSynced, setMappingSynced] = useState(false);

  useEffect(() => {
    testConnection();
    const unsub = onAuthStateChanged(auth, (user) => {
      setAuthInitialized(true);
      setFirebaseUser(user);
    });
    return () => unsub();
  }, [testConnection]);

  useEffect(() => {
    if (!db || !authInitialized) return;
    if (!firebaseUser) {
      setMappingSynced(false);
      return;
    }
    if (!currentUser) {
      setMappingSynced(true);
      return;
    }

    const syncMapping = async () => {
      try {
        await setDoc(doc(db, 'staff_uids', firebaseUser.uid), { staffId: currentUser.id }, { merge: true });
        setMappingSynced(true);
      } catch (err) {
        console.warn("Silent mapping sync in store failed:", err);
        setMappingSynced(true);
      }
    };
    syncMapping();
  }, [firebaseUser, currentUser?.id, authInitialized]);

  useEffect(() => {
    if (!db || !authInitialized) return;
    const unsubStatus = onSnapshot(doc(db, 'system_settings_v1', 'status'), (snap) => {
      if (snap.exists()) {
        setIsSystemOffline(!!snap.data().isOffline);
      } else {
        setIsSystemOffline(false);
      }
    }, (err) => {
      console.warn("Muted background error for system status settings:", err);
    });
    return () => unsubStatus();
  }, [authInitialized]);

  const setSystemOfflineStatus = useCallback(async (offline: boolean) => {
    if (quotaExceeded) return;
    try {
      await setDoc(doc(db, 'system_settings_v1', 'status'), { 
        isOffline: offline,
        updatedAt: Date.now(),
        updatedBy: currentUser?.name || 'developer'
      }, { merge: true });
      setIsSystemOffline(offline);
    } catch (e) {
      console.warn("Error updating system status:", e);
    }
  }, [quotaExceeded, currentUser]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!isInitialDataChecked) {
        console.warn("Initial data sync timed out, switching to local mode");
        setIsInitialDataChecked(true);
      }
    }, 5000); // Сокращен до 5 секунд
    return () => clearTimeout(timer);
  }, [isInitialDataChecked]);

  useEffect(() => {
    if (!db || !authInitialized || !firebaseUser || !mappingSynced) return;

    const role = currentUser ? getEffectiveRole(currentUser) : 'other';
    const isPrivileged = ['owner', 'admin', 'tech', 'developer', 'tester'].includes(role);
    const isKitchen = ['chef', 'bartender'].includes(role);
    const isStaff = role !== 'user' && role !== 'other';

    const unsubDishes = onSnapshot(collection(db, 'dishes'), (snap) => {
      const loaded = snap.docs.map(d => ({ id: d.id, ...d.data() } as Dish));
      if (loaded.length === 0 && !snap.metadata.fromCache && !quotaExceeded) {
        setDishes(initialDishes);
        const batch = writeBatch(db);
        initialDishes.forEach(d => batch.set(doc(db, 'dishes', d.id), d));
        batch.commit().catch(err => {
          handleFirestoreError(err, OperationType.WRITE, 'dishes');
        });
      } else {
        setDishes(loaded.length > 0 ? loaded : initialDishes);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'dishes');
      setDishes(prev => prev.length === 0 ? initialDishes : prev);
    });

    let unsubIngredients = () => {};
    if (isStaff || isPrivileged) {
      unsubIngredients = onSnapshot(collection(db, 'ingredients'), (snap) => {
        const loaded = snap.docs.map(d => ({ id: d.id, ...d.data() } as Ingredient));
        if (loaded.length === 0 && !snap.metadata.fromCache && !quotaExceeded) {
          setIngredients(initialIngredients);
          const batch = writeBatch(db);
          initialIngredients.forEach(i => batch.set(doc(db, 'ingredients', i.id), i));
          batch.commit().catch(err => handleFirestoreError(err, OperationType.WRITE, 'ingredients'));
        } else {
          setIngredients(loaded.length > 0 ? loaded : initialIngredients);
        }
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'ingredients');
        setIngredients(prev => prev.length === 0 ? initialIngredients : prev);
      });
    }

    let unsubStaff = () => {};
    if (!currentUser || isStaff || isPrivileged) {
      unsubStaff = onSnapshot(collection(db, 'staff'), (snap) => {
        const loaded = snap.docs.map(d => {
          let data = { id: d.id, ...d.data() } as Staff;
          if (data.login === 'salam' && data.role !== 'developer') {
            data = { ...data, role: 'developer', position: 'Разработчик' };
            setDoc(doc(db, 'staff', d.id), data, { merge: true }).catch(err => console.warn("Auto-updating salam to developer in Firestore failed:", err));
          }
          const role = getEffectiveRole(data);
          return { ...data, role };
        });
        
        setIsInitialDataChecked(true);
        
        // Always merge loaded staff documents with initialStaff defaults to guarantee accounts (like chef1, test, etc) are loginable.
        const merged = [...loaded];
        initialStaff.forEach(s => {
          if (!merged.some(m => m.login === s.login)) {
            merged.push(s);
          }
        });
        setStaff(merged);

        if (loaded.length === 0 && !quotaExceeded) {
          if (!snap.metadata.fromCache) {
            const batch = writeBatch(db);
            initialStaff.forEach(s => batch.set(doc(db, 'staff', s.id), s));
            batch.commit().catch(err => console.warn("Staff seeding failed:", err));
          }
        } else {
          const mustHaveLogins = initialStaff.map(s => s.login);
          const missingStaff = initialStaff.filter(s => 
            mustHaveLogins.includes(s.login) && 
            !loaded.some(l => l.login === s.login)
          );
          
          if (missingStaff.length > 0 && !snap.metadata.fromCache && !quotaExceeded) {
            const batch = writeBatch(db);
            missingStaff.forEach(s => batch.set(doc(db, 'staff', s.id), s));
            batch.commit().catch(err => console.warn("Staff restoration failed:", err));
          }
        }
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'staff');
        // On error, still merge active with initial staff so we have local accounts fallback
        setStaff(prev => {
          const merged = [...prev];
          initialStaff.forEach(s => {
            if (!merged.some(m => m.login === s.login)) {
              merged.push(s);
            }
          });
          return merged.length > 0 ? merged : initialStaff;
        });
        setIsInitialDataChecked(true);
      });
    } else {
      setIsInitialDataChecked(true);
    }

    let ordersQuery;
    if (isStaff || isPrivileged) {
      ordersQuery = query(collection(db, 'orders'), orderBy('timestamp', 'desc'), limit(100));
    } else {
      ordersQuery = query(collection(db, 'orders'), where('userId', '==', firebaseUser.uid), orderBy('timestamp', 'desc'), limit(50));
    }
    
    const unsubOrders = onSnapshot(ordersQuery, (snap) => {
      const loaded = snap.docs.map(d => ({ id: d.id, ...d.data() } as Order));
      setOrders(loaded);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'orders');
    });

    let unsubPromoCodes = () => {};
    if (isStaff || isPrivileged) {
      unsubPromoCodes = onSnapshot(collection(db, 'promoCodes'), (snap) => {
        const loaded = snap.docs.map(d => ({ id: d.id, ...d.data() } as PromoCode));
        setPromoCodes(loaded);
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'promoCodes');
      });
    }

    // Условные подписки для экономии трафика и ресурсов
    let unsubExpenses = () => {};
    if (isPrivileged || isKitchen) {
      unsubExpenses = onSnapshot(query(collection(db, 'expenses'), orderBy('timestamp', 'desc'), limit(100)), (snap) => {
        setExpenses(snap.docs.map(d => ({ id: d.id, ...d.data() } as Expense)));
      }, (error) => handleFirestoreError(error, OperationType.LIST, 'expenses'));
    }

    let unsubLogs = () => {};
    if (isPrivileged) {
      unsubLogs = onSnapshot(query(collection(db, 'logs'), orderBy('timestamp', 'desc'), limit(100)), (snap) => {
        setLogs(snap.docs.map(d => ({ id: d.id, ...d.data() } as ActivityLog)));
      }, (error) => handleFirestoreError(error, OperationType.LIST, 'logs'));
    }

    let unsubNotifications = () => {};
    let notificationsQuery;
    if (isStaff || isPrivileged) {
      notificationsQuery = query(collection(db, 'notifications'), orderBy('timestamp', 'desc'), limit(100));
    } else {
      notificationsQuery = query(collection(db, 'notifications'), where('targetUserId', '==', firebaseUser.uid), orderBy('timestamp', 'desc'), limit(50));
    }

    unsubNotifications = onSnapshot(notificationsQuery, (snap) => {
      setNotifications(snap.docs.map(d => ({ id: d.id, ...d.data() } as Notification)));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'notifications'));

    let unsubTickets = () => {};
    if (isPrivileged || isStaff) {
      unsubTickets = onSnapshot(query(collection(db, 'tickets'), orderBy('timestamp', 'desc'), limit(100)), (snap) => {
        setTickets(snap.docs.map(d => ({ id: d.id, ...d.data() } as Ticket)));
      }, (error) => handleFirestoreError(error, OperationType.LIST, 'tickets'));
    } else {
      unsubTickets = onSnapshot(query(collection(db, 'tickets'), where('creatorId', '==', firebaseUser.uid), orderBy('timestamp', 'desc'), limit(50)), (snap) => {
        setTickets(snap.docs.map(d => ({ id: d.id, ...d.data() } as Ticket)));
      }, (error) => handleFirestoreError(error, OperationType.LIST, 'tickets'));
    }

    let unsubChatRooms = () => {};
    if (isStaff) {
      unsubChatRooms = onSnapshot(query(collection(db, 'chatRooms'), orderBy('lastMessageTimestamp', 'desc')), (snap) => {
        setChatRooms(snap.docs.map(d => ({ id: d.id, ...d.data() } as ChatRoom)));
      }, (error) => handleFirestoreError(error, OperationType.LIST, 'chatRooms'));
    }

    let unsubStaffChat = () => {};
    if (isStaff) {
      unsubStaffChat = onSnapshot(query(collection(db, 'staffChat'), orderBy('timestamp', 'asc'), limit(100)), (snap) => {
        setStaffMessages(snap.docs.map(d => ({ id: d.id, ...d.data() } as Message)));
      }, (error) => handleFirestoreError(error, OperationType.LIST, 'staffChat'));
    }

    let unsubDocuments = () => {};
    if (isStaff) {
      unsubDocuments = onSnapshot(query(collection(db, 'documents'), orderBy('createdAt', 'desc')), (snap) => {
        setDocuments(snap.docs.map(d => ({ id: d.id, ...d.data() } as ElectronicDocument)));
      }, (error) => handleFirestoreError(error, OperationType.LIST, 'documents'));
    }

    return () => {
      unsubDishes();
      unsubIngredients();
      unsubStaff();
      unsubOrders();
      unsubPromoCodes();
      unsubExpenses();
      unsubLogs();
      unsubNotifications();
      unsubTickets();
      unsubChatRooms();
      unsubStaffChat();
      unsubDocuments();
    };
  }, [quotaExceeded, firebaseUser, authInitialized, currentUser?.id, mappingSynced]);

  // Real-time listener specifically for the logged in user document to ensure updates propagate (e.g. password changes, avatars, positions)
  useEffect(() => {
    if (!db || !currentUser?.id || !authInitialized) return;

    const userRef = doc(db, 'staff', currentUser.id);
    const unsub = onSnapshot(userRef, (snap) => {
      if (snap.exists()) {
        const data = { id: snap.id, ...snap.data() } as Staff;
        const role = getEffectiveRole(data);
        const updatedUser = { ...data, role };
        
        // Only trigger state update if there is an actual difference (prevent rendering loops)
        setCurrentUser(prev => {
          if (!prev) return updatedUser;
          const hasDiff = 
            prev.name !== updatedUser.name ||
            prev.password !== updatedUser.password ||
            prev.phone !== updatedUser.phone ||
            prev.login !== updatedUser.login ||
            prev.avatarUrl !== updatedUser.avatarUrl ||
            prev.role !== updatedUser.role ||
            prev.position !== updatedUser.position;
            
          if (hasDiff) {
            localStorage.setItem('cafe_user', JSON.stringify(updatedUser));
            return updatedUser;
          }
          return prev;
        });
      } else {
        // Clear ghost/deleted staff session
        console.warn("Current user staff document does not exist on database, logging out.");
        setCurrentUser(null);
        localStorage.removeItem('cafe_user');
      }
    }, (error) => {
      console.warn("Real-time profile sync error:", error);
      if (error && error.message && (error.message.includes('permission') || error.message.includes('Permission'))) {
        setCurrentUser(null);
        localStorage.removeItem('cafe_user');
      }
    });

    return () => unsub();
  }, [currentUser?.id, authInitialized]);

  // Синхронизация состояний с localStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('cafe_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('cafe_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('cafe_current_view', currentView);
  }, [currentView]);

  useEffect(() => {
    localStorage.setItem('cafe_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Синхронизация корзины с localStorage
  useEffect(() => {
    localStorage.setItem('cafe_cart', JSON.stringify(cart));
  }, [cart]);

  const updateStaffProfile = useCallback(async (staffId: string, updates: Partial<Staff>) => {
    if (quotaExceeded) return;
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'staff', staffId), updates, { merge: true });
      
      // If we are updating firebaseUid, we must sync the mapping
      const fuid = updates.firebaseUid || (updates as any).uid;
      if (fuid && typeof fuid === 'string') {
        batch.set(doc(db, 'staff_uids', fuid), { staffId }, { merge: true });
      }
      
      await batch.commit();

      // Immediate state and localStorage update fallback for the current user
      setCurrentUser(prev => {
        if (prev && prev.id === staffId) {
          const updated = { ...prev, ...updates };
          try {
            localStorage.setItem('cafe_user', JSON.stringify(updated));
          } catch (e) {}
          return updated;
        }
        return prev;
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'staff');
    }
  }, [quotaExceeded]);

  const addNotification = useCallback(async (notif: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    const id = generateId();
    const newNotif: Notification = {
      targetRoles: ['owner', 'admin', 'tech'], // Роли по умолчанию
      ...notif,
      id,
      timestamp: Date.now(),
      read: false
    };
    // Оптимистичное обновление
    setNotifications(prev => [newNotif, ...prev]);
    // Сохранение в Firestore
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'notifications', id), newNotif);
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, 'notifications');
        saveToLocalBackup('notifications', newNotif);
      }
    } else {
      saveToLocalBackup('notifications', newNotif);
    }
  }, [quotaExceeded]);

  const markNotificationRead = useCallback(async (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    if (quotaExceeded) return;
    try {
      await setDoc(doc(db, 'notifications', id), { read: true }, { merge: true });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'notifications');
    }
  }, [quotaExceeded]);

  const markAllNotificationsRead = useCallback(async () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    if (quotaExceeded) return;
    try {
      const unread = notifications.filter(n => !n.read);
      if (unread.length === 0) return;
      const batch = writeBatch(db);
      unread.forEach(n => {
        batch.set(doc(db, 'notifications', n.id), { read: true }, { merge: true });
      });
      await batch.commit();
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'notifications');
    }
  }, [quotaExceeded, notifications]);

  const clearNotifications = useCallback(async () => {
    setNotifications([]);
    if (quotaExceeded) return;
    try {
      const batch = writeBatch(db);
      const snap = await getDocs(collection(db, 'notifications'));
      snap.docs.forEach(d => batch.delete(d.ref));
      await batch.commit();
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, 'notifications');
    }
  }, [quotaExceeded]);

  const clearOrders = useCallback(async () => {
    // Оптимистичная очистка в UI
    setOrders([]);
    if (quotaExceeded) return;
    try {
      const ordersSnap = await getDocs(collection(db, 'orders'));
      const batch = writeBatch(db);
      ordersSnap.docs.forEach(d => {
        batch.delete(d.ref);
      });
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'orders');
    }
  }, [quotaExceeded]);

  const logAction = useCallback(async (user: Staff, action: string, details?: string) => {
    const newLog: ActivityLog = {
      id: generateId(),
      userId: user.id || 'anonymous',
      userName: user.name,
      userRole: getEffectiveRole(user),
      action,
      details,
      timestamp: Date.now()
    };
    // Оптимистичное обновление
    setLogs(prev => [newLog, ...prev]);
    if (quotaExceeded) {
      if (user) {
        saveToLocalBackup('logs', newLog);
      }
      return;
    }

    try {
      await setDoc(doc(db, 'logs', newLog.id), newLog);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'logs');
      saveToLocalBackup('logs', newLog);
    }
  }, [quotaExceeded]);

  const lastOrderTimeRef = useRef<Record<string, number>>({});

  const addOrder = useCallback(async (order: Order, user?: Staff) => {
    const orderKey = `${order.tableNumber}-${order.total}-${order.items.length}`;
    const now = Date.now();
    if (lastOrderTimeRef.current[orderKey] && now - lastOrderTimeRef.current[orderKey] < 5000) {
      return '';
    }
    lastOrderTimeRef.current[orderKey] = now;

    let lastNum = 0;
    if (orders.length > 0) {
      const nums = orders.map(o => parseInt(o.orderNumber || '0')).filter(n => !isNaN(n));
      if (nums.length > 0) {
        lastNum = Math.max(...nums);
      }
    }
    
    const nextNum = lastNum > 0 ? lastNum + 1 : orders.length + 1;
    const orderWithNumber: Order = {
      ...order,
      orderNumber: `${nextNum.toString().padStart(4, '0')}`,
      subtotal: order.subtotal || order.total,
      promoCode: order.promoCode || '', // Ensure no undefined
      discountTotal: order.discountTotal || 0,
    };
    
    // 1. Оптимистичное списание ингредиентов
    const updatedIngredients = ingredients.map(ing => {
      let usedAmount = 0;
      order.items.forEach(item => {
        const dish = dishes.find(d => d.id === item.dishId);
        const recipeItem = dish?.ingredients.find(ri => ri.ingredientId === ing.id);
        if (recipeItem) {
          usedAmount += recipeItem.amount * item.quantity;
        }
      });
      if (usedAmount === 0) return ing;
      const newQuantity = Number(Math.max(0, ing.quantity - usedAmount).toFixed(3));
      return { ...ing, quantity: newQuantity };
    });
    
    setIngredients(updatedIngredients);
    
    // 2. Оптимистичное обновление в UI
    setOrders(prev => [orderWithNumber, ...prev]);
    
    // 3. Сохранение в Firestore с использованием transaction для атомарности финансов
    if (!quotaExceeded) {
      try {
        await runTransaction(db, async (txn) => {
          // --- 1. COLLECT ALL DATA (READS) ---
          let walletData: Wallet | null = null;
          let walletRef = null;
          if (order.userId) {
            walletRef = doc(db, 'wallets', order.userId);
            const walletSnap = await txn.get(walletRef);
            if (walletSnap.exists()) {
              walletData = walletSnap.data() as Wallet;
            } else {
              // Авто-создание кошелька для нового пользователя
              walletData = {
                id: order.userId,
                balance: 0,
                bonusBalance: 0,
                virtualCard: { id: 'CARD-' + order.userId.substring(0, 4), token: Math.random().toString().slice(2, 18), isActive: true },
                lastUpdate: now
              };
            }
          }

          let promoData = null;
          let promoRef = null;
          if (order.promoCode) {
            const promo = promoCodes.find(p => p.code === order.promoCode);
            if (promo) {
              promoRef = doc(db, 'promoCodes', promo.id);
              const pSnap = await txn.get(promoRef);
              if (pSnap.exists()) {
                promoData = pSnap.data();
              }
            }
          }

          // --- 2. APPLY CHANGES (WRITES) ---
          
          // If wallet didn't exist, we create it
          if (order.userId && walletRef && !walletData?.lastUpdate) {
             txn.set(walletRef, walletData);
          }

          // Добавление заказа
          txn.set(doc(db, 'orders', orderWithNumber.id), orderWithNumber);
          
          // Обновление промокода
          if (promoRef && promoData) {
            txn.update(promoRef, { usageCount: (promoData.usageCount || 0) + 1 });
          }
          
          // Обновление ингредиентов
          updatedIngredients.forEach((ing, idx) => {
            if (ing.quantity !== ingredients[idx].quantity) {
              txn.set(doc(db, 'ingredients', ing.id), ing);
            }
          });

          // Финансовая часть
          if (walletData && walletRef) {
            const appliedBonuses = order.appliedBonuses || 0;
            const isWalletPayment = order.paymentMethod === 'wallet';
            const kopeksToDeduct = isWalletPayment ? (order.total * 100) : 0;
            
            // Начисление бонусов (5% от суммы оплаты, исключая бонусы)
            const pointsToEarn = calculateLoyaltyPoints(kopeksToDeduct || (order.total * 100)); // Начисляем за любую оплату, если привязан аккаунт
            
            txn.update(walletRef, {
              balance: walletData.balance - kopeksToDeduct,
              bonusBalance: walletData.bonusBalance - appliedBonuses + pointsToEarn,
              lastUpdate: now
            });

            // Лог транзакций
            if (kopeksToDeduct > 0) {
              txn.set(doc(collection(db, 'walletTransactions')), {
                userId: order.userId,
                type: 'payment',
                amount: -kopeksToDeduct,
                status: 'success',
                description: `Оплата заказа №${orderWithNumber.orderNumber}`,
                orderId: orderWithNumber.id,
                timestamp: now,
                idempotencyKey: `pay_${orderWithNumber.id}`
              });
            }

            if (appliedBonuses > 0) {
              txn.set(doc(collection(db, 'walletTransactions')), {
                userId: order.userId,
                type: 'bonus_redeem',
                amount: 0,
                bonusAmount: -appliedBonuses,
                status: 'success',
                description: `Списание бонусов за заказ №${orderWithNumber.orderNumber}`,
                orderId: orderWithNumber.id,
                timestamp: now,
                idempotencyKey: `redeem_${orderWithNumber.id}`
              });
            }

            if (pointsToEarn > 0) {
              txn.set(doc(collection(db, 'walletTransactions')), {
                userId: order.userId,
                type: 'bonus_earn',
                amount: 0,
                bonusAmount: pointsToEarn,
                status: 'success',
                description: `Начисление за заказ №${orderWithNumber.orderNumber}`,
                orderId: orderWithNumber.id,
                timestamp: now,
                idempotencyKey: `earn_${orderWithNumber.id}`
              });
            }
          }
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, 'orders');
        saveToLocalBackup('orders', orderWithNumber);
      }
    } else {
      saveToLocalBackup('orders', orderWithNumber);
    }

    if (user) {
      logAction(user, 'Создание заказа', `Заказ №${orderWithNumber.orderNumber} для стола №${order.tableNumber}`);
    }

    addNotification({
      title: 'Новый заказ',
      message: `Поступил заказ №${orderWithNumber.orderNumber} для стола №${order.tableNumber} на сумму ${order.total} ₽`,
      type: 'order',
      targetRoles: ['owner', 'admin', 'chef', 'bartender', 'waiter', 'tech']
    });

    return orderWithNumber.orderNumber;
  }, [quotaExceeded, orders, promoCodes, logAction, addNotification, ingredients, dishes, currentUser]);

  const clearKitchenOrders = useCallback(async () => {
    // Оптимистичное удаление
    const activeStatuses = ['pending', 'cooking', 'ready'];
    setOrders(prev => prev.filter(o => !activeStatuses.includes(o.status)));
    
    if (quotaExceeded) return;
    try {
      const q = query(collection(db, 'orders'), where('status', 'in', activeStatuses));
      const snap = await getDocs(q);
      const batch = writeBatch(db);
      snap.docs.forEach(d => batch.delete(d.ref));
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'orders');
    }
  }, [quotaExceeded]);

  const updateOrderStatus = useCallback(async (orderId: string, status: Order['status'], user?: Staff) => {
    // Optimistic
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));

    const existingOrder = orders.find(o => o.id === orderId);
    if (!existingOrder) return;

    if (quotaExceeded) {
      if (user) {
        const statusLabels: Record<string, string> = {
          'cooking': 'Начало готовки',
          'ready': 'Готов к выдаче',
          'completed': 'Заказ выдан',
          'cancelled': 'Заказ отменен'
        };
        logAction(user, statusLabels[status] || `Статус заказа: ${status}`, `Заказ №${existingOrder.orderNumber} (ЛОКАЛЬНО)`);
      }
      return;
    }

    const updatedOrder = { ...existingOrder, status };
    try {
      await setDoc(doc(db, 'orders', orderId), updatedOrder);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'orders');
    }

    if (user) {
      const statusLabels: Record<string, string> = {
        'cooking': 'Начало готовки',
        'ready': 'Готов к выдаче',
        'completed': 'Заказ выдан',
        'cancelled': 'Заказ отменен'
      };
      logAction(user, statusLabels[status] || `Статус заказа: ${status}`, `Заказ №${existingOrder.orderNumber}`);
    }

    // Handle refund if cancelled and was paid by wallet or bonuses
    if (status === 'cancelled' && existingOrder.status !== 'cancelled' && existingOrder.userId && !quotaExceeded) {
      try {
        await runTransaction(db, async (txn) => {
          const walletRef = doc(db, 'wallets', existingOrder.userId!);
          const walletSnap = await txn.get(walletRef);
          
          if (walletSnap.exists()) {
            const walletData = walletSnap.data() as Wallet;
            const isWalletPayment = existingOrder.paymentMethod === 'wallet';
            const refundAmount = isWalletPayment ? (existingOrder.total * 100) : 0;
            const refundBonuses = existingOrder.appliedBonuses || 0;
            
            // Revert points earned from this order
            // If points were earned for any payout, we must revert them
            const pointsEarnedToRevert = calculateLoyaltyPoints(refundAmount || (existingOrder.total * 100));

            txn.update(walletRef, {
              balance: walletData.balance + refundAmount,
              bonusBalance: Math.max(0, (walletData.bonusBalance || 0) + refundBonuses - pointsEarnedToRevert),
              lastUpdate: Date.now()
            });

            // Log transactions
            if (refundAmount > 0) {
              txn.set(doc(collection(db, 'walletTransactions')), {
                userId: existingOrder.userId,
                type: 'refund',
                amount: refundAmount,
                status: 'success',
                description: `Возврат средств за заказ №${existingOrder.orderNumber}`,
                orderId: existingOrder.id,
                timestamp: Date.now(),
                idempotencyKey: `ref_cash_${existingOrder.id}`
              });
            }

            if (refundBonuses > 0) {
              txn.set(doc(collection(db, 'walletTransactions')), {
                userId: existingOrder.userId,
                type: 'bonus_earn',
                amount: 0,
                bonusAmount: refundBonuses,
                status: 'success',
                description: `Возврат бонусов за заказ №${existingOrder.orderNumber}`,
                orderId: existingOrder.id,
                timestamp: Date.now(),
                idempotencyKey: `ref_bon_${existingOrder.id}`
              });
            }

            if (pointsEarnedToRevert > 0) {
              txn.set(doc(collection(db, 'walletTransactions')), {
                userId: existingOrder.userId,
                type: 'bonus_redeem',
                amount: 0,
                bonusAmount: -pointsEarnedToRevert,
                status: 'success',
                description: `Отмена начисления за заказ №${existingOrder.orderNumber}`,
                orderId: existingOrder.id,
                timestamp: Date.now(),
                idempotencyKey: `ref_earn_${existingOrder.id}`
              });
            }
          }
        });
      } catch (err) {
        console.error('Refund failed:', err);
      }
    }
    let statusText = '';
    switch(status) {
      case 'cooking': statusText = 'начал готовиться'; break;
      case 'ready': statusText = 'готов к выдаче'; break;
      case 'completed': statusText = 'завершен'; break;
      case 'cancelled': statusText = 'отменен'; break;
    }

    if (user) {
      logAction(user, 'Смена статуса заказа', `Заказ №${existingOrder.orderNumber} статус: ${statusText}`);
    }
    
    addNotification({
      title: 'Статус заказа изменен',
      message: `Заказ для стола №${existingOrder.tableNumber} ${statusText}`,
      type: 'status',
      targetRoles: ['owner', 'admin', 'chef', 'bartender', 'waiter', 'tech']
    });
  }, [quotaExceeded, orders, logAction, addNotification]);

  const addExpense = useCallback(async (expense: Expense) => {
    // Optimistic
    setExpenses(prev => [expense, ...prev]);
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'expenses', expense.id), expense);
      } catch (e) {
        handleFirestoreError(e, 'Add Expense');
        saveToLocalBackup('expenses', expense);
      }
    } else {
      saveToLocalBackup('expenses', expense);
    }
    addNotification({
      title: 'Новый расход',
      message: `Зарегистрирован расход: ${expense.description} на сумму ${expense.amount} ₽`,
      type: 'inventory',
      targetRoles: ['owner', 'admin', 'chef', 'bartender', 'tech']
    });
  }, [quotaExceeded, addNotification]);

  const updateDish = useCallback(async (dish: Dish) => {
    // Optimistic
    setDishes(prev => {
      const exists = prev.find(d => d.id === dish.id);
      if (exists) return prev.map(d => d.id === dish.id ? dish : d);
      return [...prev, dish];
    });
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'dishes', dish.id), dish);
      } catch (e) {
        handleFirestoreError(e, 'Update Dish');
      }
    }
  }, [quotaExceeded]);

  const deleteDish = useCallback(async (id: string) => {
    // Optimistic
    setDishes(prev => prev.filter(d => d.id !== id));
    if (!quotaExceeded) {
      try {
        await deleteDoc(doc(db, 'dishes', id));
      } catch (e) {
        handleFirestoreError(e, 'Delete Dish');
      }
    }
  }, [quotaExceeded]);

  const updateIngredient = useCallback(async (ing: Ingredient) => {
    // Optimistic
    setIngredients(prev => {
      const exists = prev.find(i => i.id === ing.id);
      if (exists) return prev.map(i => i.id === ing.id ? ing : i);
      return [...prev, ing];
    });
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'ingredients', ing.id), ing);
      } catch (e) {
        handleFirestoreError(e, 'Update Ingredient');
      }
    }
  }, [quotaExceeded]);

  const deleteIngredient = useCallback(async (id: string) => {
    // Optimistic
    setIngredients(prev => prev.filter(i => i.id !== id));
    if (!quotaExceeded) {
      try {
        await deleteDoc(doc(db, 'ingredients', id));
      } catch (e) {
        handleFirestoreError(e, 'Delete Ingredient');
      }
    }
  }, [quotaExceeded]);

  const updateStaff = useCallback(async (member: Staff) => {
    // Optimistic update to UI
    setStaff(prev => {
      const exists = prev.some(s => s.id === member.id);
      if (exists) return prev.map(s => s.id === member.id ? member : s);
      return [...prev, member];
    });
    // Instant save to DB
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'staff', member.id), member);
      } catch (e) {
        handleFirestoreError(e, 'Update Staff');
      }
    }
  }, [quotaExceeded]);

  const deleteStaff = useCallback(async (id: string) => {
    // Optimistic
    setStaff(prev => prev.filter(s => s.id !== id));
    if (!quotaExceeded) {
      try {
        await deleteDoc(doc(db, 'staff', id));
      } catch (e) {
        handleFirestoreError(e, 'Delete Staff');
      }
    }
  }, [quotaExceeded]);

  const updatePromoCode = useCallback(async (promo: PromoCode) => {
    setPromoCodes(prev => {
      const exists = prev.find(p => p.id === promo.id);
      if (exists) return prev.map(p => p.id === promo.id ? promo : p);
      return [...prev, promo];
    });
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'promoCodes', promo.id), promo);
      } catch (e) {
        handleFirestoreError(e, 'Update Promo');
      }
    }
  }, [quotaExceeded]);

  const deletePromoCode = useCallback(async (id: string) => {
    setPromoCodes(prev => prev.filter(p => p.id !== id));
    if (!quotaExceeded) {
      try {
        await deleteDoc(doc(db, 'promoCodes', id));
      } catch (e) {
        handleFirestoreError(e, 'Delete Promo');
      }
    }
  }, [quotaExceeded]);

  const addTicket = useCallback(async (ticket: Omit<Ticket, 'id' | 'ticketNumber' | 'timestamp' | 'updatedAt' | 'comments'>) => {
    const id = generateId();
    let lastNum = 0;
    if (tickets.length > 0) {
      const nums = tickets.map(t => parseInt(t.ticketNumber || '0')).filter(n => !isNaN(n));
      if (nums.length > 0) lastNum = Math.max(...nums);
    }
    const nextNum = (lastNum + 1).toString().padStart(4, '0');

    const newTicket: Ticket = {
      ...ticket,
      id,
      ticketNumber: nextNum,
      timestamp: Date.now(),
      updatedAt: Date.now(),
      comments: []
    };

    setTickets(prev => [newTicket, ...prev]);
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'tickets', id), newTicket);
      } catch (e) {
        handleFirestoreError(e, 'Add Ticket');
        saveToLocalBackup('tickets', newTicket);
      }
    } else {
      saveToLocalBackup('tickets', newTicket);
    }

    addNotification({
      title: 'Новый тикет',
      message: `Создан тикет №${nextNum}: ${ticket.title}`,
      type: 'ticket',
      targetRoles: ['owner', 'admin', 'tech', 'tester', 'developer']
    });

    return nextNum;
  }, [quotaExceeded, tickets, addNotification]);

  const updateTicket = useCallback(async (ticketId: string, updates: Partial<Ticket>, user?: Staff) => {
    const existing = tickets.find(t => t.id === ticketId);
    if (!existing) return;

    let finalUpdates = { ...updates };
    
    // Автоматическое назначение при переводе в работу
    if (updates.status === 'investigating' && user && !existing.assignedToId) {
      finalUpdates.assignedToId = user.id;
      finalUpdates.assignedToName = user.login;
    }

    const updatedComments = [...existing.comments];
    
    if (updates.status && updates.status !== existing.status) {
      const statusNames: Record<string, string> = {
        'new': 'Новый',
        'investigating': 'В работе',
        'commented': 'Есть ответ',
        'resolved': 'Решен',
        'closed': 'Закрыт',
        'archived': 'В архиве'
      };

      updatedComments.push({
        id: generateId(),
        text: `🤖 Статус тикета изменен на: ${statusNames[updates.status] || updates.status}`,
        authorId: 'system-bot',
        authorName: 'Системный Бот',
        timestamp: Date.now()
      });

      const fullStatusNames: Record<string, string> = {
        'new': 'Новый',
        'investigating': 'В работе (специалист приступил к изучению)',
        'commented': 'Получен ответ',
        'resolved': 'Решен (проблема устранена)',
        'closed': 'Закрыт',
        'archived': 'В архиве'
      };

      const botMessage = {
        senderId: 'bot',
        senderName: 'Техническая поддержка',
        senderRole: 'tech',
        text: `🤖 Обновление по вашему тикету №${existing.ticketNumber}: Статус изменен на "${fullStatusNames[updates.status] || updates.status}".`,
        timestamp: Date.now(),
        isBot: true,
        targetUserId: existing.creatorId
      };
      
      if (!quotaExceeded) {
        await addDoc(collection(db, 'messages'), botMessage).catch(e => handleFirestoreError(e, 'Bot Message Status', 'messages'));
      }
      
      // Уведомление для пользователя
      addNotification({
        title: 'Обновление тикета',
        message: `Статус тикета №${existing.ticketNumber} изменен на: ${statusNames[updates.status] || updates.status}`,
        type: 'ticket',
        targetUserId: existing.creatorId
      });
 
      // Специальная обработка завершения
      if (updates.status === 'resolved') {
        const resolutionMessage = {
          senderId: 'bot',
          senderName: 'Техническая поддержка',
          senderRole: 'tech',
          text: `✅ Проблема по тикету №${existing.ticketNumber} решена. Тикет закрыт. Если у вас возникнут другие вопросы, пожалуйста, создайте новое обращение.`,
          timestamp: Date.now() + 100,
          isBot: true,
          targetUserId: existing.creatorId
        };
        if (!quotaExceeded) {
          await addDoc(collection(db, 'messages'), resolutionMessage).catch(e => handleFirestoreError(e, 'Bot Message Resolution'));
        }
      }
    }
 
    // Сообщение бота для devComment обновлений (Что было сделано)
    if (updates.devComment && updates.devComment !== existing.devComment) {
       if (!quotaExceeded) {
         await addDoc(collection(db, 'messages'), {
           senderId: 'bot',
           senderName: 'Техническая поддержка',
           senderRole: 'tech',
           text: `🔧 По вашему тикету №${existing.ticketNumber} выполнены работы: "${updates.devComment}"`,
           timestamp: Date.now(),
           isBot: true,
           targetUserId: existing.creatorId
         }).catch(e => handleFirestoreError(e, 'Bot Message Work Done'));
       }
 
       addNotification({
         title: 'Обновление работ по тикету',
         message: `В тикете №${existing.ticketNumber} указано, что было сделано.`,
         type: 'ticket',
         targetUserId: existing.creatorId
       });
    }

    const updated: Ticket = {
      ...existing,
      ...finalUpdates,
      comments: updatedComments,
      updatedAt: Date.now()
    };

    setTickets(prev => prev.map(t => t.id === ticketId ? updated : t));
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'tickets', ticketId), updated);
      } catch (e) {
        handleFirestoreError(e, 'Update Ticket');
      }
    }
  }, [quotaExceeded, tickets, addNotification]);

  const archiveTicket = useCallback(async (ticketId: string) => {
    await updateTicket(ticketId, { status: 'archived' });
  }, [updateTicket]);

  const markTicketAsRead = useCallback(async (ticketId: string, userId: string) => {
    const existing = tickets.find(t => t.id === ticketId);
    if (!existing) return;

    let needsUpdate = false;
    let newStatus = existing.status;
    
    // Очистка статуса "commented", если человек, который прочитал, скорее всего тот, кому нужен ответ
    if (existing.status === 'commented') {
      newStatus = 'investigating';
      needsUpdate = true;
    }

    const updatedComments = existing.comments.map(c => {
      if (c.authorId !== userId && !c.readAt) {
        needsUpdate = true;
        return { ...c, readAt: Date.now() };
      }
      return c;
    });

    if (needsUpdate) {
      const updated: Ticket = {
        ...existing,
        comments: updatedComments,
        status: newStatus,
        updatedAt: Date.now()
      };
      setTickets(prev => prev.map(t => t.id === ticketId ? updated : t));
      if (!quotaExceeded) {
        try {
          await setDoc(doc(db, 'tickets', ticketId), updated);
        } catch (e) {
           handleFirestoreError(e, 'Mark Ticket Read', `tickets/${ticketId}`);
        }
      }
    }
  }, [quotaExceeded, tickets]);

  const addTicketComment = useCallback(async (ticketId: string, text: string, user: Staff) => {
    const existing = tickets.find(t => t.id === ticketId);
    if (!existing) return;

    const comment: TicketComment = {
      id: generateId(),
      authorId: user.id,
      authorName: user.name,
      authorRole: getEffectiveRole(user),
      text,
      timestamp: Date.now()
    };

    const updated: Ticket = {
      ...existing,
      comments: [...existing.comments, comment],
      status: 'commented',
      updatedAt: Date.now()
    };

    setTickets(prev => prev.map(t => t.id === ticketId ? updated : t));
    if (!quotaExceeded) {
       try {
         await setDoc(doc(db, 'tickets', ticketId), updated);
       } catch (e) {
         handleFirestoreError(e, 'Add Ticket Comment');
       }
    }

    addNotification({
      title: 'Новый комментарий в тикете',
      message: `${user.name} ответил в тикете №${existing.ticketNumber}`,
      type: 'ticket',
      targetRoles: ['owner', 'admin', 'tech', 'tester', 'developer'],
      targetUserId: existing.creatorId === user.id ? undefined : existing.creatorId // Уведомляем создателя, если ответил кто-то другой
    });

    // Синхронизация уведомления в чат пользователя, если это ответ техподдержки
    const userRole = getEffectiveRole(user);
    const isSupport = ['owner', 'admin', 'tech', 'developer'].includes(userRole);
    
    if (isSupport && existing.creatorId !== user.id) {
       if (!quotaExceeded) {
         try {
           await addDoc(collection(db, 'messages'), {
             senderId: 'bot',
             senderName: 'Техническая поддержка',
             senderRole: 'tech',
             text: `🤖 В вашем тикете №${existing.ticketNumber} появился новый комментарий от ${user.name}: "${text.substring(0, 100)}${text.length > 100 ? '...' : ''}"`,
             timestamp: Date.now(),
             isBot: true,
             targetUserId: existing.creatorId
           });
         } catch (e) {
           handleFirestoreError(e, 'Bot Support Message');
         }
       }
    }
  }, [quotaExceeded, tickets, addNotification]);

  const sendStaffMessage = useCallback(async (roomId: string, text: string, user: Staff, options?: { imageUrl?: string; type?: Message['type']; fileUrl?: string; fileName?: string; duration?: number }) => {
    const id = generateId();
    const newMessage: any = {
      id,
      roomId,
      senderId: user.id,
      senderName: user.name,
      senderRole: getEffectiveRole(user),
      text,
      timestamp: Date.now(),
      type: options?.type || 'text',
      readBy: [user.id]
    };

    if (options?.imageUrl) newMessage.imageUrl = options.imageUrl;
    if (options?.fileUrl) newMessage.fileUrl = options.fileUrl;
    if (options?.fileName) newMessage.fileName = options.fileName;
    if (options?.duration) newMessage.duration = options.duration;

    try {
      if (!quotaExceeded) {
        const batch = writeBatch(db);
        batch.set(doc(db, 'staffChat', id), newMessage);
        batch.set(doc(db, 'chatRooms', roomId), {
          lastMessage: options?.type === 'voice' ? '🎤 Голосовое сообщение' : (options?.type === 'file' ? `📎 Файл: ${options.fileName}` : text.substring(0, 50)),
          lastMessageTimestamp: Date.now()
        }, { merge: true });
        
        await batch.commit();
      } else {
        saveToLocalBackup('staffChat', newMessage);
      }
    } catch (e) {
      handleFirestoreError(e, 'Send Chat Message');
      saveToLocalBackup('staffChat', newMessage);
    }
    
    addNotification({
      title: 'Сообщение в чате',
      message: `${user.name}: ${text.substring(0, 30)}${text.length > 30 ? '...' : ''}`,
      type: 'chat',
      targetRoles: ['owner', 'admin', 'tech', 'chef', 'waiter', 'bartender', 'tester', 'developer']
    });
  }, [quotaExceeded, addNotification]);

  const updateChatRoom = useCallback(async (roomId: string, updates: Partial<ChatRoom>) => {
    if (quotaExceeded) return;
    try {
      await setDoc(doc(db, 'chatRooms', roomId), updates, { merge: true });
    } catch (e) {
      handleFirestoreError(e, 'Update Chat Room');
    }
  }, [quotaExceeded]);

  const pinChatMessage = useCallback(async (roomId: string, messageId: string) => {
    if (quotaExceeded) return;
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'chatRooms', roomId), { pinnedMessageId: messageId }, { merge: true });
      batch.set(doc(db, 'staffChat', messageId), { isPinned: true }, { merge: true });
      await batch.commit();
    } catch (e) {
      handleFirestoreError(e, 'Pin Message');
    }
  }, [quotaExceeded]);

  const unpinChatMessage = useCallback(async (roomId: string) => {
    if (quotaExceeded) return;
    const room = chatRooms.find(r => r.id === roomId);
    if (room?.pinnedMessageId) {
      try {
        const batch = writeBatch(db);
        batch.set(doc(db, 'staffChat', room.pinnedMessageId), { isPinned: false }, { merge: true });
        batch.set(doc(db, 'chatRooms', roomId), { pinnedMessageId: null }, { merge: true });
        await batch.commit();
      } catch (e) {
        handleFirestoreError(e, 'Unpin Message');
      }
    }
  }, [quotaExceeded, chatRooms]);

  const updateParticipantInRoom = useCallback(async (roomId: string, staffId: string, action: 'add' | 'remove') => {
    if (quotaExceeded) return;
    const room = chatRooms.find(r => r.id === roomId);
    if (!room) return;
    
    const newParticipants = action === 'add' 
      ? [...new Set([...room.participants, staffId])] 
      : room.participants.filter(id => id !== staffId);
      
    try {
      await setDoc(doc(db, 'chatRooms', roomId), { participants: newParticipants }, { merge: true });
    } catch (e) {
      handleFirestoreError(e, 'Update Participants');
    }
  }, [quotaExceeded, chatRooms]);

  const clearChatRoomMessages = useCallback(async (roomId: string) => {
    if (quotaExceeded) return;
    try {
      const q = query(collection(db, 'staffChat'), where('roomId', '==', roomId));
      const snap = await getDocs(q);
      const batch = writeBatch(db);
      snap.docs.forEach(docSnap => {
        batch.delete(docSnap.ref);
      });
      batch.set(doc(db, 'chatRooms', roomId), { pinnedMessageId: null, lastMessage: '', lastMessageTimestamp: Date.now() }, { merge: true });
      await batch.commit();
    } catch (e) {
      handleFirestoreError(e, 'Clear Chat Messages');
    }
  }, [quotaExceeded]);

  const deleteChatRoom = useCallback(async (roomId: string) => {
    if (quotaExceeded) return;
    try {
      const q = query(collection(db, 'staffChat'), where('roomId', '==', roomId));
      const snap = await getDocs(q);
      const batch = writeBatch(db);
      snap.docs.forEach(docSnap => {
        batch.delete(docSnap.ref);
      });
      batch.delete(doc(db, 'chatRooms', roomId));
      await batch.commit();
    } catch (e) {
      handleFirestoreError(e, 'Delete Chat Room');
    }
  }, [quotaExceeded]);

  // Управление присутствием пользователя
  const setUserPresence = useCallback(async (userId: string, isOnline: boolean) => {
    if (quotaExceeded || !firebaseUser) return;
    try {
      await setDoc(doc(db, 'staff', userId), { 
        isOnline, 
        lastSeen: Date.now(),
        firebaseUid: firebaseUser.uid
      }, { merge: true });
    } catch (e) {
      handleFirestoreError(e, 'Set User Presence', `staff/${userId}`);
    }
  }, [quotaExceeded, firebaseUser]);

  const markMessageAsRead = useCallback(async (messageId: string, userId: string) => {
     if (quotaExceeded) return;
     const msg = staffMessages.find(m => m.id === messageId);
     if (msg && !msg.readBy?.includes(userId)) {
       try {
         await setDoc(doc(db, 'staffChat', messageId), {
           readBy: [...(msg.readBy || []), userId]
         }, { merge: true });
       } catch (e) {
         handleFirestoreError(e, 'Mark Message Read');
       }
     }
  }, [quotaExceeded, staffMessages]);

  const createChatRoom = useCallback(async (roomData: Omit<ChatRoom, 'id' | 'createdAt'> & { id?: string }) => {
    const id = roomData.id || generateId();
    const newRoom: ChatRoom = {
      name: roomData.name,
      type: roomData.type,
      participants: roomData.participants,
      createdById: roomData.createdById,
      id,
      createdAt: Date.now(),
      lastMessage: '',
      lastMessageTimestamp: Date.now()
    };
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'chatRooms', id), newRoom);
      } catch (e) {
        handleFirestoreError(e, 'Create Chat Room');
      }
    }
    return id;
  }, [quotaExceeded]);

  const addToCart = useCallback((dish: Dish) => {
    setCart(prev => {
      const existing = prev.find(item => item.dishId === dish.id);
      if (existing) {
        return prev.map(item => 
          item.dishId === dish.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { dishId: dish.id, name: dish.name, quantity: 1, price: dish.price }];
    });
  }, []);

  const removeFromCart = useCallback((dishId: string) => {
    setCart(prev => prev.filter(item => item.dishId !== dishId));
  }, []);

  const updateCartQuantity = useCallback((dishId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.dishId === dishId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const cleanupOldData = useCallback(async () => {
    if (quotaExceeded) return;
    try {
      const batch = writeBatch(db);
      const now = Date.now();
      const oneWeekAgo = now - (7 * 24 * 60 * 60 * 1000);
      
      // Санация логов
      const logsSnap = await getDocs(query(collection(db, 'logs'), where('timestamp', '<', oneWeekAgo)));
      logsSnap.docs.forEach(d => batch.delete(d.ref));
      
      // Санация уведомлений
      const notifsSnap = await getDocs(query(collection(db, 'notifications'), where('timestamp', '<', oneWeekAgo)));
      notifsSnap.docs.forEach(d => batch.delete(d.ref));
      
      // Санация системных логов
      const sysLogsSnap = await getDocs(query(collection(db, 'system_logs'), where('timestamp', '<', oneWeekAgo)));
      sysLogsSnap.docs.forEach(d => batch.delete(d.ref));

      await batch.commit();
      console.log('Old data cleaned up successfully');
    } catch (e) {
      handleFirestoreError(e, 'Cleanup Old Data');
    }
  }, [quotaExceeded]);

  const addDocument = useCallback(async (docData: Omit<ElectronicDocument, 'id' | 'createdAt'>) => {
    const id = generateId();
    const newDoc: ElectronicDocument = {
      ...docData,
      id,
      createdAt: Date.now()
    };

    setDocuments(prev => [newDoc, ...prev]);
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'documents', id), newDoc);
      } catch (e) {
        handleFirestoreError(e, 'Add Document');
      }
    }
    return id;
  }, [quotaExceeded, generateId]);

  const updateDocument = useCallback(async (id: string, updates: Partial<ElectronicDocument>) => {
    setDocuments(prev => prev.map(d => d.id === id ? { ...d, ...updates } : d));
    if (!quotaExceeded) {
      try {
        await setDoc(doc(db, 'documents', id), updates, { merge: true });
      } catch (e) {
        handleFirestoreError(e, 'Update Document');
      }
    }
  }, [quotaExceeded]);

  const deleteDocument = useCallback(async (id: string) => {
    setDocuments(prev => prev.filter(d => d.id !== id));
    if (!quotaExceeded) {
      try {
        await deleteDoc(doc(db, 'documents', id));
      } catch (e) {
        handleFirestoreError(e, 'Delete Document');
      }
    }
  }, [quotaExceeded]);

  const clearDatabaseCache = useCallback(async () => {
    try {
      await terminate(db);
      await clearIndexedDbPersistence(db);
      window.location.reload();
    } catch (e) {
      console.error('Error clearing database cache:', e);
    }
  }, []);

  return {
    dishes,
    updateDish,
    deleteDish,
    ingredients,
    updateIngredient,
    deleteIngredient,
    orders,
    addOrder,
    updateOrderStatus,
    staff,
    updateStaff,
    updateStaffProfile,
    deleteStaff,
    expenses,
    addExpense,
    promoCodes,
    updatePromoCode,
    deletePromoCode,
    tickets,
    addTicket,
    updateTicket,
    archiveTicket,
    addTicketComment,
    markTicketAsRead,
    chatRooms,
    createChatRoom,
    staffMessages,
    sendStaffMessage,
    markMessageAsRead,
    pinChatMessage,
    unpinChatMessage,
    updateChatRoom,
    updateParticipantInRoom,
    clearChatRoomMessages,
    deleteChatRoom,
    setUserPresence,
    documents,
    addDocument,
    updateDocument,
    deleteDocument,
    notifications,
    addNotification,
    markNotificationRead,
    markAllNotificationsRead,
    clearNotifications,
    clearOrders,
    clearKitchenOrders,
    cleanupOldData,
    clearDatabaseCache,
    quotaExceeded,
    logs,
    logAction,
    generateId,
    cart,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    isInitialDataChecked,
    isSystemOffline,
    setSystemOfflineStatus,
    currentUser,
    setCurrentUser,
    currentView,
    setView,
    theme,
    setTheme,
    loadingTimedOut,
    setLoadingTimedOut,
    authInitialized,
    firebaseUser,
    mappingSynced
  };
}
